package com.dbs.daas.fitch.services;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.dbs.daas.fitch.config.SCPSourceOptionsMetadata;
import com.dbs.daas.fitch.fixtures.BatchFileFixture;
import com.dbs.daas.fitch.fixtures.EntityDataFixture;
import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.BatchFile;
import com.dbs.daas.fitch.model.EntityData;
import com.dbs.daas.fitch.repositories.BatchFileRepository;
import com.dbs.daas.fitch.repositories.EntityDataRepository;

public class DataProcessingServiceTests {

	@Autowired
	private SCPSourceOptionsMetadata options;

    @Mock
    private EntityDataRepository entityDataRepository;

    @Mock
    private BatchFileRepository fileRepository;
    
    @Mock
    private ClientStateService clientStateService;
    
    @Mock
    private BufferedReader br;

    private DataProcessingService service;

    @Before
    public void setup() throws ParseException {
        MockitoAnnotations.initMocks(this); 
        
        options = new SCPSourceOptionsMetadata();
    	
    	Map<Integer, String> fileNames = new HashMap<>();
        fileNames.put(0, ApiConstants.DEFAULT_ISSUE_DAILY_FILE_NAME);

        options.setFileNames(fileNames);

        Map<Integer, String[]> columnNames = new HashMap<>();
        columnNames.put(0, new String[]{"TRCSCODE", "GROUP", "RISK", "PILLAR", "AMOUNT"});

        options.setColumnNames(columnNames);

        Map<Integer, String[]> columnRanges = new HashMap<>();
        columnRanges.put(0, new String[]{"1-30", "31-37", "99-105", "179-182", "249-265"});

        options.setColumnRanges(columnRanges);    
        
        service = new DataProcessingService(options, entityDataRepository, fileRepository);
        
        //1487260800000 - 17022017
        //1487088000000 - 15022017
    }

	@Test
	public void checkFileForProcessingTest1() {
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileProcessed());
		Boolean result = service.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(false, result);
	}

	@Test
	public void checkFileForProcessingTest2() {
		when(fileRepository.exists(anyString())).thenReturn(false);
		Boolean result = service.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(true, result);
	}

	@Test
	public void checkFileForProcessingTest3() {
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileInprogressBeforeHrs1());
		Boolean result = service.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(false, result);
	}

	@Test
	public void checkFileForProcessingTest4() {
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileInprogressBeforeHrs2());
		Boolean result = service.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(true, result);
	}

	@Test
	public void checkFileForProcessingTest5() {
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileInprogressAfterHrs1());
		Boolean result = service.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(false, result);
	}

	@Test
	public void checkFileForProcessingTest6() {
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileInprogressAfterHrs2());
		Boolean result = service.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(true, result);
	}

	@Test
	public void checkFileForProcessingTest7() {
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileMismatch());
		Boolean result = service.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(true, result);
	}

	@Test
	public void createOrUpdateStatusTest() {
		when(fileRepository.save(any(BatchFile.class))).thenReturn(BatchFileFixture.getBatchFileInprogressAfterHrs2());
		service.createOrUpdateStatus(BatchFileFixture.getBatchFileInprogressAfterHrs2());
	}

    @Test
    public void getAllByRecordTest() {
        when(entityDataRepository.getAllByRecordHash(anyInt())).thenReturn(EntityDataFixture.getEntityData().get(0));
        EntityData data = service.getAllByRecordHash(123);
        assertNotNull(data);
    }
}