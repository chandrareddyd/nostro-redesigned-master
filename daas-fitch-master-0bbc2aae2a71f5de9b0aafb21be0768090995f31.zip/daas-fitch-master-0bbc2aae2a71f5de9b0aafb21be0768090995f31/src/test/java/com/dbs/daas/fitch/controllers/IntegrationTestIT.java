package com.dbs.daas.fitch.controllers;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.concurrent.TimeoutException;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dbs.daas.fitch.exception.APIException;
import com.dbs.daas.fitch.fixtures.SchemaModelFixture;
import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.SchemaModel;
import com.dbs.daas.fitch.util.CommonUtil;
import com.dbs.daas.fitch.util.MessageHandler;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class IntegrationTestIT {
	private static final Logger LOGGER = LoggerFactory.getLogger(IntegrationTestIT.class);

	private String remoteHost;

	@Before
	public void setup() {
		//remoteHost = "http://localhost:8080";
		remoteHost = System.getProperty("remoteHost");
	}

	@Test
	public void test_01_canRegisterSchemaModel() throws IOException, JSONException, ParseException {

		URL url;

		String urlString = remoteHost + "/fitch/v1/register";
		LOGGER.debug(urlString);

		String payload = "{ \"appName\": \"TEST-APP\", \"model\": [ \"REPORT_DATE_TIME\", \"AGENT_COMMON_ID\", \"COUNTRY_NAME\", \"ISSUER_ID\" ], \"topicName\": \"TEST-QUEUE\", \"uriConn\": \"amqp://2b0e93de-298f-4779-a0d8-3a8e62825946:hsuei5thtipuk0iejnnu685l50@10.92.206.40/f711d2a5-4958-43ab-9dfb-8fef3f5379ed\" }";
				
		if (!remoteHost.contains("uat")) {
			url = new URL(urlString);
			JSONObject jsonResponse = doRestCall(url, "POST", payload);
			assertNotNull(jsonResponse);
			assertThat(jsonResponse.get("appName"), equalTo("TEST-APP"));
			assertThat(jsonResponse.get("topicName"), equalTo("TEST-QUEUE"));
			JSONArray jsonArray = (JSONArray) jsonResponse.get("model");
			assertNotNull(jsonArray);
		}
	}

	@Test
	public void test_02_canGetSchemaModel() throws IOException, JSONException, ParseException {

		URL url;

		String urlString = remoteHost + "/fitch/v1/model/TEST-APP";
		LOGGER.debug(urlString);
		
		if (!remoteHost.contains("uat")) {
			url = new URL(urlString);
			JSONObject jsonResponse = doRestCall(url, "GET");
			assertNotNull(jsonResponse);
			assertThat(jsonResponse.get("appName"), equalTo("TEST-APP"));
		}
	}

	@Test
	public void test_03_canGetData() throws JSONException, ParseException {
		
		URL url;

		String urlString = remoteHost + "/fitch/v1/TEST-APP?replay=N&page=2&size=1&timestamp=sdfdsfdsf";
		LOGGER.debug(urlString);
		
		try {
			if (!remoteHost.contains("uat")) {
				url = new URL(urlString);
				JSONObject jsonResponse = doRestCall(url, "GET");
				assertNotNull(jsonResponse);
				assertNotNull(jsonResponse.get("statusCode"));
				assertEquals(400, jsonResponse.get("statusCode"));
				assertEquals("Bad Request", jsonResponse.get("message"));
			}
		} catch(IOException e) {
			LOGGER.info("Returns 400. Invalid timestamp");
			LOGGER.error(e.getMessage());
		}
	}

	@Test
	public void test_04_canDeleteSchemaModel() throws IOException, JSONException, ParseException {
		
		URL url;

		String urlString = remoteHost + "/fitch/v1/TEST-APP";
		LOGGER.debug(urlString);

		if (!remoteHost.contains("uat")) {
			url = new URL(urlString);
			JSONObject jsonResponse = doRestCall(url, "DELETE");
			assertNotNull(jsonResponse);
			assertNotNull(jsonResponse.get("status"));
			assertThat(jsonResponse.get("status"), equalTo("success"));
		}
	}

	@Test
	public void test_05_canGetData() throws JSONException, ParseException {
		
		URL url;

		String urlString = remoteHost + "/fitch/v1/TEST-APP?replay=N&page=2&size=1";
		LOGGER.debug(urlString);

		try {
			if (!remoteHost.contains("uat")) {
				url = new URL(urlString);
				JSONObject jsonResponse = doRestCall(url, "GET");
				assertNotNull(jsonResponse);
				assertNotNull(jsonResponse.get("statusCode"));
				assertEquals(404, jsonResponse.get("statusCode"));
				assertNotNull(jsonResponse.get("numberOfElements"));
				assertEquals("Not Found", jsonResponse.get("message"));
			}
		} catch(IOException e) {
			LOGGER.info("Returns 404. Invalid appName");
			LOGGER.error(e.getMessage());
		}
	}

	@Test
	public void test_06_canDeleteSchemaModel() throws JSONException, ParseException {
		
		URL url;

		String urlString = remoteHost + "/fitch/v1/TEST-APP";
		LOGGER.debug(urlString);

		try {
			if (!remoteHost.contains("uat")) {
				url = new URL(urlString);
				JSONObject jsonResponse = doRestCall(url, "DELETE");
				assertNotNull(jsonResponse);
				assertNotNull(jsonResponse.get("statusCode"));
				assertEquals(404, jsonResponse.get("statusCode"));
				assertNotNull(jsonResponse.get("numberOfElements"));
				assertEquals("Not Found", jsonResponse.get("message"));
			}
		} catch(IOException e) {
			LOGGER.info("Returns 404. Invalid appName");
			LOGGER.error(e.getMessage());
		}
	}

	@Test
	public void test_07_canGetSchemaModel() throws JSONException, ParseException {

		URL url;

		String urlString = remoteHost + "/fitch/v1/model/TEST-APP";
		LOGGER.debug(urlString);
		
		try {
			if (!remoteHost.contains("uat")) {
				url = new URL(urlString);
				JSONObject jsonResponse = doRestCall(url, "GET");
				assertNotNull(jsonResponse);
				assertNotNull(jsonResponse.get("statusCode"));
				assertEquals(404, jsonResponse.get("statusCode"));
				assertNotNull(jsonResponse.get("numberOfElements"));
				assertEquals("Not Found", jsonResponse.get("message"));
			}
		} catch(IOException e) {
			LOGGER.info("Returns 404. Invalid appName");
			LOGGER.error(e.getMessage());
		}
	}

	@Test
	public void test_08_canRegisterSchemaModel() throws IOException, JSONException, ParseException {

		URL url;

		String urlString = remoteHost + "/fitch/v1/register";
		LOGGER.debug(urlString);

		String payload = "{ \"appName\": \"TEST-APP-1\" }";
		
		if (!remoteHost.contains("uat")) {
			url = new URL(urlString);
			JSONObject jsonResponse = doRestCall(url, "POST", payload);
			assertNotNull(jsonResponse);
			assertThat(jsonResponse.get("appName"), equalTo("TEST-APP-1"));
			JSONArray jsonArray = (JSONArray) jsonResponse.get("model");
			assertNotNull(jsonArray);
			for (int i = 0; i < jsonArray.length(); i++) {
				assertEquals(true, ApiConstants.DEFAULT_MODEL_FIELDS_SET.contains(jsonArray.getString(i)));
			}
		}
	}

	@Test
	public void test_09_canDeleteSchemaModel() throws IOException, JSONException, ParseException {
		
		URL url;

		String urlString = remoteHost + "/fitch/v1/TEST-APP-1";
		LOGGER.debug(urlString);

		if (!remoteHost.contains("uat")) {
			url = new URL(urlString);
			JSONObject jsonResponse = doRestCall(url, "DELETE");
			assertNotNull(jsonResponse);
			assertNotNull(jsonResponse.get("status"));
			assertThat(jsonResponse.get("status"), equalTo("success"));
		}
	}

	@Test
	public void test_10_canSearchRatings() throws IOException, JSONException, ParseException {

		URL url;

		String urlString = remoteHost + "/fitch/v1/search";
		LOGGER.debug(urlString);

		String payload = "{ }";
		
		try {
			if (!remoteHost.contains("uat")) {
				url = new URL(urlString);
				JSONObject jsonResponse = doRestCall(url, "POST", payload);
				assertNotNull(jsonResponse);
				assertNotNull(jsonResponse.get("statusCode"));
				assertEquals(400, jsonResponse.get("statusCode"));
				assertEquals("Bad Request", jsonResponse.get("message"));
			}
		} catch(IOException e) {
			LOGGER.info("Returns 400. Invalid search model");
			LOGGER.error(e.getMessage());
		}
	}

	@Test
	public void test_11_canSearchRatings() throws JSONException, ParseException {

		URL url;

		String urlString = remoteHost + "/fitch/v1/search";
		LOGGER.debug(urlString);

		String payload = "{ \"RATING_ORG\": \"MLC\", \"RATING_TYPE\": [\"LT_IDR\", \"LT_ISSUER\"], \"IDENTIFIER\": [ {\"ID_TYPE\": \"FITCH_ID\", \"ID_VALUE\": \"11829\"}, {\"ID_TYPE\": \"FITCH_ID\", \"ID_VALUE\": \"138966\"} ], \"SEARCH_TYPE\": \"LATEST\" }";
		
		try {
			if (!remoteHost.contains("uat")) {
				url = new URL(urlString);
				JSONObject jsonResponse = doRestCall(url, "POST", payload);
				assertNotNull(jsonResponse);
				assertNotNull(jsonResponse.get("statusCode"));
				assertEquals(400, jsonResponse.get("statusCode"));
				assertEquals("Bad Request", jsonResponse.get("message"));
			}
		} catch(IOException e) {
			LOGGER.info("Returns 400. Invalid RATING_ORG");
			LOGGER.error(e.getMessage());
		}
	}

	@Test
	public void test_12_canSearchRatings() throws JSONException, ParseException {

		URL url;

		String urlString = remoteHost + "/fitch/v1/search?page=x&size=2";
		LOGGER.debug(urlString);

		String payload = "{ \"RATING_ORG\": \"FITCH\", \"RATING_TYPE\": [\"LT_IDR\", \"LT_ISSUER\"], \"IDENTIFIER\": [ {\"ID_TYPE\": \"FITCH_ID\", \"ID_VALUE\": \"11829\"}, {\"ID_TYPE\": \"FITCH_ID\", \"ID_VALUE\": \"138966\"} ], \"SEARCH_TYPE\": \"LATEST\" }";

		try {
			if (!remoteHost.contains("uat")) {
				url = new URL(urlString);
				JSONObject jsonResponse = doRestCall(url, "POST", payload);
				assertNotNull(jsonResponse);
				assertNotNull(jsonResponse.get("statusCode"));
				assertEquals(200, jsonResponse.get("statusCode"));
			}
		} catch (IOException e) {
			LOGGER.info("Returns 400. Invalid page");
			LOGGER.error(e.getMessage());
		}
	}

	@Test
	public void test_13_canPublishMessage() throws APIException, IOException, TimeoutException {
		Channel channel = null;
		try {
			channel = getChannel(SchemaModelFixture.getSchemaModel());
			final Consumer consumer = new DefaultConsumer(channel) {
				@Override
				public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties,
						byte[] body) throws IOException {
					String subscribedMessage = new String(body, "UTF-8");
					LOGGER.info("Published message: " + subscribedMessage);
					JSONObject notificationMessage = null;;
					try {
						notificationMessage = new JSONObject(subscribedMessage);
						
						assertNotNull(notificationMessage);
						assertNotNull(notificationMessage.get("appName"));
						assertThat(notificationMessage.get("appName"), equalTo("TEST-APP"));
						assertNotNull(notificationMessage.get("serviceName"));
						assertThat(notificationMessage.get("serviceName"), equalTo("fitch"));
						
					} catch (JSONException e) {
						LOGGER.error("Failed to receive published message. Error: " + e.getMessage());
						e.printStackTrace();
					}
				}
			};
			boolean autoAck = true; // acknowledgment is covered below
			MessageHandler.publishMessage(SchemaModelFixture.getSchemaModel());
			String message = channel.basicConsume(SchemaModelFixture.getSchemaModel().getTopicName(), autoAck,
					consumer);
			assertNotNull(message);

		} catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
			if (null != channel) {
				channel.close();
			}
		}
	}

	private Channel getChannel(SchemaModel model) throws IOException, TimeoutException, APIException {
		ConnectionFactory factory = new ConnectionFactory();
		Connection connection = null;
		Channel channel = null;

		if (model != null) {
			factory.setVirtualHost(model.getMqVirtualHost());
			factory.setHost(model.getMqHost());
			factory.setPort(model.getMqPort());
			factory.setUsername(model.getMqUsername());
			factory.setPassword(model.getMqPassword());
			if (null != model.getMqPassword()) {
				factory.setPassword(CommonUtil.decrypt(model.getMqPassword()));
			}
			connection = factory.newConnection();
			channel = connection.createChannel();
            channel.exchangeDeclare(model.getTopicName(), "fanout", true);
            channel.queueDeclare(model.getTopicName(), false, false, false, null);
            channel.queueBind(model.getTopicName(), model.getTopicName(), "");
			return channel;
		}
		return channel;
	}

	
	private JSONObject doRestCall(URL url, String type) throws IOException, JSONException, ParseException {
		return doRestCall(url, type, null);
	}

	private JSONObject doRestCall(URL url, String type, String payload) throws IOException, JSONException, ParseException {
		JSONObject result = null;
		HttpURLConnection conn = null;

		if (type.equals("GET")) {
			conn = getHttpURLConnectionGET(url);
		} else if (type.equals("POST")) {
			conn = getHttpURLConnectionPOST(url, payload);
		} else if (type.equals("DELETE")) {
			conn = getHttpURLConnectionDELETE(url);
		}

		if (200 != conn.getResponseCode() && 201 != conn.getResponseCode() && 204 != conn.getResponseCode()) {
			LOGGER.error("Failed : HTTP error code : " + conn.getResponseCode());
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

		String line;
		StringBuilder stringBuilder = new StringBuilder();
		while ((line = br.readLine()) != null) {
			stringBuilder.append(line);
		}

		String jsonString = stringBuilder.toString();
		LOGGER.debug("Output from Server .... \n" + jsonString);
		jsonString = jsonString.replaceAll("\n", "\\n");
		result = new JSONObject(jsonString);

		conn.disconnect();

		return result;
	}

	private HttpURLConnection getHttpURLConnectionGET(URL url) throws IOException, JSONException {
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-Type", "application/json");
		org.codehaus.jettison.json.JSONObject headerJson = new org.codehaus.jettison.json.JSONObject();
		headerJson.put("language", "en");
		headerJson.put("country", "sg");
		headerJson.put("status", "1");
		conn.setDoOutput(false);
		conn.setRequestProperty("header", headerJson.toString());
		return conn;
	}

	private HttpURLConnection getHttpURLConnectionPOST(URL url, String payload) throws IOException, JSONException {
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/json");
		org.codehaus.jettison.json.JSONObject headerJson = new org.codehaus.jettison.json.JSONObject();
		headerJson.put("language", "en");
		headerJson.put("country", "sg");
		headerJson.put("status", "1");
		conn.setRequestProperty("header", headerJson.toString());

		byte[] postData = payload.getBytes(StandardCharsets.UTF_8);
		int postDataLength = postData.length;
		conn.setDoOutput(true);
		conn.setRequestProperty("charset", "utf-8");
		conn.setRequestProperty("Content-Length", Integer.toString(postDataLength));
		conn.setUseCaches(false);
		try (DataOutputStream wr = new DataOutputStream(conn.getOutputStream())) {
			wr.write(postData);
		}
		return conn;
	}

	private HttpURLConnection getHttpURLConnectionDELETE(URL url) throws IOException, JSONException {
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("DELETE");
		conn.setRequestProperty("Content-Type", "application/json");
		org.codehaus.jettison.json.JSONObject headerJson = new org.codehaus.jettison.json.JSONObject();
		headerJson.put("language", "en");
		headerJson.put("country", "sg");
		headerJson.put("status", "1");
		conn.setDoOutput(false);
		conn.setRequestProperty("header", headerJson.toString());
		return conn;
	}

}