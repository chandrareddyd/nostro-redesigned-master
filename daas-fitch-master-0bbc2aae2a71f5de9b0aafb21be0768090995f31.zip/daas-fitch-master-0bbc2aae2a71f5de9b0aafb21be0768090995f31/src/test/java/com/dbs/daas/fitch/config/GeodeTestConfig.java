package com.dbs.daas.fitch.config;


import java.util.Properties;

import org.apache.geode.cache.GemFireCache;
import org.apache.geode.cache.query.QueryService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.gemfire.CacheFactoryBean;
import org.springframework.data.gemfire.PartitionedRegionFactoryBean;
import org.springframework.data.gemfire.repository.config.EnableGemfireRepositories;

import com.dbs.daas.fitch.FitchApp;
import com.dbs.daas.fitch.model.BatchFile;
import com.dbs.daas.fitch.model.ClientState;
import com.dbs.daas.fitch.model.EntityData;
import com.dbs.daas.fitch.model.SchemaModel;

@Configuration
@EnableGemfireRepositories(value = "com.dbs.daas.fitch.repositories")
public class GeodeTestConfig {

    protected static final String DEFAULT_GEMFIRE_LOG_LEVEL = "error";

    protected String applicationName() {
        return FitchApp.class.getSimpleName();
    }

    protected String logLevel() {
        return System.getProperty("gemfire.log-level", DEFAULT_GEMFIRE_LOG_LEVEL);
    }

    public Properties geodeProperties() {
        Properties gemfireProperties = new Properties();

        gemfireProperties.setProperty("name", applicationName());
        gemfireProperties.setProperty("mcast-port", "0");
        gemfireProperties.setProperty("log-level", logLevel());

        return gemfireProperties;
    }

    @Bean
    public CacheFactoryBean geodeCache() {
    	//PoolManager.createFactory().addLocator(locatorAddress,locatorPort).create("fitch-pool");
        CacheFactoryBean gemfireCache = new CacheFactoryBean();
        gemfireCache.setClose(true);
        gemfireCache.setProperties(geodeProperties());

        return gemfireCache;
    }

    @Bean
    public PartitionedRegionFactoryBean<String, EntityData> dataEntitiesRegion(GemFireCache gemfireCache) {

        PartitionedRegionFactoryBean<String, EntityData> dataEntitiesRegion = new PartitionedRegionFactoryBean<>();
        dataEntitiesRegion.setCache(gemfireCache);
        dataEntitiesRegion.setClose(false);
        dataEntitiesRegion.setPersistent(false);
        dataEntitiesRegion.setName("Fitch_DataEntities");
        return dataEntitiesRegion;
    }

	@Bean
	public PartitionedRegionFactoryBean<String, SchemaModel> schemaModelPartitionedRegionFactoryBean(
			GemFireCache gemfireCache) {

		PartitionedRegionFactoryBean<String, SchemaModel> schemaModelPartitionedRegionFactoryBean = new PartitionedRegionFactoryBean<>();
		schemaModelPartitionedRegionFactoryBean.setCache(gemfireCache);
		schemaModelPartitionedRegionFactoryBean.setClose(false);
		schemaModelPartitionedRegionFactoryBean.setPersistent(false);
		schemaModelPartitionedRegionFactoryBean.setName("Fitch_Schemas");
		return schemaModelPartitionedRegionFactoryBean;
	}

	@Bean
	public PartitionedRegionFactoryBean<String, BatchFile> batchFilePartitionedRegionFactoryBean(
			GemFireCache gemfireCache) {

		PartitionedRegionFactoryBean<String, BatchFile> batchFilePartitionedRegionFactoryBean = new PartitionedRegionFactoryBean<>();
		batchFilePartitionedRegionFactoryBean.setCache(gemfireCache);
		batchFilePartitionedRegionFactoryBean.setClose(false);
		batchFilePartitionedRegionFactoryBean.setPersistent(false);
		batchFilePartitionedRegionFactoryBean.setName("Fitch_BatchFiles");
		return batchFilePartitionedRegionFactoryBean;
	}

	@Bean
	public PartitionedRegionFactoryBean<String, ClientState> clientStatePartitionedRegionFactoryBean(
			GemFireCache gemfireCache) {

		PartitionedRegionFactoryBean<String, ClientState> clientStatePartitionedRegionFactoryBean = new PartitionedRegionFactoryBean<>();
		clientStatePartitionedRegionFactoryBean.setCache(gemfireCache);
		clientStatePartitionedRegionFactoryBean.setClose(false);
		clientStatePartitionedRegionFactoryBean.setPersistent(false);
		clientStatePartitionedRegionFactoryBean.setName("Fitch_ClientState");
		return clientStatePartitionedRegionFactoryBean;
	}

    @Bean
    public QueryService queryService(GemFireCache gemfireCache) {
        return gemfireCache.getQueryService();
    }

}
