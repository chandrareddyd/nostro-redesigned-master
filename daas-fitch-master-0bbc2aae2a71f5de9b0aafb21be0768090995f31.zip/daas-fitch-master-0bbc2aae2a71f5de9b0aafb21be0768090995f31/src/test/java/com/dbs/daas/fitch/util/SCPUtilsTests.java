package com.dbs.daas.fitch.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.Arrays;

import org.apache.sshd.common.NamedFactory;
import org.apache.sshd.common.file.virtualfs.VirtualFileSystemFactory;
import org.apache.sshd.server.Command;
import org.apache.sshd.server.SshServer;
import org.apache.sshd.server.keyprovider.SimpleGeneratorHostKeyProvider;
import org.apache.sshd.server.scp.ScpCommandFactory;
import org.apache.sshd.server.subsystem.sftp.SftpSubsystemFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.daas.fitch.config.SCPSourceOptionsMetadata;
import com.dbs.daas.fitch.model.ApiConstants;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;


@RunWith(SpringRunner.class)
@SpringBootTest
public class SCPUtilsTests {

	@Autowired
    private SCPSourceOptionsMetadata options;
	
	@Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();
    

    private SshServer sshd;

    @Autowired
	private SCPUtils scpUtil;
	
	@Before
	public void setup() throws IOException, InterruptedException {

		setupSSHServer();
	}
	
	@After
	public void teardown() throws IOException {
		if(null != sshd) {
			sshd.stop();
		}
	}
	
    @Test
    public void authenticateScpServerTest() throws JSchException {    	
    	Session session = scpUtil.authenticateScpServer(options);    	
    	assertNotNull(session);		
    }
	
    @Test
    public void testRemoteFile_exist() throws IOException, JSchException {
    	File file = scpUtil.getRemoteFile(scpUtil.authenticateScpServer(options), options.getFileNames().get(0), ApiConstants.DEFAULT_ISSUE_DAILY_FILE_NAME);
    	assertNotNull(file);		
    	file.delete();
    }

    @Test
    public void testRemoteFileDoes_not_exist() throws Exception {
        File file = scpUtil.getRemoteFile(scpUtil.authenticateScpServer(options), "/tmp/hello_there.txt", ApiConstants.DEFAULT_ISSUE_DAILY_FILE_NAME);
        assertNull(file);
    }

    @Test
    public void checksumLocalFileTest() throws Exception {
        String checksum = scpUtil.checksumLocalFile(new FileInputStream(getFileSource(0)));
        assertNotNull(checksum);
    }

    private void setupSSHServer() throws IOException, InterruptedException {
        File file = getFileSource(0);
        Files.copy(file.toPath(), tempFolder.getRoot().toPath().resolve(file.getName()));

        sshd = SshServer.setUpDefaultServer();
        sshd.setFileSystemFactory(new VirtualFileSystemFactory(tempFolder.getRoot().toPath()));
        sshd.setHost(options.getHostname());
        sshd.setPort(options.getPort());
        sshd.setSubsystemFactories(Arrays.<NamedFactory<Command>>asList(new SftpSubsystemFactory()));
        sshd.setCommandFactory(new ScpCommandFactory());
        sshd.setKeyPairProvider(new SimpleGeneratorHostKeyProvider(tempFolder.newFile("hostkey.ser")));
        sshd.setPasswordAuthenticator((username, password, session) -> options.getUsername().equals(username) && options.getPassword().equals(password));
        sshd.start();
    }
    
	public File getFileSource(Integer fileIndex) throws IOException {
		ClassLoader classLoader = this.getClass().getClassLoader();

		URL fileUrl = null;

		fileUrl = classLoader.getResource(options.getFileNames().get(fileIndex));

		if(null != fileUrl) {
			return new File(fileUrl.getFile());
		} else {
			return null;
		}
	}

}