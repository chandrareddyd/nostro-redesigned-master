package com.dbs.daas.fitch.fixtures;

import static com.dbs.daas.fitch.model.ApiConstants.DAILY;
import static com.dbs.daas.fitch.model.ApiConstants.DEFAULT_ISSUER_DAILY_FILE_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.DEFAULT_ISSUER_MONTHLY_FILE_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.DEFAULT_ISSUE_DAILY_FILE_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.DEFAULT_ISSUE_MONTHLY_FILE_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.FILE_TYPE_ISSUE;
import static com.dbs.daas.fitch.model.ApiConstants.FILE_TYPE_ISSUER;
import static com.dbs.daas.fitch.model.ApiConstants.MONTHLY;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.geode.cache.query.internal.StructImpl;
import org.apache.geode.cache.query.internal.types.StructTypeImpl;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.dbs.daas.fitch.model.EntityData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EntityDataFixture {

    public static List<EntityData> getEntityData() {
        List<EntityData> entityDataList = new ArrayList<>();
        
        Map<String,String> data1 = new HashMap<>();     
        data1.put("ISSUER_ID", "85404676");
        data1.put("BANK_SUPPORT_RATING", "2");
        data1.put("BANK_INDIVIDUAL_RATING", "WD");
        data1.put("LT_IDR_EFFECTIVE_DATE", "2015-12-30 00:00:20");
        data1.put("LT_IDR_ACTION", "Withdrawn");
        
        Map<String,String> data2 = new HashMap<>(); 
        data2.put("ISSUER_ID", "85404676");
        data2.put("BANK_SUPPORT_RATING", "1");
        data2.put("BANK_INDIVIDUAL_RATING", "NR");
        data2.put("LT_IDR_EFFECTIVE_DATE", "2015-12-30 00:00:58");
        data2.put("LT_IDR_ACTION", "Affirmed");

        EntityData entityData = new EntityData();
        entityData.setFileName(DEFAULT_ISSUE_DAILY_FILE_NAME);
        entityData.setFileType(FILE_TYPE_ISSUE);
        entityData.setFrequency(DAILY);
        entityData.setData(data1);
        entityData.setDateOfIngestion(System.currentTimeMillis());
        entityData.setFileChecksum("checksum");
        entityDataList.add(entityData);
        
        entityData = new EntityData();
        entityData.setFileName(DEFAULT_ISSUE_MONTHLY_FILE_NAME);
        entityData.setFileType(FILE_TYPE_ISSUE);
        entityData.setFrequency(MONTHLY);
        entityData.setData(data2);
        entityData.setDateOfIngestion(System.currentTimeMillis());
        entityData.setFileChecksum("checksum");
        entityDataList.add(entityData);
        
        entityData = new EntityData();
        entityData.setFileName(DEFAULT_ISSUER_DAILY_FILE_NAME);
        entityData.setFileType(FILE_TYPE_ISSUER);
        entityData.setFrequency(DAILY);
        entityData.setData(data1);
        entityData.setDateOfIngestion(System.currentTimeMillis());
        entityData.setFileChecksum("checksum");
        entityDataList.add(entityData);
        
        entityData = new EntityData();
        entityData.setFileName(DEFAULT_ISSUER_MONTHLY_FILE_NAME);
        entityData.setFileType(FILE_TYPE_ISSUER);
        entityData.setFrequency(MONTHLY);
        entityData.setData(data2);
        entityData.setDateOfIngestion(System.currentTimeMillis());
        entityData.setFileChecksum("checksum");
        entityDataList.add(entityData);
        
        return entityDataList;
    }
    
    public static List<String> getEntityDataIds() {
        List<String> entityDataList = new ArrayList<>();
        entityDataList.add("000060a1-472b-4712-b327-56d4d78520ae1489654146164");
        entityDataList.add("0000fde3-fe41-4677-9555-e99397de10221489654075618");
        entityDataList.add("00012144-d2ae-4c87-a04e-5d7af7bc80001489654146037");
        entityDataList.add("0002806e-1f39-4333-a7bd-0b41b5b5f4ac1489654118656");
        entityDataList.add("00046312-f2de-422b-b9e3-213e9d361ded1489654105623");
		return entityDataList;
    }
    
    public static Page<EntityData> getEntityDataPage(int page, int size) {
        List<EntityData> entityDataList = getEntityData();

        PagedListHolder<EntityData> holder = new PagedListHolder<>(entityDataList);
        holder.setPage(page);
        holder.setPageSize(size);

        return new PageImpl<>(holder.getPageList(), createPageRequest(page, size), entityDataList.size());
    }

    public static Pageable createPageRequest(Integer page, Integer size) {
        return new PageRequest(page, size);
    }

    public static String getData() {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> responseJsonObject = new HashMap<>();
        
        List<Map<String,String>> entityDataList = new ArrayList<>();
        
        Map<String,String> data = new HashMap<>();
        
        data = new HashMap<>();        
        data.put("ISSUER_ID", "85404676");
        data.put("BANK_SUPPORT_RATING", "1");
        data.put("BANK_INDIVIDUAL_RATING", "NR");
        data.put("LT_IDR_EFFECTIVE_DATE", "2015-12-30 00:00:58");
        data.put("LT_IDR_ACTION", "Affirmed");
        entityDataList.add(data);
        
        data = new HashMap<>(); 
        data.put("ISSUER_ID", "85404676");
        data.put("BANK_SUPPORT_RATING", "2");
        data.put("BANK_INDIVIDUAL_RATING", "WD");
        data.put("LT_IDR_EFFECTIVE_DATE", "2015-12-30 00:00:20");
        data.put("LT_IDR_ACTION", "Withdrawn");
        entityDataList.add(data);
        
        responseJsonObject.put("first", true);
        responseJsonObject.put("last", true);
        responseJsonObject.put("totalPages", 1);
        responseJsonObject.put("totalElements", entityDataList.size());
        responseJsonObject.put("pageNumber", 0);
        responseJsonObject.put("batchDate", "2017-01-18 19:20:08");
        responseJsonObject.put("sort", null);
        responseJsonObject.put("size", 50);
        responseJsonObject.put("content", entityDataList);
        responseJsonObject.put("numberOfElements", entityDataList.size());
        
        try {
            return mapper.writeValueAsString(responseJsonObject);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getRatings() {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> responseJsonObject = new HashMap<>();
        
        List<Map<String,Object>> searchResults = new ArrayList<>();
        
        List<Map<String,String>> ratings = new ArrayList<>();
        
        Map<String,String> ratingData = new HashMap<>();
        
        ratingData = new HashMap<>();        
        ratingData.put("RATING_TYPE", "Long-Term Issuer Default Rating");
        ratingData.put("RATING_VALUE", "BBB+");
        ratingData.put("RATING_DATE", "2014-12-15 00:00:22");
        ratingData.put("RATING_ACTION", "Affirmed");
        ratings.add(ratingData);
        
        Map<String,Object> data = new HashMap<>();
        
        data.put("FITCH_ID", "138966");
        data.put("RATING_ORG", "FITCH");
        data.put("RATINGS", ratings);
        
        searchResults.add(data);
        
        ratings = new ArrayList<>();
        
        ratingData = new HashMap<>();
        
        ratingData = new HashMap<>();        
        ratingData.put("RATING_TYPE", "Long-Term Issuer Default Rating");
        ratingData.put("RATING_VALUE", "A");
        ratingData.put("RATING_DATE", "2014-06-24 02:23:37");
        ratingData.put("RATING_ACTION", "Affirmed");
        ratings.add(ratingData);
        
        data = new HashMap<>();
        
        data.put("FITCH_ID", "11829");
        data.put("RATING_ORG", "FITCH");
        data.put("RATINGS", ratings);
        
        searchResults.add(data);
        
        responseJsonObject.put("first", true);
        responseJsonObject.put("last", true);
        responseJsonObject.put("totalPages", 1);
        responseJsonObject.put("totalElements", searchResults.size());
        responseJsonObject.put("pageNumber", 0);
        responseJsonObject.put("sort", null);
        responseJsonObject.put("size", 50);
        responseJsonObject.put("content", searchResults);
        responseJsonObject.put("numberOfElements", searchResults.size());
        
        try {
            return mapper.writeValueAsString(responseJsonObject);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public static List<StructImpl> getRatingData() {
    	
    	String[] fields = new String[] {"AGENT_COMMON_ID","LONG_TERM_ISSUER_DEFAULT_RATING","LT_IDR_EFFECTIVE_DATE","LT_IDR_ACTION","LONG_TERM_ISSUER_RATING","LT_ISSUER_RATING_EFFECTIVE_DATE","LT_ISSUER_RATING_ACTION","SHORT_TERM_ISSUER_DEFAULT_RATING","ST_IDR_EFFECTIVE_DATE","ST_IDR_ACTION","SHORT_TERM_ISSUER_RATING","ST_ISSUER_RATING_EFFECTIVE_DATE","ST_ISSUER_RATING_ACTION","BANK_INDIVIDUAL_RATING","BANK_INDIVIDUAL_RATING_EFFECTIVE_DATE","BANK_INDIVIDUAL_RATING_ACTION","BANK_SUPPORT_RATING","BANK_SUPPORT_RATING_EFFECTIVE_DATE","BANK_SUPPORT_RATING_ACTION"};
    	
    	StructImpl s1 = new StructImpl(new StructTypeImpl(fields), new String[]{"11829", "A", "2014-06-24 02:23:37", "Affirmed", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null});
    	
    	StructImpl s2 = new StructImpl(new StructTypeImpl(fields), new String[]{"138966", "BBB+", "2014-12-15 00:00:22", "Affirmed", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null});
    	
    	List<StructImpl> results = new ArrayList<>();
    	results.add(s1);
    	results.add(s2);
    	
		return results;
    	
    }
}
