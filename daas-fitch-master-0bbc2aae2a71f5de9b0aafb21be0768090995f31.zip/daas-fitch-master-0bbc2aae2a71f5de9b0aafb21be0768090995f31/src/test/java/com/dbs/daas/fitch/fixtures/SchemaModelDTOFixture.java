package com.dbs.daas.fitch.fixtures;


import java.util.ArrayList;
import java.util.Arrays;

import com.dbs.daas.fitch.model.SchemaModelDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SchemaModelDTOFixture {
    public static SchemaModelDTO getSchemaModelDTO() {

        SchemaModelDTO dto = new SchemaModelDTO();

        dto.setAppName("TEST-APP");
        dto.setModel(new ArrayList<String>(Arrays.asList("ISSUER_ID","LONG_TERM_ISSUER_DEFAULT_RATING", "LONG_TERM_ISSUER_RATING", 
        		"BANK_INDIVIDUAL_RATING", "BANK_SUPPORT_RATING","LT_IDR_EFFECTIVE_DATE",
        		"LT_ISSUER_RATING_EFFECTIVE_DATE","BANK_INDIVIDUAL_RATING_EFFECTIVE_DATE","BANK_SUPPORT_RATING_EFFECTIVE_DATE","LT_IDR_ACTION",
        		"LT_ISSUER_RATING_ACTION","BANK_INDIVIDUAL_RATING_ACTION","BANK_SUPPORT_RATING_ACTION")));
        dto.setTopicName("TEST-APP-MQ");
        dto.setUriConn("amqp://2b0e93de-298f-4779-a0d8-3a8e62825946:hsuei5thtipuk0iejnnu685l50@10.92.206.40/f711d2a5-4958-43ab-9dfb-8fef3f5379ed");

        return dto;
    }

    public static String getJsonRequest() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(getSchemaModelDTO());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getInvalidJsonRequest() {
        ObjectMapper mapper = new ObjectMapper();
        SchemaModelDTO dto = getSchemaModelDTO();
        dto.setAppName(null);
        try {
            return mapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }
}
