package com.dbs.daas.fitch.fixtures;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.SearchModelDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SearchModelDTOFixture {
    public static SearchModelDTO getSearchModelDTO() {

    	SearchModelDTO dto = new SearchModelDTO();
        dto.setRatingOrg(ApiConstants.SERVICE_NAME.toUpperCase());
        dto.setRatingTypes(Arrays.asList(new String[]{"LT_IDR", "LT_ISSUER"}));
        
        List<Map<String, String>> identifiers = new ArrayList<>();
        
        Map<String, String> identifier = new HashMap<>();
        identifier.put(ApiConstants.ID_TYPE, "FITCH_ID");
        identifier.put(ApiConstants.ID_VALUE, "11829");
        identifiers.add(identifier);
        
        identifier = new HashMap<>();
        identifier.put(ApiConstants.ID_TYPE, "FITCH_ID");
        identifier.put(ApiConstants.ID_VALUE, "138966");
        identifiers.add(identifier);
        
        dto.setIdentifier(identifiers);
        
        dto.setSearchType(ApiConstants.SEARCH_TYPE_LATEST);

        return dto;
    }

    public static String getJsonRequest() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(getSearchModelDTO());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getSearchModelWithInvalidIdentifier1() {
        ObjectMapper mapper = new ObjectMapper();
        SearchModelDTO dto = getSearchModelDTO();
        dto.setIdentifier(null);
        try {
            return mapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getSearchModelWithInvalidIdentifier2() {
        ObjectMapper mapper = new ObjectMapper();
        SearchModelDTO dto = getSearchModelDTO();
        dto.setIdentifier(new ArrayList<Map<String, String>>());
        try {
            return mapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getSearchModelWithInvalidOrg1() {
        ObjectMapper mapper = new ObjectMapper();
        SearchModelDTO dto = getSearchModelDTO();
        dto.setRatingOrg("MLC");
        try {
            return mapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getSearchModelWithInvalidOrg2() {
        ObjectMapper mapper = new ObjectMapper();
        SearchModelDTO dto = getSearchModelDTO();
        dto.setRatingOrg(null);
        try {
            return mapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getSearchModelWithInvalidOrg3() {
        ObjectMapper mapper = new ObjectMapper();
        SearchModelDTO dto = getSearchModelDTO();
        dto.setRatingOrg("");
        try {
            return mapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getSearchModelWithInvalidSearchType1() {
        ObjectMapper mapper = new ObjectMapper();
        SearchModelDTO dto = getSearchModelDTO();
        dto.setSearchType("INVALID");
        try {
            return mapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }
}
