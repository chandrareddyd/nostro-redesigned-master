package com.dbs.daas.fitch.fixtures;


import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.ClientState;


public class ClientStateFixture {
    public static ClientState getClientState() {
        return new ClientState("TEST-APP"+ApiConstants.ID_SEPARATOR+"1487260800000", 0);
    }
}
