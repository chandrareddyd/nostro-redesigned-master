package com.dbs.daas.fitch.fixtures;

import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.BatchFile;

public class BatchFileFixture {
    public static BatchFile getBatchFileProcessed() {
    	long sixHours = 6 * 60 * 60 * 1000;
        long sixHoursAhead = System.currentTimeMillis() + sixHours;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM1234");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(sixHoursAhead + sixHoursAhead + 10);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_PROCESSED);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
    
    public static BatchFile getBatchFileInprogressBeforeHrs1() {
    	long twoHours = 2 * 60 * 60 * 1000;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM1234");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(System.currentTimeMillis() - twoHours);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_INPROGRESS);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
    
    public static BatchFile getBatchFileInprogressBeforeHrs2() {
    	long halfHour = 30 * 60 * 1000;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM1234");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(System.currentTimeMillis() - halfHour);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_INPROGRESS);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
    
    public static BatchFile getBatchFileInprogressAfterHrs1() {
    	long oneHour = 1 * 60 * 60 * 1000;
    	long halfHour = 30 * 60 * 1000;
        long sixHoursAhead = System.currentTimeMillis() + oneHour + halfHour;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM1234");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(sixHoursAhead);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_INPROGRESS);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
    
    public static BatchFile getBatchFileInprogressAfterHrs2() {
    	long halfHour = 30 * 60 * 1000;
        long sixHoursAhead = System.currentTimeMillis() + halfHour;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM1234");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(sixHoursAhead);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_INPROGRESS);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
    
    public static BatchFile getBatchFileMismatch() {
    	long sixHours = 6 * 60 * 60 * 1000;
        long sixHoursAhead = System.currentTimeMillis() + sixHours;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM12345");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(sixHoursAhead);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_MISMATCH);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
}
