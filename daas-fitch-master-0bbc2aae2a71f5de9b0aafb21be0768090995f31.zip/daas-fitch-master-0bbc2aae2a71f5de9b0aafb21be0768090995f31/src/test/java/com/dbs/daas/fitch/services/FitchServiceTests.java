package com.dbs.daas.fitch.services;

import static com.dbs.daas.fitch.model.ApiConstants.YYYYMMDD;
import static com.dbs.daas.fitch.util.CommonUtil.stringToDate;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;

import java.io.File;
import java.text.ParseException;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.daas.fitch.fixtures.SearchModelDTOFixture;
import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.EntityData;
import com.dbs.daas.fitch.model.SchemaModel;
import com.dbs.daas.fitch.model.SchemaModelDTO;
import com.dbs.daas.fitch.model.SearchModelDTO;
import com.dbs.daas.fitch.repositories.BatchFileRepository;
import com.dbs.daas.fitch.repositories.ClientStateRepository;
import com.dbs.daas.fitch.repositories.EntityDataRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FitchServiceTests {

	@Autowired
    private EntityDataRepository entityDataRepository;

	@Autowired
    private BatchFileRepository fileRepository;

	@Autowired
    private ClientStateRepository clientStateRepository;

	@Autowired
    private EntityDataService entityDataService;

	@Autowired
    private DataProcessingService dataProcessingService;

    @Autowired
    SchemaModelService schemaModelService;
    
    private Long timestampDate1;
    
    private Long timestampDate2;

    @Before
    public void setup() throws ParseException {
    	entityDataRepository.deleteAll();
    	fileRepository.deleteAll();
        clientStateRepository.deleteAll();
        
        timestampDate1 = stringToDate(YYYYMMDD, "20170217").getTime();
        
        timestampDate2 = stringToDate(YYYYMMDD, "20170215").getTime();
        
        //1485878400000 - 20170201
        //1488211200000 - 20170228
        //1487260800000 - 20170217
        //1487088000000 - 20170215
        
        // Hash values
        //1340055205 : 2015-12-30 18:06:03,10179,,,01010111,AUSTRALIA,80359689,Westpac Banking Corporation,2015-12-29 20:06:07,96229645,AUS,,,AU3FN0029898,,,,,,5,SR,AUD 100 mln Floating Rate Notes 30 Dec 2016,2016-12-30,,,AUD,100000000,Floating,,,,,,,,,1,1,Revision Rating,NR,,,,,,NR,,,,NR,,,,NR,,,,F1+,New Rating,2015-12-29 19:21:00,,NR,,,,NR,,,,NR,,,,NR,,,,1,20000,

        //32311861 : 2015-12-30 18:06:03,10179,,,01010111,AUSTRALIA,80359689,Westpac Banking Corporation,2015-12-29 20:06:06,88678268,AUS,,,XS0458569927,,045856992,,,,5,SR,GBP 650 mln 5% Notes 21 Oct 2019,2019-10-21,EMTN,,GBP,650000000,Fixed,5,,,,,,,,1,1,Revision Rating,AA-,Affirmed,2015-05-15 01:57:34,,,,NR,,,,NR,,,,NR,,,,NR,,,,NR,,,,NR,,,,NR,,,,NR,,,,1,20000,

    }

    @After
    public void tearDown() throws Exception {
    	entityDataRepository.deleteAll();
    	fileRepository.deleteAll();
        clientStateRepository.deleteAll();
    }

    private void ingestData(String srcFile, Integer fileIndex, String fileType, String frequeny, Long dateOfIngestion) throws Exception {  
    	File file = new File(this.getClass().getClassLoader().getResource(srcFile).getFile());
    	dataProcessingService.populateData(file, "xxxxxxx", fileIndex, fileType, frequeny, dateOfIngestion);
    }

    @Test
    public void testSavedDataCountforIssue() throws Exception {
        ingestData("RDSIssueReport.txt", 0, ApiConstants.FILE_TYPE_ISSUE, ApiConstants.DAILY, timestampDate1);

        assertThat(entityDataRepository.count(),equalTo(4305L));
    }

    @Test
    public void testSavedDataCountForIssuer() throws Exception {
        ingestData("RDSIssuerReport.txt", 2, ApiConstants.FILE_TYPE_ISSUER, ApiConstants.DAILY, timestampDate1);

        assertThat(entityDataRepository.count(),equalTo(7288L));
    }

    @Test
    public void testGetLatestDataEntity() throws Exception {
        ingestData("RDSIssueReport.txt", 0, ApiConstants.FILE_TYPE_ISSUE, ApiConstants.DAILY, timestampDate1);

        assertThat(entityDataRepository.count(),equalTo(4305L));

        Long latestDateOfIngestion = entityDataRepository.getLatestDataEntity();

        assertThat(latestDateOfIngestion, notNullValue());
    }

    @Test
    public void testGetAllByDateOfIngestion() throws Exception {
        ingestData("RDSIssueReport.txt", 0, ApiConstants.FILE_TYPE_ISSUE, ApiConstants.DAILY, timestampDate1);

        assertThat(entityDataRepository.count(),equalTo(4305L));

        List<String> data = entityDataRepository.getAllByDateOfIngestion(timestampDate1);

        assertThat(data, notNullValue());
        
        assertEquals(4305L, data.size());
    }

    @Test
    public void testGetAllByRecordHash() throws Exception {
        ingestData("RDSIssueReport.txt", 0, ApiConstants.FILE_TYPE_ISSUE, ApiConstants.DAILY, timestampDate1);

        assertThat(entityDataRepository.count(),equalTo(4305L));

        EntityData entityData = entityDataRepository.getAllByRecordHash(1340055205);

        assertThat(entityData, notNullValue());
        
        assertThat(entityData.getDateOfIngestion(), notNullValue());

    }

    @Test
    public void testGetData_with_page_minus_1() throws Exception {
    	
        ingestData("RDSIssueReport.txt", 0, ApiConstants.FILE_TYPE_ISSUE, ApiConstants.DAILY, timestampDate1);
        
        SchemaModelDTO dto = new SchemaModelDTO();
        dto.setAppName("daas-fitch-test");
        dto.setModel(null);
        dto.setTopicName(null);
        dto.setUriConn(null);

        schemaModelService.save(dto);

        SchemaModel model = schemaModelService.get("daas-fitch-test");

        String returnedData = entityDataService.getData(model, timestampDate1, "N", -1, 100);

        assertThat(returnedData,notNullValue());

        JSONObject jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("batchDate"), equalTo("20170217"));

        assertThat(jsonObject.get("totalElements"), equalTo(4305));

    }

    @Test
    public void testGetData_with_replay_Y() throws Exception {
    	
        ingestData("RDSIssueReport.txt", 0, ApiConstants.FILE_TYPE_ISSUE, ApiConstants.DAILY, timestampDate1);
        
        SchemaModelDTO dto = new SchemaModelDTO();
        dto.setAppName("daas-fitch-test");
        dto.setModel(null);
        dto.setTopicName(null);
        dto.setUriConn(null);

        schemaModelService.save(dto);

        SchemaModel model = schemaModelService.get("daas-fitch-test");

        String returnedData = entityDataService.getData(model, timestampDate1, "Y", 2, 100);

        assertThat(returnedData,notNullValue());

        JSONObject jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("batchDate"), equalTo("20170217"));

        assertThat(jsonObject.get("totalElements"), equalTo(4305));

    }

    @Test
    public void testPageConsistency() throws Exception {
    	
        ingestData("RDSIssueReport.txt", 0, ApiConstants.FILE_TYPE_ISSUE, ApiConstants.DAILY, timestampDate1);
        
        SchemaModelDTO dto = new SchemaModelDTO();
        dto.setAppName("daas-fitch-test-consistency");
        dto.setModel(null);
        dto.setTopicName(null);
        dto.setUriConn(null);

        schemaModelService.save(dto);

        SchemaModel model = schemaModelService.get("daas-fitch-test-consistency");

        String returnedData0 = entityDataService.getData(model,timestampDate1,"N", 1, 200);

        assertThat(returnedData0, notNullValue());

        JSONObject jsonObject = new JSONObject(returnedData0);

        assertThat(jsonObject.get("batchDate"),equalTo("20170217"));

        assertThat(jsonObject.get("totalElements"),equalTo(4305));
        
        assertThat(jsonObject.get("pageNumber"), equalTo(1));

        String returnedData1 = entityDataService.getData(model,timestampDate1,"N", 1, 200);

        JSONObject jsonObject1 = new JSONObject(returnedData1);

        assertThat(jsonObject1.get("pageNumber"), equalTo(1));

        assertThat((jsonObject.get("content")).toString(),equalToIgnoringCase((jsonObject1.get("content")).toString()));

    }
    
    @Test
    public void testGetData_with_Different_BatchDate() throws Exception {

        SchemaModelDTO dto = new SchemaModelDTO();
        dto.setAppName("daas-fitch-test");
        dto.setModel(null);
        dto.setTopicName(null);
        dto.setUriConn(null);

        schemaModelService.save(dto);

        SchemaModel model = schemaModelService.get("daas-fitch-test");		
    	
        ingestData("RDSIssueReport.txt", 0, ApiConstants.FILE_TYPE_ISSUE, ApiConstants.DAILY, timestampDate1); // ingest data for 20170217

        String returnedData = entityDataService.getData(model,timestampDate1,"N",-1,100); // get page 0

        assertThat(returnedData,notNullValue());

        JSONObject jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("batchDate"),equalTo("20170217"));

        assertThat(jsonObject.get("totalElements"),equalTo(4305));

        returnedData = entityDataService.getData(model,timestampDate1,"N",-1,100); // get page 1

        assertThat(returnedData,notNullValue());

        jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(1));

        assertThat(jsonObject.get("batchDate"),equalTo("20170217"));

        assertThat(jsonObject.get("totalElements"),equalTo(4305));

        returnedData = entityDataService.getData(model,timestampDate1,"N",-1,100); // get page 2

        assertThat(returnedData,notNullValue());

        jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(2));

        assertThat(jsonObject.get("batchDate"),equalTo("20170217"));

        assertThat(jsonObject.get("totalElements"),equalTo(4305));
    	
        ingestData("RDSIssuerReport.txt", 2, ApiConstants.FILE_TYPE_ISSUER, ApiConstants.DAILY, timestampDate2); // ingest data for 20170215

        returnedData = entityDataService.getData(model,timestampDate2,"N",-1,100); // get page 0

        assertThat(returnedData,notNullValue());

        jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("batchDate"),equalTo("20170215"));

        assertThat(jsonObject.get("totalElements"),equalTo(7288));

    }

    @Test
    public void testGetRatings_all() throws Exception {
        ingestData("RDSIssuerReport.txt", 2, ApiConstants.FILE_TYPE_ISSUER, ApiConstants.DAILY, timestampDate1);

        assertThat(entityDataRepository.count(),equalTo(7288L));
        
        SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
        
        dto.setSearchType(ApiConstants.SEARCH_TYPE_ALL);
        
        String returnedData = entityDataService.getRatings(dto, 0, 2);

        assertThat(returnedData, notNullValue());
        
        JSONObject jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("numberOfElements"),equalTo(2));

        assertThat(jsonObject.get("totalElements"), equalTo(2));  
        
        JSONArray content = jsonObject.getJSONArray("content");

        assertThat(content, notNullValue());
        
        for(int i = 0; i < content.length(); i++) {        	
        	JSONObject ratingObj = content.getJSONObject(i);
        	JSONArray ratings = ratingObj.getJSONArray(ApiConstants.COL_RATINGS);
            assertThat(ratings, notNullValue());
        }
    }

    @Test
    public void testGetRatings_latest() throws Exception {
        ingestData("RDSIssuerReport.txt", 2, ApiConstants.FILE_TYPE_ISSUER, ApiConstants.DAILY, timestampDate1);

        assertThat(entityDataRepository.count(),equalTo(7288L));
        
        String returnedData = entityDataService.getRatings(SearchModelDTOFixture.getSearchModelDTO(), 0, 2);

        assertThat(returnedData, notNullValue());
        
        JSONObject jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("numberOfElements"),equalTo(2));

        assertThat(jsonObject.get("totalElements"), equalTo(2));
        
        JSONArray content = jsonObject.getJSONArray("content");

        assertThat(content, notNullValue());
        
        for(int i = 0; i < content.length(); i++) {        	
        	JSONObject ratingObj = content.getJSONObject(i);
        	JSONArray ratings = ratingObj.getJSONArray(ApiConstants.COL_RATINGS);
            assertThat(ratings, notNullValue());
        }

    }

    @Test
    public void testGetRatings_Pagination() throws Exception {
        ingestData("RDSIssuerReport.txt", 2, ApiConstants.FILE_TYPE_ISSUER, ApiConstants.DAILY, timestampDate1);

        assertThat(entityDataRepository.count(),equalTo(7288L));
        
        String returnedData = entityDataService.getRatings(SearchModelDTOFixture.getSearchModelDTO(), 0, 1);

        assertThat(returnedData, notNullValue());
        
        JSONObject jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("numberOfElements"),equalTo(1));

        assertThat(jsonObject.get("totalElements"), equalTo(2));
        
        returnedData = entityDataService.getRatings(SearchModelDTOFixture.getSearchModelDTO(), 1, 1);

        assertThat(returnedData, notNullValue());
        
        jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(1));

        assertThat(jsonObject.get("numberOfElements"),equalTo(1));

        assertThat(jsonObject.get("totalElements"), equalTo(2));

    }

}
