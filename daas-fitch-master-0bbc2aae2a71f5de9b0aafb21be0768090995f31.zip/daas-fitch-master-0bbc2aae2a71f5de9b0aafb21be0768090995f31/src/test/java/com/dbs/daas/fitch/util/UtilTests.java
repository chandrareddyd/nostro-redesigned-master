package com.dbs.daas.fitch.util;


import static com.dbs.daas.fitch.util.CommonUtil.decrypt;
import static com.dbs.daas.fitch.util.CommonUtil.encrypt;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.junit.Test;

import com.dbs.daas.fitch.exception.APIException;
import com.dbs.daas.fitch.model.ApiConstants;


public class UtilTests {

    @Test
    public void encryptTest() throws APIException {
        String plainText = "testing";
        String encryptedText = encrypt(plainText);
        assertNotNull(encryptedText);
        assertNotEquals(plainText, encryptedText);
    }

    @Test
    public void dencryptTest() throws APIException {
        String plainText = "testing";
        String encryptedText = encrypt(plainText);
        String dencryptedText = decrypt(encryptedText);
        assertNotNull(dencryptedText);
        assertEquals(plainText, dencryptedText);
    }

    @Test
    public void dateFormatterTest1() {
        String date = CommonUtil.dateFormatter(ApiConstants.YYYYMMDD);
        assertNotNull(date);
    }

    @Test
    public void dateFormatterTest2() {
        String date = CommonUtil.dateFormatter(ApiConstants.YYYYMMDD, new Date());
        assertNotNull(date);
    }

    @Test
    public void dateFormatterTest3() {
        Date date = CommonUtil.dateFormatter(System.currentTimeMillis());
        assertNotNull(date);
    }

    @Test
    public void stringToDateTest() throws ParseException {
        Date date = CommonUtil.stringToDate(ApiConstants.YYYYMMDD, "20170101");
        assertNotNull(date);
    }

    @Test
    public void testChecksum() throws Exception {

        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("application.properties");
        SCPUtils scpUtils = new SCPUtils();
        String result = scpUtils.checksumLocalFile(inputStream);
        assertNotNull(result);
    }
}