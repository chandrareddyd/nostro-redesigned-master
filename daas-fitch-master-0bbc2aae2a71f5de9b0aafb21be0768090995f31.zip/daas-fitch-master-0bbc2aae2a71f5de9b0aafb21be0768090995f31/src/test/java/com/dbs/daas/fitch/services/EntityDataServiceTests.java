package com.dbs.daas.fitch.services;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.geode.cache.query.internal.StructImpl;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.dbs.daas.fitch.config.RatingSearchConfig;
import com.dbs.daas.fitch.exception.APIException;
import com.dbs.daas.fitch.fixtures.ClientStateFixture;
import com.dbs.daas.fitch.fixtures.EntityDataFixture;
import com.dbs.daas.fitch.fixtures.SchemaModelFixture;
import com.dbs.daas.fitch.fixtures.SearchModelDTOFixture;
import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.ClientState;
import com.dbs.daas.fitch.model.EntityData;
import com.dbs.daas.fitch.model.SchemaModel;
import com.dbs.daas.fitch.model.SearchModelDTO;
import com.dbs.daas.fitch.repositories.EntityDataRepository;
import com.dbs.daas.fitch.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;

public class EntityDataServiceTests {

	
	private RatingSearchConfig ratingSearchConfig;
	 
    @Mock
    private EntityDataRepository entityDataRepository;
    
    @Mock
    private ClientStateService clientStateService;
    
    private EntityDataService service;
    
    private Long today;
    
    private SchemaModel schemaModel;

    @Before
    public void setup() throws ParseException {
        MockitoAnnotations.initMocks(this);
        
        ratingSearchConfig = new RatingSearchConfig();
        
        Map<String, String> RATING_TYPE_CODES = new TreeMap<>();
		RATING_TYPE_CODES.put("LT_IDR", "LONG_TERM_ISSUER_DEFAULT_RATING");
		RATING_TYPE_CODES.put("LT_ISSUER", "LONG_TERM_ISSUER_RATING");
		RATING_TYPE_CODES.put("ST_IDR", "SHORT_TERM_ISSUER_DEFAULT_RATING");
		RATING_TYPE_CODES.put("ST_ISSUER", "SHORT_TERM_ISSUER_RATING");
		RATING_TYPE_CODES.put("INDIVIDUAL", "BANK_INDIVIDUAL_RATING");
		RATING_TYPE_CODES.put("SUPPORT", "BANK_SUPPORT_RATING");
		ratingSearchConfig.setRatingTypeCodes(RATING_TYPE_CODES);
		
		Map<String, String> RATING_TYPES = new TreeMap<>();
		RATING_TYPES.put("LT_IDR", "Long-Term Issuer Default Rating");
		RATING_TYPES.put("LT_ISSUER", "Long-Term Issuer Rating");
		RATING_TYPES.put("ST_IDR", "Short-Term Issuer Default Rating");
		RATING_TYPES.put("ST_ISSUER", "Short-Term Issuer Rating");
		RATING_TYPES.put("INDIVIDUAL", "Bank Individual Rating");
		RATING_TYPES.put("SUPPORT", "Bank Support Rating");
		ratingSearchConfig.setRatingTypeDescription(RATING_TYPES);
		
		Map<String, Set<String>> RATING_TYPE_COL_MAPPINGS = new TreeMap<>();
		RATING_TYPE_COL_MAPPINGS.put("LT_IDR", new TreeSet<>(Arrays.asList(new String[]{"LONG_TERM_ISSUER_DEFAULT_RATING","LT_IDR_EFFECTIVE_DATE","LT_IDR_ACTION"})));
		RATING_TYPE_COL_MAPPINGS.put("LT_ISSUER", new TreeSet<>(Arrays.asList(new String[]{"LONG_TERM_ISSUER_RATING","LT_ISSUER_RATING_EFFECTIVE_DATE","LT_ISSUER_RATING_ACTION"})));
		RATING_TYPE_COL_MAPPINGS.put("ST_IDR", new TreeSet<>(Arrays.asList(new String[]{"SHORT_TERM_ISSUER_DEFAULT_RATING","ST_IDR_EFFECTIVE_DATE","ST_IDR_ACTION"})));
		RATING_TYPE_COL_MAPPINGS.put("ST_ISSUER", new TreeSet<>(Arrays.asList(new String[]{"SHORT_TERM_ISSUER_RATING","ST_ISSUER_RATING_EFFECTIVE_DATE","ST_ISSUER_RATING_ACTION"})));
		RATING_TYPE_COL_MAPPINGS.put("INDIVIDUAL", new TreeSet<>(Arrays.asList(new String[]{"BANK_INDIVIDUAL_RATING","BANK_INDIVIDUAL_RATING_EFFECTIVE_DATE","BANK_INDIVIDUAL_RATING_ACTION"})));
		RATING_TYPE_COL_MAPPINGS.put("SUPPORT", new TreeSet<>(Arrays.asList(new String[]{"BANK_SUPPORT_RATING","BANK_SUPPORT_RATING_EFFECTIVE_DATE","BANK_SUPPORT_RATING_ACTION"})));
		ratingSearchConfig.setRatingTypeColumnMapping(RATING_TYPE_COL_MAPPINGS);
		
		Map<String, String> IDENTIFER_TYPES = new TreeMap<>();
		IDENTIFER_TYPES.put("FITCH_ID", "AGENT_COMMON_ID");
		ratingSearchConfig.setIdentifierTypes(IDENTIFER_TYPES);
    	
    	ratingSearchConfig.setRatingValueColumns(new TreeSet<>(Arrays.asList(new String[]{"LONG_TERM_ISSUER_DEFAULT_RATING","LONG_TERM_ISSUER_RATING","SHORT_TERM_ISSUER_DEFAULT_RATING","SHORT_TERM_ISSUER_RATING","BANK_INDIVIDUAL_RATING","BANK_SUPPORT_RATING"})));
        ratingSearchConfig.setRatingDateColumns(new TreeSet<>(Arrays.asList(new String[]{"LT_IDR_EFFECTIVE_DATE","LT_ISSUER_RATING_EFFECTIVE_DATE","ST_IDR_EFFECTIVE_DATE","ST_ISSUER_RATING_EFFECTIVE_DATE","BANK_INDIVIDUAL_RATING_EFFECTIVE_DATE","BANK_SUPPORT_RATING_EFFECTIVE_DATE"})));
        ratingSearchConfig.setRatingActionColumns(new TreeSet<>(Arrays.asList(new String[]{"LT_IDR_ACTION","LT_ISSUER_RATING_ACTION","ST_IDR_ACTION","ST_ISSUER_RATING_ACTION","BANK_INDIVIDUAL_RATING_ACTION","BANK_SUPPORT_RATING_ACTION"})));
        
        service = new EntityDataService(entityDataRepository, clientStateService, ratingSearchConfig);
        
        today = CommonUtil.stringToDate(ApiConstants.YYYYMMDD, CommonUtil.dateFormatter(ApiConstants.YYYYMMDD)).getTime();
        
        schemaModel = SchemaModelFixture.getSchemaModel();
        
        //1487260800000 - 17022017
        //1487088000000 - 15022017
    }

	@Test
	public void getLatestDataEntityTest() {
		when(entityDataRepository.findAll()).thenReturn(EntityDataFixture.getEntityData());
		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0).getDateOfIngestion());
		Long latestDateOfIngestion = service.getLatestDataEntity();
		assertNotNull(latestDateOfIngestion);
	}
	
	@Test
	public void getDataWithNullSchemaModel() throws IOException, NumberFormatException, APIException, JSONException {	
		String json = service.getData(null, null, "N", 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("remarks"));
	}
	
	@Test
	public void getDataWithNullSchemaModelFields() throws IOException, NumberFormatException, APIException, JSONException {	
		SchemaModel tmpSchemaModel = SchemaModelFixture.getSchemaModel();
		tmpSchemaModel.setModel(null);
		String json = service.getData(tmpSchemaModel, null, "N", 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("remarks"));
	}
	
	@Test
	public void getDataWithEmptySchemaModelFields() throws IOException, NumberFormatException, APIException, JSONException {	
		SchemaModel tmpSchemaModel = SchemaModelFixture.getSchemaModel();
		tmpSchemaModel.setModel(new ArrayList<String>());
		String json = service.getData(tmpSchemaModel, null, "N", 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("remarks"));
	}
	
	@Test
	public void getDataWithTodaysDateAndAvailableData() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.isDataLoaded(anyLong())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(EntityDataFixture.getEntityDataIds());
		when(entityDataRepository.findOne(anyString())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, today, "N", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
        verify(clientStateService, Mockito.times(1)).save(any(ClientState.class));
	}
	
	@Test
	public void getDataWithTodaysDateAndAvailableDataAndAvailableClientState() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(ClientStateFixture.getClientState());
		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0).getDateOfIngestion());
		when(entityDataRepository.isDataLoaded(anyLong())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(EntityDataFixture.getEntityDataIds());
		when(entityDataRepository.findOne(anyString())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, 1451232000000L, "N", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(1, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
        verify(clientStateService, Mockito.times(1)).save(any(ClientState.class));
	}
	
	@Test
	public void getDataWithTodaysDateAndAvailableDataAndAvailableClientStateAndNoLatestDate() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(ClientStateFixture.getClientState());
		when(entityDataRepository.getLatestDataEntity()).thenReturn(null);
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(EntityDataFixture.getEntityDataIds());
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, 1451232000000L, "N", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("remarks"));
	}
	
	@Test
	public void getDataWithTodaysDateAndLatestData() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0).getDateOfIngestion());
		when(entityDataRepository.isDataLoaded(anyLong())).thenReturn(null);
		when(entityDataRepository.count()).thenReturn(10L);
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(EntityDataFixture.getEntityDataIds());
		when(entityDataRepository.findOne(anyString())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, today, "N", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
        verify(clientStateService, Mockito.times(1)).save(any(ClientState.class));
	}
	
	@Test
	public void getDataWithTodaysDateAndNoLatestData() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.getLatestDataEntity()).thenReturn(null);
		when(entityDataRepository.isDataLoaded(anyLong())).thenReturn(null);
		when(entityDataRepository.count()).thenReturn(10L);
		String json = service.getData(schemaModel, today, "N", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("remarks"));
	}
	
	@Test
	public void getDataWithTodaysDateAndNoData1() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0).getDateOfIngestion());
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(null).thenReturn(null);
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, today, "N", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("remarks"));
	}
	
	@Test
	public void getDataWithTodaysDateAndNoData2() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0).getDateOfIngestion());
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(null).thenReturn(new ArrayList<String>());
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, today, "N", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("remarks"));
	}
	
	@Test
	public void getDataWithTodaysDateAndNoDataAndNoLatest() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.getLatestDataEntity()).thenReturn(null);
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(null).thenReturn(EntityDataFixture.getEntityDataIds());
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, today, "N", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("remarks"));
	}
	
	@Test
	public void getDataWithNoTodaysDateAndNoAvailableData() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(null).thenReturn(EntityDataFixture.getEntityDataIds());
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, 1487260800000L, "N", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
	}
	
	@Test
	public void getDataWithNoTodaysDateAndAvailableData() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.isDataLoaded(anyLong())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(EntityDataFixture.getEntityDataIds().subList(0,  2));
		when(entityDataRepository.findOne(anyString())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, 1487260800000L, "A", -10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
        verify(clientStateService, Mockito.times(1)).save(any(ClientState.class));
	}
	
	@Test
	public void getDataWithNoTodaysDateAndAvailableDataWithMaxPage() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.isDataLoaded(anyLong())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(EntityDataFixture.getEntityDataIds());
		when(entityDataRepository.findOne(anyString())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = service.getData(schemaModel, 1487260800000L, "N", 3, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(2, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(1, jsonObject.get("numberOfElements"));
        verify(clientStateService, Mockito.times(1)).save(any(ClientState.class));
	}
	
	@Test(expected = APIException.class)
	public void getDataWithFailedClientStateSave() throws JsonProcessingException, APIException, JSONException {
		when(clientStateService.get(anyString())).thenReturn(null);
		when(entityDataRepository.isDataLoaded(anyLong())).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(entityDataRepository.getAllByDateOfIngestion(anyLong())).thenReturn(EntityDataFixture.getEntityDataIds());
		when(clientStateService.save(any(ClientState.class))).thenReturn(false);
		String json = service.getData(schemaModel, 1487260800000L, "N", 3, 2);
		JSONObject jsonObject = new JSONObject(json);
        verify(clientStateService, Mockito.times(1)).save(any(ClientState.class));
	}
	
	@Test
	public void getRatingsWithNoSearchModel() throws JsonProcessingException, APIException, JSONException {
		String json = service.getRatings(null, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
	}
	
	@Test
	public void getRatingsWithSearchModel() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());
		String json = service.getRatings(SearchModelDTOFixture.getSearchModelDTO(), 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelMaxPages() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());

		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
        List<Map<String, String>> identifiers = new ArrayList<>();        
        Map<String, String> identifier = new HashMap<>();
        identifier.put(ApiConstants.ID_TYPE, "FITCH_ID");
        identifier.put(ApiConstants.ID_VALUE, "11829");
        identifiers.add(identifier);
        dto.setIdentifier(identifiers);
		String json = service.getRatings(dto, 10, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(1, jsonObject.get("numberOfElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndNullRatingType() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		dto.setRatingTypes(null);
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndEmptyRatingType() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		dto.setRatingTypes(new ArrayList<String>());
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndInvalidIdentifier() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		List<Map<String, String>> identifiers = new ArrayList<>();
		Map<String, String> identifier = new HashMap<>();
        identifier.put(ApiConstants.ID_TYPE, "MLC");
        identifiers.add(identifier);
		dto.setIdentifier(identifiers);
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndInvalidIdentifierNoIdType() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		List<Map<String, String>> identifiers = new ArrayList<>();
		Map<String, String> identifier = new HashMap<>();
        identifiers.add(identifier);
		dto.setIdentifier(identifiers);
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndNullData() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(null);
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		dto.setRatingTypes(new ArrayList<String>());
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndEmptyData() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(new ArrayList<StructImpl>());
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		dto.setRatingTypes(new ArrayList<String>());
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndEmptyRatingTypes() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		dto.setRatingTypes(new ArrayList<String>());
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndInvalidRatingTypes() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		dto.setRatingTypes(Arrays.asList(new String[]{"LT_IDR", "INVALID"}));
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndSearchTypeAll() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		dto.setSearchType(ApiConstants.SEARCH_TYPE_ALL);
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("pageNumber"));
		assertEquals(0, jsonObject.get("pageNumber"));
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
	}
	
	@Test
	public void getRatingsWithSearchModelAndSearchTypeInvalid() throws JsonProcessingException, APIException, JSONException {
		when(entityDataRepository.searchByAgentCommonId(anyString())).thenReturn(EntityDataFixture.getRatingData());
		SearchModelDTO dto = SearchModelDTOFixture.getSearchModelDTO();
		dto.setSearchType("");
		String json = service.getRatings(dto, 0, 2);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalPages"));
		assertEquals(0, jsonObject.get("totalPages"));
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
	}
}