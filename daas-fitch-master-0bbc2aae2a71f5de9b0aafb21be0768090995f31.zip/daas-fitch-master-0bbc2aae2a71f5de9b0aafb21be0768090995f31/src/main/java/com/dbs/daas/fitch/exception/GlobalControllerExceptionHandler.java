package com.dbs.daas.fitch.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
public class GlobalControllerExceptionHandler extends ResponseEntityExceptionHandler {
    private static final Logger LOG = LoggerFactory.getLogger(GlobalControllerExceptionHandler.class);

    @ResponseBody
    @ExceptionHandler(Throwable.class)
    ResponseEntity<ErrorMessage> handleThrowable(HttpServletRequest request, Throwable ex) {
        HttpStatus status = getStatus(request, ex);
        LOG.error(ex.getMessage(), ex);
        return new ResponseEntity<>(new ErrorMessage(status.value(), ex.getMessage()), status);
    }

    private HttpStatus getStatus(HttpServletRequest request, Throwable ex) {
        Integer statusCode;
        if (ex instanceof APIException && null != ((APIException) ex).getStatusCode()) {
            statusCode = ((APIException) ex).getStatusCode();
        } else {
            statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        }
        if (null == statusCode) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return HttpStatus.valueOf(statusCode);
    }
}
