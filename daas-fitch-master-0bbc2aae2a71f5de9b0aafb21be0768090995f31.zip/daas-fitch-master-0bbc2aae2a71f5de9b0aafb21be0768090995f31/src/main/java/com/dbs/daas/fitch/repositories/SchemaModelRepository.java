package com.dbs.daas.fitch.repositories;


import org.springframework.data.gemfire.repository.GemfireRepository;
import org.springframework.stereotype.Repository;

import com.dbs.daas.fitch.model.SchemaModel;

@Repository
public interface SchemaModelRepository extends GemfireRepository<SchemaModel, String> {


}
