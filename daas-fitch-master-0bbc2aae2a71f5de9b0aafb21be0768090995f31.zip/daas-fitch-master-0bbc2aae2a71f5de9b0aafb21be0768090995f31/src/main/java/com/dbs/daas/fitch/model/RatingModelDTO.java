package com.dbs.daas.fitch.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RatingModelDTO {
	
	@JsonProperty("RATING_TYPE")
    private String ratingType;
	
	@JsonProperty("RATING_VALUE")
    private String ratingValue;
	
	@JsonProperty("RATING_DATE")
    private String ratingDate;
	
	@JsonProperty("RATING_ACTION")
    private String ratingAction;

    public RatingModelDTO() {
    }

    public RatingModelDTO(String ratingType, String ratingValue, String ratingDate, String ratingAction) {
        this.ratingType = ratingType;
        this.ratingValue = ratingValue;
        this.ratingDate = ratingDate;
        this.ratingAction = ratingAction;
    }

}
