package com.dbs.daas.fitch.config;

import org.apache.geode.cache.client.ClientCache;
import org.apache.geode.cache.client.ClientCacheFactory;
import org.apache.geode.cache.client.ClientRegionShortcut;
import org.apache.geode.cache.query.QueryService;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.gemfire.client.ClientRegionFactoryBean;
import org.springframework.data.gemfire.repository.config.EnableGemfireRepositories;

import com.dbs.daas.fitch.model.BatchFile;
import com.dbs.daas.fitch.model.ClientState;
import com.dbs.daas.fitch.model.EntityData;
import com.dbs.daas.fitch.model.SchemaModel;

@RefreshScope
@Configuration
@Profile({ "local", "sit", "uat", "perf", "prod" })
@EnableGemfireRepositories(value = "com.dbs.daas.fitch.repositories")
public class GeodeClusterConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(GeodeClusterConfig.class);

	private static final String DEFAULT_GEMFIRE_LOG_LEVEL = "warning";

	private String applicationName() {
		return "daas-fitch::".concat(getClass().getSimpleName());
	}

	private String logLevel() {
		return DEFAULT_GEMFIRE_LOG_LEVEL;
	}

	@Bean
	public ClientCache geodeCache() {
		
		String locatorAddress = null;

		int locatorPort = 0;		
    	
    	String vcapServices = System.getenv("VCAP_SERVICES"); 
    	
    	try {

    	    if(vcapServices!=null && !vcapServices.isEmpty()) {
    	        JSONObject jsonObject = new JSONObject(vcapServices);
    	        JSONArray attributes = jsonObject.getJSONArray("user-provided");
    	        String locators = null;
    	        
    	        for(int i = 0; i < attributes.length(); i++) {     
        	        JSONObject service = attributes.getJSONObject(i);
        	        JSONObject credentials = service.getJSONObject("credentials");
        	        try {
        	        	locators = credentials.getString("locators");
        	        } catch (JSONException e) {
        	        	LOGGER.warn("'locators' key is not present in current object.", e);
        	        }
    	        }

    	        if(null != locators && !locators.isEmpty()) {
    	        	String[] locator = null;
    	        	if(locators.contains(",")) {
    	        		
        	        	String[] locatorArray = locators.split(",");        	        	
        	        	if(null != locatorArray && locatorArray.length > 0) {        	        		
            	        	locator = locatorArray[0].split(":");   	        		
        	        	}    	        		
    	        	} else {
    	        		locator = locators.split(":");
    	        	}
    	        	
    	        	if(null != locator && locator.length > 1) {
    	        		
        	        	locatorAddress = locator[0];
        	        	locatorPort = Integer.valueOf(locator[1]);    	        		
    	        	}    	        	
    	        } else {
    	        	LOGGER.error("locator details are not available....");
    	        }
    	    }
    	} catch (JSONException e) {
        	LOGGER.error("Error while parsing VCAP_SERVICES for geode locator information", e);
    	}

		return new ClientCacheFactory().addPoolLocator(locatorAddress, locatorPort).setPoolSubscriptionEnabled(true)
				.setPdxPersistent(true).setPoolReadTimeout(900000).setPoolIdleTimeout(-1)
				// .setPdxSerializer(new
				// ReflectionBasedAutoSerializer("com.dbs.daas.fitch.model"))
				.set("name", applicationName()).set("log-level", logLevel()).create();
	}

	@Bean
	public ClientRegionFactoryBean<String, EntityData> dataEntitiesRegion(ClientCache geodeCache) {
		ClientRegionFactoryBean<String, EntityData> clientRegionFactoryBean = new ClientRegionFactoryBean<>();
		clientRegionFactoryBean.setName("Fitch_DataEntities");
		clientRegionFactoryBean.setCache(geodeCache);
		clientRegionFactoryBean.setPersistent(false);
		clientRegionFactoryBean.setClose(false);
		clientRegionFactoryBean.setShortcut(ClientRegionShortcut.PROXY);
		return clientRegionFactoryBean;

	}

	@Bean
	public ClientRegionFactoryBean<String, SchemaModel> schemaModelPartitionedRegionFactoryBean(
			ClientCache geodeCache) {
		ClientRegionFactoryBean<String, SchemaModel> stringSchemaModelClientRegionFactoryBean = new ClientRegionFactoryBean<>();
		stringSchemaModelClientRegionFactoryBean.setName("Fitch_Schemas");
		stringSchemaModelClientRegionFactoryBean.setCache(geodeCache);
		stringSchemaModelClientRegionFactoryBean.setPersistent(false);
		stringSchemaModelClientRegionFactoryBean.setClose(false);
		stringSchemaModelClientRegionFactoryBean.setShortcut(ClientRegionShortcut.PROXY);
		return stringSchemaModelClientRegionFactoryBean;

	}

	@Bean
	public ClientRegionFactoryBean<String, BatchFile> batchFileClientRegionFactoryBean(ClientCache geodeCache) {
		ClientRegionFactoryBean<String, BatchFile> batchFileClientRegionFactoryBean = new ClientRegionFactoryBean<>();
		batchFileClientRegionFactoryBean.setName("Fitch_BatchFiles");
		batchFileClientRegionFactoryBean.setCache(geodeCache);
		batchFileClientRegionFactoryBean.setPersistent(false);
		batchFileClientRegionFactoryBean.setClose(false);
		batchFileClientRegionFactoryBean.setShortcut(ClientRegionShortcut.PROXY);
		return batchFileClientRegionFactoryBean;
	}

	@Bean
	public ClientRegionFactoryBean<String, ClientState> clientStateRegion(ClientCache geodeCache) {
		ClientRegionFactoryBean<String, ClientState> clientStateClientRegionFactoryBean = new ClientRegionFactoryBean<>();
		clientStateClientRegionFactoryBean.setName("Fitch_ClientState");
		clientStateClientRegionFactoryBean.setCache(geodeCache);
		clientStateClientRegionFactoryBean.setPersistent(false);
		clientStateClientRegionFactoryBean.setClose(false);
		clientStateClientRegionFactoryBean.setShortcut(ClientRegionShortcut.PROXY);
		return clientStateClientRegionFactoryBean;

	}

	@Bean
	public QueryService queryService(ClientCache gemfireCache) {
		return gemfireCache.getQueryService();
	}
}
