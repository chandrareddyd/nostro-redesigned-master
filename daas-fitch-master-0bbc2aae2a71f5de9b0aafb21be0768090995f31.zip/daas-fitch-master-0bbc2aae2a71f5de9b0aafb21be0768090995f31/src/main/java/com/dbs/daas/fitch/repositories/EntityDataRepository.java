package com.dbs.daas.fitch.repositories;


import java.util.List;

import org.apache.geode.cache.query.internal.StructImpl;
import org.springframework.data.gemfire.repository.GemfireRepository;
import org.springframework.data.gemfire.repository.Query;
import org.springframework.stereotype.Repository;

import com.dbs.daas.fitch.model.EntityData;


@Repository
public interface EntityDataRepository extends GemfireRepository<EntityData, String> {
	
	@Query("SELECT DISTINCT dateOfIngestion FROM /Fitch_DataEntities ORDER BY dateOfIngestion DESC LIMIT 1")
    Long getLatestDataEntity();
    
    @Query("SELECT * FROM /Fitch_DataEntities WHERE dateOfIngestion = $1 ORDER BY id ASC LIMIT 1")
    EntityData isDataLoaded(Long dateOfIngestion);
    
    @Query("SELECT id FROM /Fitch_DataEntities WHERE dateOfIngestion = $1 ORDER BY id ASC")
    List<String> getAllByDateOfIngestion(Long dateOfIngestion);
    
    
    @Query("SELECT * FROM /Fitch_DataEntities WHERE recordHash = $1")
    EntityData getAllByRecordHash(Integer recordHash);
    
    @Query("SELECT d.data['AGENT_COMMON_ID'] AS AGENT_COMMON_ID, "
    		+ "d.data['LONG_TERM_ISSUER_DEFAULT_RATING'] AS LONG_TERM_ISSUER_DEFAULT_RATING, d.data['LT_IDR_EFFECTIVE_DATE'] AS LT_IDR_EFFECTIVE_DATE, d.data['LT_IDR_ACTION'] AS LT_IDR_ACTION, "
    		+ "d.data['LONG_TERM_ISSUER_RATING'] AS LONG_TERM_ISSUER_RATING, d.data['LT_ISSUER_RATING_EFFECTIVE_DATE'] AS LT_ISSUER_RATING_EFFECTIVE_DATE, d.data['LT_ISSUER_RATING_ACTION'] AS LT_ISSUER_RATING_ACTION, "
    		+ "d.data['SHORT_TERM_ISSUER_DEFAULT_RATING'] AS SHORT_TERM_ISSUER_DEFAULT_RATING, d.data['ST_IDR_EFFECTIVE_DATE'] AS ST_IDR_EFFECTIVE_DATE, d.data['ST_IDR_ACTION'] AS ST_IDR_ACTION, "
    		+ "d.data['SHORT_TERM_ISSUER_RATING'] AS SHORT_TERM_ISSUER_RATING, d.data['ST_ISSUER_RATING_EFFECTIVE_DATE'] AS ST_ISSUER_RATING_EFFECTIVE_DATE, d.data['ST_ISSUER_RATING_ACTION'] AS ST_ISSUER_RATING_ACTION, "
    		+ "d.data['BANK_INDIVIDUAL_RATING'] AS BANK_INDIVIDUAL_RATING, d.data['BANK_INDIVIDUAL_RATING_EFFECTIVE_DATE'] AS BANK_INDIVIDUAL_RATING_EFFECTIVE_DATE, d.data['BANK_INDIVIDUAL_RATING_ACTION'] AS BANK_INDIVIDUAL_RATING_ACTION, "
    		+ "d.data['BANK_SUPPORT_RATING'] AS BANK_SUPPORT_RATING, d.data['BANK_SUPPORT_RATING_EFFECTIVE_DATE'] AS BANK_SUPPORT_RATING_EFFECTIVE_DATE, d.data['BANK_SUPPORT_RATING_ACTION'] AS BANK_SUPPORT_RATING_ACTION"
    		+ " FROM /Fitch_DataEntities d WHERE d.data['AGENT_COMMON_ID'] = $1 AND d.fileType = 'ISSUER'")
    List<StructImpl> searchByAgentCommonId(String agentCommonId);

}
