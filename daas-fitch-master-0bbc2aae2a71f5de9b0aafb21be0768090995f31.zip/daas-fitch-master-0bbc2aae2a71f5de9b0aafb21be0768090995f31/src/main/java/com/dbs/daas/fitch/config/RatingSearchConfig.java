package com.dbs.daas.fitch.config;

import java.util.Map;
import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@ConfigurationProperties(prefix = "rating")
@Component
public class RatingSearchConfig {
	
	private Map<String, String> ratingTypeCodes;
	
	private Map<String, String> ratingTypeDescription;
	
	private Map<String,  Set<String>> ratingTypeColumnMapping;
	
	private Map<String, String> identifierTypes;
	
	private Set<String> ratingValueColumns;
	
	private Set<String> ratingDateColumns;
	
	private Set<String> ratingActionColumns;

}
