package com.dbs.daas.fitch.controllers;


import static com.dbs.daas.fitch.util.CommonUtil.dateFormatter;
import static com.dbs.daas.fitch.util.CommonUtil.stringToDate;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.daas.fitch.exception.APIException;
import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.SchemaModel;
import com.dbs.daas.fitch.model.SchemaModelDTO;
import com.dbs.daas.fitch.model.SearchModelDTO;
import com.dbs.daas.fitch.services.EntityDataService;
import com.dbs.daas.fitch.services.SchemaModelService;
import com.fasterxml.jackson.core.JsonProcessingException;


@RequestMapping(value = "/fitch/v1")
@RestController
public class APIController implements SwaggerApi {
    private static final Logger LOGGER = LoggerFactory.getLogger(APIController.class);

	private SchemaModelService schemaModelService;
    private EntityDataService entityDataService;	

    @Autowired
    public APIController(SchemaModelService schemaModelService, EntityDataService entityDataService) {
    	this.schemaModelService = schemaModelService;
        this.entityDataService = entityDataService;
    }

    @Override
    public ResponseEntity<String> getData(
            @PathVariable("appName") String appName,
            @RequestParam(value = "timestamp", required = false) String timestamp, // yyyyMMdd
            @RequestParam(value = "replay", required = false, defaultValue = "N") String replay,
            @RequestParam(value = "page", required = false, defaultValue = "-1") Integer page,
            @RequestParam(value = "size", required = false, defaultValue = "50") Integer size) throws APIException, JsonProcessingException {
    	
    	long timestampDate;

        if(null == timestamp || timestamp.isEmpty()) {
            timestamp = dateFormatter(ApiConstants.YYYYMMDD, new Date());
        }
        
        try {

            timestampDate = stringToDate(ApiConstants.YYYYMMDD, timestamp).getTime();

        } catch (ParseException e) {
            LOGGER.error("Bad request. Invalid timestamp. Error - " + e.getMessage());
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }
        
        SchemaModel schemaModel = schemaModelService.get(appName);
        
        if (null == schemaModel) {
            LOGGER.error("Failed to find schema registration for app " + appName);
            throw new APIException(Integer.parseInt(HttpStatus.NOT_FOUND.toString()),
                    HttpStatus.NOT_FOUND.getReasonPhrase());
        } else {
            return new ResponseEntity<>(entityDataService.getData(schemaModel, timestampDate, replay, page, size), HttpStatus.OK);
        }
    }

    @Override
    public ResponseEntity<SchemaModelDTO> registerModel(@RequestBody SchemaModelDTO dto) throws APIException {
        
    	if (null == dto.getAppName()) {
            LOGGER.error("Bad request. Invalid schema model");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }
        
        SchemaModelDTO savedModel = schemaModelService.save(dto);
        
        if (null == savedModel) {
            LOGGER.error("Failed to save schema model");
            throw new APIException(Integer.parseInt(HttpStatus.INTERNAL_SERVER_ERROR.toString()),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
        }
        
        return new ResponseEntity<>(savedModel, HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<Map<String, String>> deleteModel(@PathVariable("appName") String appName) throws APIException {

        Map<String, String> responseMessage = new HashMap<>();
        responseMessage.put("status", "success");

        SchemaModel schemaModel = schemaModelService.get(appName);
        
        if (null == schemaModel) {
            LOGGER.error("Failed to find schema registration for app " + appName);
            throw new APIException(Integer.parseInt(HttpStatus.NOT_FOUND.toString()),
                    HttpStatus.NOT_FOUND.getReasonPhrase());
        } else {
            
        	Boolean isDeleted = schemaModelService.delete(appName);
            
        	if (null == isDeleted || !isDeleted) {
                LOGGER.error("Failed to delete schema by app name " + appName);
                throw new APIException(Integer.parseInt(HttpStatus.INTERNAL_SERVER_ERROR.toString()),
                        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
            }
        }
        
        return new ResponseEntity<>(responseMessage, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SchemaModel> getModel(@PathVariable(value = "modelName") String modelName) throws APIException {

        SchemaModel schemaModel = schemaModelService.get(modelName);
        
        if (null == schemaModel) {
            LOGGER.error("Failed to find schema " + modelName);
            throw new APIException(Integer.parseInt(HttpStatus.NOT_FOUND.toString()),
                    HttpStatus.NOT_FOUND.getReasonPhrase());
        } else {
            return new ResponseEntity<>(schemaModel, HttpStatus.OK);
        }

    }


    public ResponseEntity<String> searchRatings(
    		@RequestBody SearchModelDTO dto,
            @RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
            @RequestParam(value = "size", required = false, defaultValue = "50") Integer size) throws APIException, JsonProcessingException {
    	if (null == dto.getRatingOrg() || dto.getRatingOrg().isEmpty() || !ApiConstants.SERVICE_NAME.equalsIgnoreCase(dto.getRatingOrg())) {
            LOGGER.error("Bad request. Invalid search rating organization");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }
    	if (null == dto.getIdentifier() || dto.getIdentifier().isEmpty()) {
            LOGGER.error("Bad request. Invalid search identifer");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }
    	if(!ApiConstants.SEARCH_TYPE_ALL.equalsIgnoreCase(dto.getSearchType()) && !ApiConstants.SEARCH_TYPE_LATEST.equalsIgnoreCase(dto.getSearchType())) {
        	LOGGER.error("Bad request. Invalid search type");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }
        return new ResponseEntity<>(entityDataService.getRatings(dto, page, size), HttpStatus.OK);
    }


    @Override
    public ResponseEntity<String> searchRatings(@PathVariable String fitchIds) throws APIException, JsonProcessingException {
        if(StringUtils.isBlank(fitchIds)){
            LOGGER.error("Bad request. Invalid fitchIds");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }

        List<String> fitchIdArray = Arrays.asList(fitchIds.split(","));

        List<Map<String, String>> identifier = new ArrayList<>();
        fitchIdArray.stream().filter(fitchId -> StringUtils.isNotBlank(fitchId) ).forEach(fitchId ->{
            Map<String, String> tmpMap = new HashMap<>();
            tmpMap.put(ApiConstants.ID_TYPE, "FITCH_ID");
            tmpMap.put(ApiConstants.ID_VALUE, fitchId.trim());

            identifier.add(tmpMap);
        });

        if (CollectionUtils.isEmpty(identifier)) {
            LOGGER.error("Bad request. Invalid search identifer");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }

        int page = 0;
        int size = Integer.MAX_VALUE;

        SearchModelDTO dto = new SearchModelDTO();
        dto.setRatingOrg(ApiConstants.SERVICE_NAME);
        dto.setSearchType(ApiConstants.SEARCH_TYPE_LATEST);
        dto.setRatingTypes(new ArrayList<String>());
        dto.setIdentifier(identifier);

        return new ResponseEntity<>(entityDataService.getRatings(dto, page, size), HttpStatus.OK);
    }


}
