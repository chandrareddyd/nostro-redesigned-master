package com.dbs.daas.fitch.model;

import org.apache.geode.pdx.PdxReader;
import org.apache.geode.pdx.PdxSerializable;
import org.apache.geode.pdx.PdxWriter;
import org.springframework.data.annotation.Id;
import org.springframework.data.gemfire.mapping.Region;

import lombok.Data;

import java.util.Arrays;
import java.util.List;

@Region("Fitch_Schemas")
@Data
public class SchemaModel implements PdxSerializable {

    @Id
    /** client that register schema model*/
    private String appName;

    /**
     * list of fields that represents the schema model
     */
    private List<String> model;

    /**
     * Queue name
     */
    private String topicName;

    /**
     * Host for Queue
     */
    private String mqHost;

    /**
     * Port for Queue
     */
    private int mqPort;

    /**
     * Username for Queue
     */
    private String mqUsername;

    /**
     * Password for Queue
     */
    private String mqPassword;

    /**
     * Virtual Host for Queue
     */
    private String mqVirtualHost;

    public SchemaModel() {
    }

    public SchemaModel(String appName, List<String> model, String topicName, String mqHost, int mqPort, String mqUsername, String mqPassword, String mqVirtualHost) {
        this.appName = appName;
        this.model = model;
        this.topicName = topicName;
        this.mqHost = mqHost;
        this.mqPort = mqPort;
        this.mqUsername = mqUsername;
        this.mqPassword = mqPassword;
        this.mqVirtualHost = mqVirtualHost;
    }

    

    @Override
    public void toData(PdxWriter pdxWriter) {
        pdxWriter.writeString("appName", this.appName);

        String[] modelArray = new String[this.model.size()];
        modelArray = this.model.toArray(modelArray);
        pdxWriter.writeStringArray("model", modelArray);
        pdxWriter.writeString("topicName", this.topicName);
        pdxWriter.writeString("mqHost", this.mqHost);
        pdxWriter.writeInt("mqPort", this.mqPort);
        pdxWriter.writeString("mqUsername", this.mqUsername);
        pdxWriter.writeString("mqPassword", this.mqPassword);
        pdxWriter.writeString("mqVirtualHost", this.mqVirtualHost);
    }

    @Override
    public void fromData(PdxReader pdxReader) {
        this.appName = pdxReader.readString("appName");
        this.model = Arrays.asList(pdxReader.readStringArray("model"));
        this.topicName = pdxReader.readString("topicName");
        this.mqHost = pdxReader.readString("mqHost");
        this.mqPort = pdxReader.readInt("mqPort");
        this.mqUsername = pdxReader.readString("mqUsername");
        this.mqPassword = pdxReader.readString("mqPassword");
        this.mqVirtualHost = pdxReader.readString("mqVirtualHost");
    }


    
}
