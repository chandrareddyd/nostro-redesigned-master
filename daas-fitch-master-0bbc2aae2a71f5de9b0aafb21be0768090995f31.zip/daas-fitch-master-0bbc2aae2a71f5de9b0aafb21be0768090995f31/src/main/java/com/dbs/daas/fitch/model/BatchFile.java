package com.dbs.daas.fitch.model;

import org.apache.geode.pdx.PdxReader;
import org.apache.geode.pdx.PdxSerializable;
import org.apache.geode.pdx.PdxWriter;
import org.springframework.data.annotation.Id;
import org.springframework.data.gemfire.mapping.Region;

import lombok.Data;

/**
 * Created by carlos on 1/25/17.
 */
@Region("Fitch_BatchFiles")
@Data
public class BatchFile implements PdxSerializable {

    @Id
    private String checksum;

    private String fileSource;

    private Long datetime;

    private String status;

    private String batchId;

    @Override
    public void toData(PdxWriter pdxWriter) {
        pdxWriter.writeString("checksum",this.checksum);
        pdxWriter.writeLong("datetime",this.datetime);
        pdxWriter.writeString("fileSource",this.fileSource);
        pdxWriter.writeString("status",this.status);
        pdxWriter.writeString("batchId",this.batchId);
    }

    @Override
    public void fromData(PdxReader pdxReader) {
        this.checksum = pdxReader.readString("checksum");
        this.datetime = pdxReader.readLong("datetime");
        this.fileSource = pdxReader.readString("fileSource");
        this.status = pdxReader.readString("status");
        this.batchId = pdxReader.readString("batchId");
    }
}
