package com.dbs.daas.fitch.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SchemaModelDTO {

    @JsonProperty("appName")
    /** client that register schema model*/
    private String appName;

    @JsonProperty("model")
    /** list of fields that represents the schema model */
    private List<String> model;

    @JsonProperty("topicName")
    /** Queue name */
    private String topicName;

    @JsonProperty("uriConn")
    /** URI connection details for Queue */
    private String uriConn;

    public SchemaModelDTO() {
    }

    public SchemaModelDTO(String appName, List<String> model, String topicName, String uriConn) {
        this.appName = appName;
        this.model = model;
        this.topicName = topicName;
        this.uriConn = uriConn;
    }

   }
