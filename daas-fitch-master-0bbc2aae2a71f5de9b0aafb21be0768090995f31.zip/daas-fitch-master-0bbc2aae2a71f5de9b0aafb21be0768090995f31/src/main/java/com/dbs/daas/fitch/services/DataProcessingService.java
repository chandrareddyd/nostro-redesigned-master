package com.dbs.daas.fitch.services;

import static com.dbs.daas.fitch.model.ApiConstants.BATCH_FILE_STATUS_INPROGRESS;
import static com.dbs.daas.fitch.model.ApiConstants.BATCH_FILE_STATUS_PROCESSED;
import static com.dbs.daas.fitch.model.ApiConstants.FILE_FORMAT;
import static com.dbs.daas.fitch.model.ApiConstants.YYYYMMDD;
import static com.dbs.daas.fitch.util.CommonUtil.dateFormatter;
import static com.dbs.daas.fitch.util.CommonUtil.stringToDate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.LongAdder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.supercsv.io.CsvListReader;
import org.supercsv.io.ICsvListReader;
import org.supercsv.prefs.CsvPreference;
import org.supercsv.util.Util;

import com.dbs.daas.fitch.config.SCPSourceOptionsMetadata;
import com.dbs.daas.fitch.model.BatchFile;
import com.dbs.daas.fitch.model.EntityData;
import com.dbs.daas.fitch.repositories.BatchFileRepository;
import com.dbs.daas.fitch.repositories.EntityDataRepository;

@Service
public class DataProcessingService {
	private static final Logger LOGGER = LoggerFactory.getLogger(DataProcessingService.class);

	private SCPSourceOptionsMetadata options;

	private EntityDataRepository entityDataRepository;

	private BatchFileRepository fileRepository;
	
	@Value("${check.file.processing}")
	private long timeToCheckFileProcessing;

	@Autowired
	public DataProcessingService(SCPSourceOptionsMetadata options, EntityDataRepository entityDataRepository, BatchFileRepository fileRepository) {
		this.options = options;
		this.entityDataRepository = entityDataRepository;
		this.fileRepository = fileRepository;
	}
	
	public EntityData getAllByRecordHash(Integer recordHash) {
		return entityDataRepository.getAllByRecordHash(recordHash);
	}

	public void createOrUpdateStatus(BatchFile batchFile) {
		fileRepository.save(batchFile);
	}

	public boolean checkFileForProcessing(String fileName, String checksum) {
		
		String fileStatusMsg = fileName + " with checksum: " + checksum;
      
		boolean exists = fileRepository.exists(checksum);
  
		if (!exists) {
	  
			LOGGER.info(fileStatusMsg + " NOT EXISTS");
			return true;
		} else {
      
			BatchFile batchFile = fileRepository.findOne(checksum);
      
			if (batchFile.getStatus().equalsIgnoreCase(BATCH_FILE_STATUS_PROCESSED)) {
    	  
				LOGGER.info(fileStatusMsg + " is already PROCESSED");
				return false;
			} else if (batchFile.getStatus().equalsIgnoreCase(BATCH_FILE_STATUS_INPROGRESS) && dateInRange(batchFile.getDatetime())) {
      
				LOGGER.info(fileStatusMsg + " is in INPROGRESS");
				return false;
			} else {
	  
				LOGGER.info(fileStatusMsg + " is ready for processing");
				return true;
			}
		}
	}

	private boolean dateInRange(long date) {
		Long oneHour = 1 * 60 * 60 * 1000l;
		
		if(0 >= timeToCheckFileProcessing)
			timeToCheckFileProcessing = oneHour;
		
		long currentDate = System.currentTimeMillis();
		
		if(date > currentDate)
			return (date - currentDate) > timeToCheckFileProcessing;
		else 
			return (currentDate - date) > timeToCheckFileProcessing;
	}

	public Map<String, Long> populateData(File file, String fileChecksum, Integer fileIndex, String fileType, String frequency, Long dateOfIngestion)
			throws IOException {

		Map<String, Long> result = new HashMap<>();
		LongAdder successCount = new LongAdder();

		final String[] columnNames = options.getColumnNames().get(fileIndex);		
		
		InputStream fileInputStream = null;
		InputStreamReader inputStreamReader = null;
		BufferedReader bufferedReader = null;
		ICsvListReader listReader = null;

		try {
			
			//Long dateOfIngestion = stringToDate(YYYYMMDD, dateFormatter(YYYYMMDD)).getTime();
			
			fileInputStream = new FileInputStream(file);
			
			inputStreamReader = new InputStreamReader(fileInputStream, Charset.forName(FILE_FORMAT));
			
			bufferedReader = new BufferedReader(inputStreamReader);
			
			listReader = new CsvListReader(bufferedReader,  CsvPreference.EXCEL_PREFERENCE);
			
			List<String> row = listReader.read(); // skipping header row with column names
	        
			while ((row = listReader.read()) != null) {
				Integer recordHash = String.join("", row).replaceAll(" ", "").trim().hashCode();
				if (listReader.length() != columnNames.length) {
					
					//LOGGER.error("Skipping row. Invalid No. of fields: " + row);
					
					continue;
				}
			
				Map<String, String> data = new HashMap<>();
				
				Util.filterListToMap(data, columnNames, row); // converting list of strings to map of key-value pairs
				
				if(!data.isEmpty() && data.size() == columnNames.length) {
					
					Boolean isSaved = false;
					EntityData entityData = getAllByRecordHash(recordHash);
					
					if(entityData == null ) {
						isSaved = saveEntityData(file, data, fileChecksum, fileType, frequency, dateOfIngestion, recordHash);
					}
					
					if(!isSaved) {
						//LOGGER.error("Failed to save current row[" + rowCount + "]: " + row);
					} else {
						successCount.increment();
					}
				
				} else {				
					//LOGGER.error("Skipping row[" + rowCount + "]. Invalid No. of fields: " + row);
				}
			}
			
		} catch(Exception e) {
			
			LOGGER.error("Error reading file", e);
			
		} finally {
			
			if(null != listReader) {
				listReader.close();
			}
			
			if(null != bufferedReader) {
				bufferedReader.close();
			}
			
			if(null != inputStreamReader) {
				inputStreamReader.close();
			}
			
			if(null != fileInputStream) {
				fileInputStream.close();
			}
	
		}

		result.put("successCount", successCount.sum());
		
		return result;
	}
	
	private Boolean saveEntityData(File file, Map<String, String> data, String fileChecksum, String fileType, String frequency, Long dateOfIngestion, Integer recordHash) {
		
		EntityData entityData = new EntityData();
		
		entityData.setId(UUID.randomUUID().toString()+System.currentTimeMillis());
		entityData.setFileName(file.getName());
		entityData.setFileType(fileType);
		entityData.setFrequency(frequency);
		entityData.setData(data);
		entityData.setDateOfIngestion(dateOfIngestion);
		entityData.setFileChecksum(fileChecksum);
		entityData.setRecordHash(recordHash);
		return entityDataRepository.save(entityData) != null;
	}

}
