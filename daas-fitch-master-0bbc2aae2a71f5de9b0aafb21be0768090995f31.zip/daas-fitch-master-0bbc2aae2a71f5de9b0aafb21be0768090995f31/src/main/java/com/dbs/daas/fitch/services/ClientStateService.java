package com.dbs.daas.fitch.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.daas.fitch.model.ClientState;
import com.dbs.daas.fitch.repositories.ClientStateRepository;

@Service
public class ClientStateService {
    private ClientStateRepository clientStateRepository;

    @Autowired
    public ClientStateService(ClientStateRepository clientStateRepository) {
        this.clientStateRepository = clientStateRepository;
    }

    public ClientState get(String id) {
        return clientStateRepository.findOne(id);
    }

    public boolean save(ClientState state) {
        return clientStateRepository.save(state) != null;
    }

    public boolean delete(String appName) {
        clientStateRepository.delete(appName);
        return true;
    }
}
