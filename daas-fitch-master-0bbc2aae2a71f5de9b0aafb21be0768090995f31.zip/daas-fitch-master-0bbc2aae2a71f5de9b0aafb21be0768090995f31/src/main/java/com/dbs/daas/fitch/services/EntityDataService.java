package com.dbs.daas.fitch.services;

import static com.dbs.daas.fitch.model.ApiConstants.COL_IDENTIFIER;
import static com.dbs.daas.fitch.model.ApiConstants.COL_RATINGS;
import static com.dbs.daas.fitch.model.ApiConstants.COL_RATING_ACTION;
import static com.dbs.daas.fitch.model.ApiConstants.COL_RATING_DATE;
import static com.dbs.daas.fitch.model.ApiConstants.COL_RATING_ORG;
import static com.dbs.daas.fitch.model.ApiConstants.COL_RATING_TYPE;
import static com.dbs.daas.fitch.model.ApiConstants.COL_RATING_VALUE;
import static com.dbs.daas.fitch.model.ApiConstants.DDMMYYYY;
import static com.dbs.daas.fitch.model.ApiConstants.DEFAULT_RATING_DATE;
import static com.dbs.daas.fitch.model.ApiConstants.FIELD_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.FIELD_STATUS;
import static com.dbs.daas.fitch.model.ApiConstants.FIELD_VALUE;
import static com.dbs.daas.fitch.model.ApiConstants.ID_SEPARATOR;
import static com.dbs.daas.fitch.model.ApiConstants.ID_TYPE;
import static com.dbs.daas.fitch.model.ApiConstants.ID_VALUE;
import static com.dbs.daas.fitch.model.ApiConstants.SEARCH_TYPE_ALL;
import static com.dbs.daas.fitch.model.ApiConstants.SEARCH_TYPE_LATEST;
import static com.dbs.daas.fitch.model.ApiConstants.SERVICE_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.STATUS_INVALID;
import static com.dbs.daas.fitch.model.ApiConstants.YYYY_MM_DD_HHMMSS;
import static com.dbs.daas.fitch.util.CommonUtil.dateFormatter;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.geode.cache.query.internal.StructImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dbs.daas.fitch.config.RatingSearchConfig;
import com.dbs.daas.fitch.exception.APIException;
import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.ClientState;
import com.dbs.daas.fitch.model.EntityData;
import com.dbs.daas.fitch.model.SchemaModel;
import com.dbs.daas.fitch.model.SearchModelDTO;
import com.dbs.daas.fitch.repositories.EntityDataRepository;
import com.dbs.daas.fitch.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class EntityDataService {
	private static final Logger LOGGER = LoggerFactory.getLogger(EntityDataService.class);
	
	private final ObjectMapper mapper = new ObjectMapper();
	
	private RatingSearchConfig ratingSearchConfig;

	private EntityDataRepository entityDataRepository;

	private ClientStateService clientStateService; 

	@Value("${check.file.processing}")
	private long timeToCheckFileProcessing;

	@Autowired
	public EntityDataService(EntityDataRepository entityDataRepository, ClientStateService clientStateService, RatingSearchConfig ratingSearchConfig) {
		this.entityDataRepository = entityDataRepository;
		this.clientStateService = clientStateService;
		this.ratingSearchConfig = ratingSearchConfig;
	}

	public Long getLatestDataEntity() {
		return entityDataRepository.getLatestDataEntity();
	}

	public List<StructImpl> searchByAgentCommonId(String agentCommonId) {
		return entityDataRepository.searchByAgentCommonId(agentCommonId);
	}

	private Page<String> getPage(List<String> entityDataList, Integer page, Integer size) {

		if (entityDataList == null || entityDataList.isEmpty())
			return new PageImpl<>(new ArrayList<>(), new PageRequest(page, size), 0);

		int min = page * size;
		int max = Math.min(min + size, entityDataList.size());

		List<String> paginatedList = IntStream.range(0, entityDataList.size()).filter(i -> i >= min)
				.filter(i -> i < max).mapToObj(i -> entityDataList.get(i)).collect(Collectors.toList());

		PagedListHolder<String> holder = new PagedListHolder<>(paginatedList);
		holder.setPage(page);
		holder.setPageSize(size);

		return new PageImpl<>(holder.getPageList(), new PageRequest(page, size), entityDataList.size());

	}

	private Page<Map<String, Object>> getSearchResultPage(List<Map<String, Object>> searchResultsList, Integer page, Integer size) {

		if (searchResultsList == null || searchResultsList.isEmpty())
			return new PageImpl<>(new ArrayList<>(), new PageRequest(page, size), 0);

		int min = page * size;
		int max = Math.min(min + size, searchResultsList.size());

		List<Map<String, Object>> paginatedList = IntStream.range(0, searchResultsList.size()).filter(i -> i >= min)
				.filter(i -> i < max).mapToObj(i -> searchResultsList.get(i)).collect(Collectors.toList());

		PagedListHolder<Map<String, Object>> holder = new PagedListHolder<>(paginatedList);
		holder.setPage(page);
		holder.setPageSize(size);

		return new PageImpl<>(holder.getPageList(), new PageRequest(page, size), searchResultsList.size());

	}

	private String defaultReturnMessage(String message) throws JsonProcessingException {
		Map<String, Object> responseJsonObject = new HashMap<>();
		responseJsonObject.put("remarks", message);
		responseJsonObject.put("totalElements", 0);
		responseJsonObject.put("totalPages", 0);
		responseJsonObject.put("last", true);
		return mapper.writeValueAsString(responseJsonObject);
	}

    private void updateClientState(ClientState currentState) throws APIException {
        if (!clientStateService.save(currentState)) {
            LOGGER.error("Failed to save/update client state in Gemfire cache");
            throw new APIException(Integer.parseInt(HttpStatus.INTERNAL_SERVER_ERROR.toString()),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
        }
    }

    private boolean isTodayDate(Long timestampDate) {

        String requestedDate = dateFormatter(DDMMYYYY,new Date(timestampDate));
        String todayDate = dateFormatter(DDMMYYYY,new Date());

        return requestedDate.equalsIgnoreCase(todayDate);
    }
    
    private Long processTimestamp(long timestamp) {

        // base date. 01/01/2016
        Calendar initialDate = Calendar.getInstance();
        initialDate.set(2016,01,01);

        if(timestamp > initialDate.getTime().getTime()) 
        	return timestamp;
		
		Long latestDateOfIngestion = getLatestDataEntity();

        if (null != latestDateOfIngestion) 
        	return latestDateOfIngestion;
        else 
        	return 0L;
    }
    
    private ClientState processClientState(SchemaModel schemaModel, Long timestampDate) {

        ClientState currentState = clientStateService.get(schemaModel.getAppName() + ID_SEPARATOR + timestampDate);
        if (null == currentState)
            return new ClientState(schemaModel.getAppName() + ID_SEPARATOR + timestampDate, -1);
        else return currentState;
    }

    private boolean isDataLoaded(Long timestampDate) {
    	
    	EntityData entityDataList = entityDataRepository.isDataLoaded(timestampDate);

    	if(null == entityDataList)
    		return false;
    	else
    		return true;

    }

    private Map<String, String> addRemark(String fieldName, String fieldValue, String status) {
    	Map<String, String> remarkObj = new HashMap<>();
		remarkObj.put(FIELD_NAME, fieldName);
		remarkObj.put(FIELD_VALUE, fieldValue);
		remarkObj.put(FIELD_STATUS, status);
		return remarkObj;
    }
    
    public String getRatings(SearchModelDTO searchModel, Integer page, Integer size) throws JsonProcessingException {

		final List<Map<String, Object>> searchResultsList = new ArrayList<>();
		final List<Map<String, String>> remarks = new ArrayList<>();
		final Map<String, List<Map<String, Object>>> ratingTypeData = new HashMap<>();
		List<String> correctRatingTypes = new ArrayList<>();
		
		if(null == searchModel){
			LOGGER.error("No search model available");
			return defaultReturnMessage("No search model available");
		}
		
		if(null == searchModel.getRatingTypes() || searchModel.getRatingTypes().isEmpty()){
			correctRatingTypes = new ArrayList<>(ratingSearchConfig.getRatingTypeCodes().keySet());
		} else {
			for(String ratingType : searchModel.getRatingTypes()) {
				if(null == ratingType || ratingType.isEmpty() || !ratingSearchConfig.getRatingTypeColumnMapping().containsKey(ratingType.toUpperCase())) {
					remarks.add(addRemark(COL_RATING_TYPE, ratingType, STATUS_INVALID));
				} else {
					correctRatingTypes.add(ratingType);					
				}
			}
		}
		
		for(Map<String, String> identifier : searchModel.getIdentifier()) {
			
			if(null != identifier && identifier.containsKey(ID_TYPE) && identifier.containsKey(ID_VALUE) && null != ratingSearchConfig.getIdentifierTypes().get(identifier.get(ID_TYPE))) {
				
				List<StructImpl> entityDataList = searchByAgentCommonId(identifier.get(ID_VALUE));
				
				if(null != entityDataList && !entityDataList.isEmpty()) {
					
					final List<Map<String, Object>> ratings = new ArrayList<>();
					
					for(StructImpl entityDataObj : entityDataList) { // Iterate over each record to generate ratings data	
							
						for(String requestedRatingType : correctRatingTypes) {

							Map<String, Object> ratingObj = new HashMap<>();
							
							ratingObj.put(COL_RATING_TYPE, ratingSearchConfig.getRatingTypeDescription().get(requestedRatingType));
							
							for(String field : ratingSearchConfig.getRatingTypeColumnMapping().get(requestedRatingType)) { // generate rating data object
								
								ratingObj.put(getRatingResponseField(field), entityDataObj.get(field));
								
							}	
								
							List<Map<String, Object>> ratingDataList;
							if(ratingTypeData.containsKey(requestedRatingType)) {
								ratingDataList = ratingTypeData.get(requestedRatingType);
							} else {
								ratingDataList = new ArrayList<>();
							}
							if(null != ratingDataList) {
								ratingDataList.add(ratingObj);
								ratingTypeData.put(requestedRatingType, ratingDataList);
							}
						}
					}
					
					for(Map.Entry<String, List<Map<String, Object>>> entry : ratingTypeData.entrySet()) {
						List<Map<String, Object>> ratingData = entry.getValue();
						if(null != ratingData) {
							Collections.sort(ratingData, new Comparator<Map<String, Object>>() {
							    @Override
							    public int compare(Map<String, Object> rating1, Map<String, Object> rating2) {
							    	Long rating1Date = null;
							    	Long rating2Date = null;
							    	try {
										if(null == rating1.get(COL_RATING_DATE) || (null != rating1.get(COL_RATING_DATE) && rating1.get(COL_RATING_DATE).toString().isEmpty()) || "NR".equalsIgnoreCase(rating1.get(COL_RATING_DATE).toString())) {
											rating1Date = CommonUtil.stringToDate(YYYY_MM_DD_HHMMSS, DEFAULT_RATING_DATE).getTime();
										} else {
											rating1Date = CommonUtil.stringToDate(YYYY_MM_DD_HHMMSS, (String)rating1.get(COL_RATING_DATE)).getTime();
										}
								    	if(null == rating2.get(COL_RATING_DATE) || (null != rating2.get(COL_RATING_DATE) && rating2.get(COL_RATING_DATE).toString().isEmpty()) || "NR".equalsIgnoreCase(rating2.get(COL_RATING_DATE).toString())) {
								    		rating2Date = CommonUtil.stringToDate(YYYY_MM_DD_HHMMSS, DEFAULT_RATING_DATE).getTime();
										} else {
											rating2Date = CommonUtil.stringToDate(YYYY_MM_DD_HHMMSS, (String)rating2.get(COL_RATING_DATE)).getTime();
										}
									} catch (ParseException e) {
										LOGGER.error("Error while trying to sort ratings: " + e.getMessage(), e);
									}
							    	return rating1Date.compareTo(rating2Date);
							    }
							});
							Collections.reverse(ratingData);
							if(null != ratingData && !ratingData.isEmpty()) {
								for(Map<String, Object> ratingDataObj : ratingData) {
									ratingDataObj.values().removeAll(Collections.singleton(null));
								}
								if(searchModel.getSearchType().equalsIgnoreCase(SEARCH_TYPE_LATEST)) {				
									ratings.add(ratingData.get(0));
								}
								else if(searchModel.getSearchType().equalsIgnoreCase(SEARCH_TYPE_ALL)) {	
									ratings.addAll(ratingData);
								}
							}
						}
					}
					
					if(!ratings.isEmpty()) {
						
						Map<String, Object> ratingData = new HashMap<>();
						
						ratingData.put(COL_RATING_ORG, SERVICE_NAME.toUpperCase());
						ratingData.put(identifier.get(ID_TYPE), identifier.get(ID_VALUE));						
						ratingData.put(COL_RATINGS, ratings);
						
						searchResultsList.add(ratingData);
					}
				}
			} else {
				if(null != identifier && null != identifier.get(ID_TYPE) && null == ratingSearchConfig.getIdentifierTypes().get(identifier.get(ID_TYPE))) {
					remarks.add(addRemark(COL_IDENTIFIER+"."+ID_TYPE, identifier.get(ID_TYPE), STATUS_INVALID));	
				}
			}
		}
		
		if(!searchResultsList.isEmpty()) {
			
			Integer maxPages;
			if (searchResultsList.size() % size == 0) {
				maxPages = searchResultsList.size() / size;
			} else {
				maxPages = (searchResultsList.size() / size) + 1;
			}
			if(page >= maxPages) 
				page = maxPages - 1;

			Page<Map<String, Object>> currentPage = getSearchResultPage(searchResultsList, page, size);	
			
			if (null == currentPage || currentPage.getContent().isEmpty()) {
				return defaultReturnMessage(ApiConstants.MSG_NO_DATA);
			}
	
			Map<String, Object> responseJsonObject = new HashMap<>();
            responseJsonObject.put("content", currentPage.getContent());
			responseJsonObject.put("size", size);
			responseJsonObject.put("pageNumber", page);
			responseJsonObject.put("numberOfElements", currentPage.getContent().size());
			responseJsonObject.put("sort", "desc");
	
			responseJsonObject.put("totalElements", currentPage.getTotalElements());
			responseJsonObject.put("totalPages", currentPage.getTotalPages());
	
			if ((currentPage.getTotalPages() - 1) == page) {
				responseJsonObject.put("last", true);
			} else {
				responseJsonObject.put("last", false);
			}
			if (0 == page) {
				responseJsonObject.put("first", true);
			} else {
				responseJsonObject.put("first", false);
			}
			responseJsonObject.put("remarks", remarks);
			return mapper.writeValueAsString(responseJsonObject);
		} else {			
		    return defaultReturnMessage(ApiConstants.MSG_NO_DATA);
        } 
    }
    
    private String getRatingResponseField(String field) {
    	if(ratingSearchConfig.getRatingValueColumns().contains(field))
    		return COL_RATING_VALUE;
    	if(ratingSearchConfig.getRatingDateColumns().contains(field))
    		return COL_RATING_DATE;
    	if(ratingSearchConfig.getRatingActionColumns().contains(field))
    		return COL_RATING_ACTION;
    	return field;
    }

	public String getData(SchemaModel schemaModel, Long requestedDate, String replay, Integer page, Integer size)
			throws JsonProcessingException, APIException {

		Integer maxPages = 0;
		Integer requestedPage = page;
		
		List<String> entityDataList = null;

		if (null == schemaModel || null == schemaModel.getModel() || schemaModel.getModel().isEmpty()) {
			LOGGER.error("No schema model available");
			return defaultReturnMessage("No schema model available");
		}

		Long timestampDate = processTimestamp(requestedDate);
		
		if(isTodayDate(timestampDate) && !isDataLoaded(timestampDate)){ // no data for todays in the datastore. load latest.
			
			if(entityDataRepository.count() > 0) {
				Long latestDateOfIngestion = getLatestDataEntity();
	            
				if (null != latestDateOfIngestion) 
					timestampDate = latestDateOfIngestion;
	            else {
	            	timestampDate = 0L;
	            }
			} else {
				timestampDate = 0L;
			}
        }		
		
        if(timestampDate == 0) {
        	return defaultReturnMessage(ApiConstants.MSG_NO_DATA);
        }
		
		if (!isTodayDate(timestampDate) && !isDataLoaded(timestampDate)) {			
			return defaultReturnMessage(ApiConstants.MSG_NO_DATA);			
		}

		entityDataList = entityDataRepository.getAllByDateOfIngestion(timestampDate);	
		
		ClientState clientState = processClientState(schemaModel, timestampDate);
		
		if(null != entityDataList && !entityDataList.isEmpty()) {
			
			//if replay is not N or n then start from page 0.
	        if(!"N".equalsIgnoreCase(replay)) {

	        	requestedPage = 0;
	        }       
        
	        if (entityDataList.size() % size == 0) {
				maxPages = entityDataList.size() / size;
			} else {
				maxPages = (entityDataList.size() / size) + 1;
			}
	
	        if(requestedPage < 0) 
	        	requestedPage = clientState.getPageNo() + 1; // "streaming pages"
	
	        if(requestedPage >= maxPages) 
	        	requestedPage = maxPages - 1;
	        
	        clientState.setPageNo(requestedPage);
	        
	        updateClientState(clientState); 

			final List<Map<String, Object>> entityDataPageList = new ArrayList<>();
	
			Page<String> currentPage = getPage(entityDataList, requestedPage, size);
	
			currentPage.map(id -> {
				
				EntityData entityData = entityDataRepository.findOne(id);
				
				Map<String, Object> dataMap = generateMap(schemaModel, entityData);
				
				return dataMap;
				
			}).forEach(entity -> {
				
				if(null != entity && !entity.isEmpty()) {
					entityDataPageList.add(entity);
				}
				
			});
	
			if (null == entityDataPageList || entityDataPageList.isEmpty()) {
				return defaultReturnMessage(ApiConstants.MSG_NO_DATA);
			}
	
			Map<String, Object> responseJsonObject = new HashMap<>();
            responseJsonObject.put("content", entityDataPageList);
			responseJsonObject.put("size", size);
			responseJsonObject.put("pageNumber", requestedPage);
			responseJsonObject.put("numberOfElements", entityDataPageList.size());
			responseJsonObject.put("sort", "desc");
	
			responseJsonObject.put("totalElements", currentPage.getTotalElements());
			responseJsonObject.put("totalPages", currentPage.getTotalPages());
	
			if ((currentPage.getTotalPages() - 1) == requestedPage) {
				responseJsonObject.put("last", true);
			} else {
				responseJsonObject.put("last", false);
			}
			if (0 == requestedPage) {
				responseJsonObject.put("first", true);
			} else {
				responseJsonObject.put("first", false);
			}
	
			responseJsonObject.put("batchDate", dateFormatter(ApiConstants.YYYYMMDD, dateFormatter(timestampDate)));
			
			return mapper.writeValueAsString(responseJsonObject);
		} else {
			
		    return defaultReturnMessage(ApiConstants.MSG_NO_DATA);
        } 
	}

	private Map<String, Object> generateMap(SchemaModel schemaModel, EntityData entityData) {
		final Map<String, Object> dataMap = new HashMap<>();
		
		Map<String, String> data = null;

		for (String field : schemaModel.getModel()) {
			//if (DEFAULT_MODEL_FIELDS_SET.contains(field.toUpperCase())) {
				try {
					data = entityData.getData();
					
					if(null != data && !data.isEmpty() && data.containsKey(field) && !"null".equalsIgnoreCase(data.get(field))) {
						dataMap.put(field, (String) data.get(field));
					}/* else {
						dataMap.put(field, null);
					}*/
					
				} catch (Exception e) {
					LOGGER.warn("error processing json object: " + data, e);
				}
			//}
		}
		return dataMap;
	}
}
