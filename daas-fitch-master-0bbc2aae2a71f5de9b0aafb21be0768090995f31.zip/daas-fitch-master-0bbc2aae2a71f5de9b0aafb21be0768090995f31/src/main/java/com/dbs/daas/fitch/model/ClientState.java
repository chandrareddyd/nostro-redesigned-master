package com.dbs.daas.fitch.model;

import org.apache.geode.pdx.PdxReader;
import org.apache.geode.pdx.PdxSerializable;
import org.apache.geode.pdx.PdxWriter;
import org.springframework.data.annotation.Id;
import org.springframework.data.gemfire.mapping.Region;

import lombok.Data;


@Region("Fitch_ClientState")
@Data
public class ClientState implements PdxSerializable {

    @Id
    private String id; // appName + "##" + batchDate

    private Integer pageNo;

    public ClientState() {
    	// default
    }

    public ClientState(String id, Integer pageNo) {
        this.id = id;
        this.pageNo = pageNo;
    }   

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	@Override
    public void toData(PdxWriter pdxWriter) {
        pdxWriter.writeString("id",this.id);
        pdxWriter.writeInt("pageNo", this.pageNo);
    }

    @Override
    public void fromData(PdxReader pdxReader) {
        this.id = pdxReader.readString("id");
        this.pageNo = pdxReader.readInt("pageNo");
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((pageNo == null) ? 0 : pageNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClientState other = (ClientState) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (pageNo == null) {
			if (other.pageNo != null)
				return false;
		} else if (!pageNo.equals(other.pageNo))
			return false;
		return true;
	}
}
