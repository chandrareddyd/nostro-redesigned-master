package com.dbs.daas.fitch.repositories;

import org.springframework.data.gemfire.repository.GemfireRepository;
import org.springframework.stereotype.Repository;

import com.dbs.daas.fitch.model.BatchFile;

/**
 * Created by carlos on 1/25/17.
 */
@Repository
public interface BatchFileRepository extends GemfireRepository<BatchFile, String> {

}
