package com.dbs.daas.fitch.batch;


import static com.dbs.daas.fitch.model.ApiConstants.BATCH_FILE_STATUS_DOESNOT_EXIST;
import static com.dbs.daas.fitch.model.ApiConstants.BATCH_FILE_STATUS_INPROGRESS;
import static com.dbs.daas.fitch.model.ApiConstants.BATCH_FILE_STATUS_MISMATCH;
import static com.dbs.daas.fitch.model.ApiConstants.BATCH_FILE_STATUS_PROCESSED;
import static com.dbs.daas.fitch.model.ApiConstants.DAILY;
import static com.dbs.daas.fitch.model.ApiConstants.FILE_TYPE_ISSUE;
import static com.dbs.daas.fitch.model.ApiConstants.FILE_TYPE_ISSUER;
import static com.dbs.daas.fitch.model.ApiConstants.ISSUER_DAILY_TMP_FILE_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.ISSUER_MONTHLY_TMP_FILE_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.ISSUE_DAILY_TMP_FILE_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.ISSUE_MONTHLY_TMP_FILE_NAME;
import static com.dbs.daas.fitch.model.ApiConstants.MONTHLY;
import static com.dbs.daas.fitch.model.ApiConstants.MSG_ERR_CPY_FILE;
import static com.dbs.daas.fitch.model.ApiConstants.MSG_NO_REMOTE_FILE_EXISTS;
import static com.dbs.daas.fitch.model.ApiConstants.YYYYMMDD;
import static com.dbs.daas.fitch.util.CommonUtil.dateFormatter;
import static com.dbs.daas.fitch.util.CommonUtil.stringToDate;
import static com.dbs.daas.fitch.util.MessageHandler.publishMessage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dbs.daas.fitch.config.SCPSourceOptionsMetadata;
import com.dbs.daas.fitch.model.BatchFile;
import com.dbs.daas.fitch.model.SchemaModel;
import com.dbs.daas.fitch.services.DataProcessingService;
import com.dbs.daas.fitch.services.SchemaModelService;
import com.dbs.daas.fitch.util.SCPUtils;
import com.jcraft.jsch.Session;


@Component
public class SCPBatch implements JobExecutionListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(SCPBatch.class);

    private SCPSourceOptionsMetadata options;

    private SCPUtils scpUtils;

	private DataProcessingService dataProcessingService;

    private SchemaModelService schemaModelService;


    @Autowired
    public SCPBatch(SCPSourceOptionsMetadata options, SCPUtils scpUtil, DataProcessingService dataProcessingService,
                    SchemaModelService schemaModelService) {
        this.options = options;
        this.scpUtils = scpUtil;
        this.dataProcessingService = dataProcessingService;
        this.schemaModelService = schemaModelService;
    }

	public void copyRemoteFilesAndProcessThem(String jobId) throws IOException {
		Session session = null;

        Long rowsProcessed0 = 0l;
        Long rowsProcessed1 = 0l;
        Long rowsProcessed2 = 0l;
        Long rowsProcessed3 = 0l;

        try {
			
			session = scpUtils.authenticateScpServer(options);
	
	        try {
	        		
	        	rowsProcessed0 = processFile(jobId, ISSUE_MONTHLY_TMP_FILE_NAME, 1, session, FILE_TYPE_ISSUE, MONTHLY);
	        	
	        } catch (IOException e) {
	            LOGGER.error(MSG_ERR_CPY_FILE, e);
	        }
	        
	        try {
	        		
	        	rowsProcessed1 = processFile(jobId, ISSUER_MONTHLY_TMP_FILE_NAME, 3, session, FILE_TYPE_ISSUER, MONTHLY);
	        	
	        } catch (IOException e) {
	            LOGGER.error(MSG_ERR_CPY_FILE, e);
	        }
        
	        try {
	        	
	            rowsProcessed2 = processFile(jobId, ISSUE_DAILY_TMP_FILE_NAME, 0, session, FILE_TYPE_ISSUE, DAILY);
	            
	        } catch (IOException e) {
	            LOGGER.error(MSG_ERR_CPY_FILE, e);
	        }
	
	        try {
	        	
	            rowsProcessed3 = processFile(jobId, ISSUER_DAILY_TMP_FILE_NAME, 2, session, FILE_TYPE_ISSUER, DAILY);	
	            
	        } catch (IOException e) {
	            LOGGER.error(MSG_ERR_CPY_FILE, e);
	        }

        } catch (Exception e) {
        	
            LOGGER.error("error authentication to server", e);
            
        } finally {
        	
            if (null != session) {
                
            	try {
            		
                    session.disconnect();
                    
                } catch (Exception e) {
                    LOGGER.warn("Error occurred while disconnecting ssh session", e);
                }
            }
        }

        Long totalCount = rowsProcessed0 + rowsProcessed1 + rowsProcessed2 + rowsProcessed3;
        
        if (totalCount > 0) {
            notifyUsers();
        }
	}
	
    private Long processFile(String jobId, String tmpFileName, int fileIndex, Session session, String fileType, String frequency) throws IOException, ParseException {
        File file = null;
        Long count = 0l;

        String rfileName = options
                .getFileNames()
                .get(fileIndex);

        String tempFilename = tmpFileName;
        
        try {
        	
            String fileChecksum = scpUtils.shasumRemoteFile(session, rfileName);
            
            boolean fileIsOKForProcessing = dataProcessingService.checkFileForProcessing(rfileName, fileChecksum);
            
            if (fileIsOKForProcessing) {
            	
                updateFileStatus(BATCH_FILE_STATUS_INPROGRESS, jobId, fileChecksum, rfileName);
                
                file = scpUtils.getRemoteFile(session, rfileName, tempFilename);
                
                if (null == file || !file.exists()) {
                	
					updateFileStatus(BATCH_FILE_STATUS_DOESNOT_EXIST, jobId, fileChecksum, rfileName);
					
					throw new IOException(MSG_NO_REMOTE_FILE_EXISTS + ": " + options.getFileNames().get(fileIndex));
				}
                
                String localFileChecksum = scpUtils.checksumLocalFile(new FileInputStream(file));
                
                if (localFileChecksum.equalsIgnoreCase(fileChecksum)) { // remote file matches local file
                	
                	Long dateOfIngestion = stringToDate(YYYYMMDD, dateFormatter(YYYYMMDD)).getTime();
                    
                	Map<String, Long> result = dataProcessingService.populateData(file, fileChecksum, fileIndex, fileType, frequency, dateOfIngestion);
                	
                	if (null != result && !result.isEmpty()) {
                		
                        LOGGER.info("Total "  + result.get("successCount") + " records saved in database from file: " + options.getFileNames().get(fileIndex));
                        
                        count = result.get("successCount");
                    
                	} else {
                    	LOGGER.error("Failed to process " + options.getFileNames().get(fileIndex));
                    }
                    
                    updateFileStatus(BATCH_FILE_STATUS_PROCESSED, jobId, fileChecksum, rfileName);
                    
                } else {
                	
                    updateFileStatus(BATCH_FILE_STATUS_MISMATCH, jobId, fileChecksum, rfileName);
                }
            }
        } finally {
            
            if (null != file && file.delete()) {
                LOGGER.debug("Temporary file deleted successfully");
            }
        }
        return count;
    }

	private void updateFileStatus(String status, String jobId, String fileChecksum, String fileName) {
		
		BatchFile batchFile = new BatchFile();
		
		batchFile.setChecksum(fileChecksum);
		batchFile.setFileSource(fileName);
		batchFile.setDatetime(System.currentTimeMillis());
		batchFile.setStatus(status);
		batchFile.setBatchId(jobId);
		
		dataProcessingService.createOrUpdateStatus(batchFile);
	}


    private void notifyUsers() {
        List<SchemaModel> models = schemaModelService.get();
        if (null != models && !models.isEmpty()) {
            for (SchemaModel model : models) {
                if (null != model.getTopicName() && !model.getTopicName().isEmpty() && null != model.getMqHost()
                        && !model.getMqHost().isEmpty() && 0 != model.getMqPort()
                        && null != model.getMqUsername() && !model.getMqUsername().isEmpty()
                        && null != model.getMqPassword() && !model.getMqPassword().isEmpty()
                        && null != model.getMqVirtualHost() && !model.getMqVirtualHost().isEmpty()) {                    
                	try {                        
                		publishMessage(model);                    
                	} catch (Exception e) {
                        LOGGER.error("Failed to publish message for " + model.getAppName(), e);
                    }
                }
            }
        }
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        
    	String jobId = jobExecution.getExecutionContext().getString("JOBID");
        
    	String date = new Date().toString();
        
        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
        	
            LOGGER.info(String.format("SCP Source job: %s completed at %s", jobId, date));
            
        } else if (jobExecution.getStatus() == BatchStatus.FAILED) {
        	
            LOGGER.info(String.format("SCP Source job: %s failed at %s", jobId, date));
            
        }
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        
    	String jobId = UUID.randomUUID().toString();
        
    	String date = new Date().toString();
        
    	LOGGER.info(String.format("SCP Source job: %s started at %s", jobId, date));
        
    	jobExecution.getExecutionContext().putString("JOBID", jobId);
    	
    }

}