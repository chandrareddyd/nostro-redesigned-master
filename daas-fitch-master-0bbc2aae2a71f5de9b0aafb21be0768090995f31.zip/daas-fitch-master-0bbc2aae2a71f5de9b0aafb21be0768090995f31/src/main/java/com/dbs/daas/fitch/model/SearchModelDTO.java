package com.dbs.daas.fitch.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SearchModelDTO {
	
	@JsonProperty("RATING_ORG")
    private String ratingOrg;
	
	@JsonProperty("RATING_TYPE")
    private List<String> ratingTypes;
	
	@JsonProperty("IDENTIFIER")
    private List<Map<String, String>> identifier;
	
	@JsonProperty("SEARCH_TYPE")
    private String searchType;

    public SearchModelDTO() {
    }

    public SearchModelDTO(String ratingOrg, List<String> ratingTypes, List<Map<String, String>> identifier, String searchType) {
        this.ratingOrg = ratingOrg;
        this.ratingTypes = ratingTypes;
        this.identifier = identifier;
        this.searchType = searchType;
    }

}
