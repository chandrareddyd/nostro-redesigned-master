package com.dbs.daas.fitch.model;

import java.util.Map;

import org.apache.geode.pdx.PdxReader;
import org.apache.geode.pdx.PdxSerializable;
import org.apache.geode.pdx.PdxWriter;
import org.springframework.data.annotation.Id;
import org.springframework.data.gemfire.mapping.Region;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

import lombok.Data;


@Region("Fitch_DataEntities")
@Data
public class EntityData implements PdxSerializable {

    @Id
    private String id;

    private String fileName;

    private String fileType; // ISSUE, ISSUER

    private String frequency; // DAILY, MONTHLY

    private Map<String,String> data;
    
    @JsonSerialize(using = ToStringSerializer.class)
    private Long dateOfIngestion; // yyyyMMdd

    @JsonIgnore
    private String fileChecksum; 
    
    @JsonIgnore
    private Integer recordHash;

    @Override
    public void toData(PdxWriter pdxWriter) {
        pdxWriter.writeString("id",this.id);
        pdxWriter.writeString("fileName",this.fileName);
        pdxWriter.writeString("fileType",this.fileType);
        pdxWriter.writeString("frequency",this.frequency);
        pdxWriter.writeObject("data", this.data);
        pdxWriter.writeLong("dateOfIngestion",this.dateOfIngestion);
        pdxWriter.writeString("fileChecksum",this.fileChecksum);
        pdxWriter.writeInt("recordHash", this.recordHash);
    }

    @Override
    public void fromData(PdxReader pdxReader) {
        this.id = pdxReader.readString("id");
        this.fileName = pdxReader.readString("fileName");
        this.fileType = pdxReader.readString("fileType");
        this.frequency = pdxReader.readString("frequency");
        this.data = (Map<String, String>) pdxReader.readObject("data");
        this.dateOfIngestion = pdxReader.readLong("dateOfIngestion");
        this.fileChecksum = pdxReader.readString("fileChecksum");
        this.recordHash = pdxReader.readInt("recordHash");
    }

}
