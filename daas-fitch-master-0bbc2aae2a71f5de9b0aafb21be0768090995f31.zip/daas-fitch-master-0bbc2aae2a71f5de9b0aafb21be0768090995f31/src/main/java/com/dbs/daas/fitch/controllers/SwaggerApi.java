package com.dbs.daas.fitch.controllers;

import java.util.HashMap;
import java.util.Map;

import org.codehaus.jettison.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.dbs.daas.fitch.exception.APIException;
import com.dbs.daas.fitch.model.SchemaModel;
import com.dbs.daas.fitch.model.SchemaModelDTO;
import com.dbs.daas.fitch.model.SearchModelDTO;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Fitch")
public interface SwaggerApi {

	@ApiOperation(value = "Returns file data", notes = "Returns file data", response = HashMap.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation", response = String.class) })
	@GetMapping(value = "/{appName}")
	ResponseEntity<String> getData(
			@ApiParam(value = "Client application name", required = true) @PathVariable(value = "appName") String appName,
			@ApiParam(value = "Timestamp in yyyyMMdd format") @RequestParam(value = "timestamp", required = false) String timestamp,
			@ApiParam(value = "Replay Y/N") @RequestParam(value = "replay", required = false, defaultValue = "N") String replay,
			@ApiParam(value = "Page number to be fetched") @RequestParam(value = "page", required = false, defaultValue = "-1") Integer page,
			@ApiParam(value = "Maximum number of records per page") @RequestParam(value = "size", required = false, defaultValue = "50") Integer size)
			throws APIException, JsonProcessingException;

	@ApiOperation(value = "Registers schema model", notes = "Registers schema model", response = SchemaModelDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Successful operation", response = SchemaModelDTO.class) })
	@PostMapping(value = "/register")
	ResponseEntity<SchemaModelDTO> registerModel(
			@ApiParam(value = "Schema model object") @RequestBody SchemaModelDTO dto) throws APIException;

	@ApiOperation(value = "Deletes schema model", notes = "Deletes schema model", response = JSONObject.class)
	@ApiResponses(value = { @ApiResponse(code = 204, message = "Successful operation", response = JSONObject.class) })
	@DeleteMapping(value = "/{appName}")
	ResponseEntity<Map<String, String>> deleteModel(
			@ApiParam(value = "Client application name", required = true) @PathVariable(value = "appName") String appName)
			throws APIException;

	@GetMapping(value = "/model/{modelName}")
	ResponseEntity<SchemaModel> getModel(
			@ApiParam(value = "model name", required = true) @PathVariable(value = "modelName") String modelName)
			throws APIException;

	@ApiOperation(value = "Search ratings", notes = "Search ratings", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Successful operation", response = String.class) })
	@PostMapping(value = "/search")
	ResponseEntity<String> searchRatings(@ApiParam(value = "Search model object") @RequestBody SearchModelDTO dto,
			@ApiParam(value = "Page number to be fetched") @RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
			@ApiParam(value = "Maximum number of records per page") @RequestParam(value = "size", required = false, defaultValue = "50") Integer size)
			throws APIException, JsonProcessingException;

	@ApiOperation(value = "Search fitch Rating by fitch Ids")
	@GetMapping(value = "/search/{fitchIds}", produces = "application/json")
	ResponseEntity<String> searchRatings(
			@ApiParam(value = "Comma Seperated Fitch Ids", required = true) @PathVariable(value = "appName") String fitchIds)
			throws APIException, JsonProcessingException;
}