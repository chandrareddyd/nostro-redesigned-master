package com.dbs.daas.fitch.model;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class ApiConstants {

    public static final String SERVICE_NAME = "fitch";
    public static final String BATCH_FILE_STATUS_PROCESSED = "PROCESSED";
    public static final String BATCH_FILE_STATUS_INPROGRESS = "INPROGRESS";
    public static final String BATCH_FILE_STATUS_MISMATCH = "FILE_MISMATCH";
    public static final String BATCH_FILE_STATUS_DOESNOT_EXIST = "FILE_DOESNOT_EXIST";
    public static final String YYYYMMDD = "yyyyMMdd";
    public static final String DDMMYYYY = "ddMMyyyy";
    public static final String YYYY_MM_DD_HHMMSS = "yyyy-MM-dd HH:mm:ss";
    public static final String NOTIFICATION_MSG = "File data is ready to consume";
    public static final String ENCRYPTION_ALGORITHM_NAME = "AES";
    public static final String CIPHER_TRANSFORMATION = "AES/CBC/PKCS5PADDING";
    public static final String DEFAULT_ISSUE_DAILY_FILE_NAME = "RDSIssueReport.txt";
    public static final String DEFAULT_ISSUE_MONTHLY_FILE_NAME = "RDSIssueReport_M.txt";
    public static final String DEFAULT_ISSUER_DAILY_FILE_NAME = "RDSIssuerReport.txt";
    public static final String DEFAULT_ISSUER_MONTHLY_FILE_NAME = "RDSIssuerReport_M.txt";
    public static final String ISSUE_DAILY_TMP_FILE_NAME = "issue-daily-output.scp.tmp";
    public static final String ISSUE_MONTHLY_TMP_FILE_NAME = "issue-monthly-output.scp.tmp";
    public static final String ISSUER_DAILY_TMP_FILE_NAME = "issuer-daily-output.scp.tmp";
    public static final String ISSUER_MONTHLY_TMP_FILE_NAME = "issuer-monthly-output.scp.tmp";
    public static final String[] DEFAULT_MODEL_FIELDS_ARRAY = {"ISSUER_ID","AGENT_COMMON_ID","LONG_TERM_ISSUER_DEFAULT_RATING","LT_IDR_EFFECTIVE_DATE","LT_IDR_ACTION","LONG_TERM_ISSUER_RATING","LT_ISSUER_RATING_EFFECTIVE_DATE","LT_ISSUER_RATING_ACTION","SHORT_TERM_ISSUER_DEFAULT_RATING","ST_IDR_EFFECTIVE_DATE","ST_IDR_ACTION","SHORT_TERM_ISSUER_RATING","ST_ISSUER_RATING_EFFECTIVE_DATE","ST_ISSUER_RATING_ACTION","BANK_INDIVIDUAL_RATING","BANK_INDIVIDUAL_RATING_EFFECTIVE_DATE","BANK_INDIVIDUAL_RATING_ACTION","BANK_SUPPORT_RATING","BANK_SUPPORT_RATING_EFFECTIVE_DATE","BANK_SUPPORT_RATING_ACTION"};
    public static final Set<String> DEFAULT_MODEL_FIELDS_SET = new TreeSet<>(Arrays.asList(DEFAULT_MODEL_FIELDS_ARRAY));
    public static final String MSG_NO_DATA = "No Fitch ratings available";
    public static final String MSG_NO_REMOTE_FILE_EXISTS = "File doesn't exist on remote server";
    public static final String MSG_ERR_CPY_FILE = "error copying file";
    public static final String COL_DATA = "data"; 
    public static final String COL_IDENTIFIER = "IDENTIFIER";
    public static final String COL_RATING_ORG = "RATING_ORG";  
    public static final String COL_RATINGS = "RATINGS";
    public static final String COL_RATING_TYPE = "RATING_TYPE";
    public static final String COL_RATING_VALUE = "RATING_VALUE";
    public static final String COL_RATING_DATE = "RATING_DATE";
    public static final String COL_RATING_ACTION = "RATING_ACTION";
    public static final String FILE_TYPE_ISSUE = "ISSUE";     
    public static final String FILE_TYPE_ISSUER = "ISSUER";     
    public static final String DAILY = "D";     
    public static final String MONTHLY = "M";  
    public static final String FILE_FORMAT = "UTF-16LE";
	public static final String SG_TIMEZONE = "Asia/Singapore";
	public static final String ID_SEPARATOR = "##";
	public static final String ID_TYPE = "ID_TYPE";
	public static final String ID_VALUE = "ID_VALUE";
	public static final String SEARCH_TYPE_LATEST = "LATEST";
	public static final String SEARCH_TYPE_ALL = "ALL";
	public static final String FIELD_NAME = "FIELD_NAME";
	public static final String FIELD_VALUE = "FIELD_VALUE";
	public static final String FIELD_STATUS = "STATUS";
	public static final String STATUS_INVALID = "INVALID";	
	public static final String DEFAULT_RATING_DATE = "1970-01-01 00:00:00";	

    private ApiConstants() {
    }
}
