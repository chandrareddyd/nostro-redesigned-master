package com.dbs.daas.fitch.config;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import com.dbs.daas.fitch.batch.SCPBatch;

/**
 * Created by carlos on 1/26/17.
 */
@Configuration
@EnableBatchProcessing
@EnableScheduling
public class SCPBatchConfig {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    private SCPBatch scp;

    @Bean
    public TaskScheduler taskScheduler() {
        return new ThreadPoolTaskScheduler();
    }


    @Bean
    public ResourcelessTransactionManager transactionManager() {
        return new ResourcelessTransactionManager();
    }

    @Bean("mapJobRepositoryFactory")
    public MapJobRepositoryFactoryBean mapJobRepositoryFactory(
            ResourcelessTransactionManager transactionManager) throws Exception {

        MapJobRepositoryFactoryBean factory = new MapJobRepositoryFactoryBean(transactionManager);
        factory.afterPropertiesSet();
        return factory;
    }

    @Bean
    @DependsOn("mapJobRepositoryFactory")
    public JobRepository jobRepository(MapJobRepositoryFactoryBean mapJobRepositoryFactory) throws Exception {
        return mapJobRepositoryFactory.getObject();
    }

    @Bean
    public SimpleJobLauncher jobLauncher(JobRepository jobRepository) {
        SimpleJobLauncher launcher = new SimpleJobLauncher();
        launcher.setJobRepository(jobRepository);
        return launcher;
    }

    @Bean
    public Step copyRemoteFilesStep() {
        return stepBuilderFactory.get("copyRemoteFilesStep")
                .tasklet((contribution, chunkContext) -> {
                    scp.copyRemoteFilesAndProcessThem((String) chunkContext
                            .getStepContext()
                            .getStepExecution()
                            .getJobExecution()
                            .getExecutionContext().get("JOBID"));
                    return RepeatStatus.FINISHED;
                })
                .build();
    }

    @Bean
    public Job job(Step copyRemoteFilesStep) {

        return jobBuilderFactory.get("copyFile")
                .incrementer(new RunIdIncrementer())
                .listener(scp)
                .flow(copyRemoteFilesStep)
                .end()
                .build();
    }

    @Scheduled(cron = "${scp.cron}")
    public void perform() throws Exception {

        Map<String, JobParameter> params = new HashMap<>();
        JobParameter jobParameter = new JobParameter(new Date());
        params.put("start-date", jobParameter);
        JobParameters jobParameters = new JobParameters(params);
        jobLauncher(jobRepository(mapJobRepositoryFactory(transactionManager()))).run(job(copyRemoteFilesStep()), jobParameters);
    }
}
