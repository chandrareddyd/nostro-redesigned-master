package com.dbs.daas.fitch.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;

import java.util.HashMap;
import java.util.Map;

public class JSCHLogger implements com.jcraft.jsch.Logger {

    protected static final Logger LOGGER = LoggerFactory.getLogger(JSCHLogger.class);
    private Map<Integer, Level> levels = new HashMap<>();

    public JSCHLogger() {
        // Mapping between JSch levels and our own levels
        levels.put(DEBUG, Level.DEBUG);
        levels.put(INFO, Level.INFO);
        levels.put(WARN, Level.WARN);
        levels.put(ERROR, Level.ERROR);
        levels.put(FATAL, Level.TRACE);
    }

    @Override
    public boolean isEnabled(int pLevel) {
        return true; // here, all levels enabled 
    }

    @Override
    public void log(int pLevel, String pMessage) {
        Level level = levels.get(pLevel);
        if (level == null) {
            level = Level.INFO;
        }
        LOGGER.info(pMessage); // logging-framework dependent...
    }
}
