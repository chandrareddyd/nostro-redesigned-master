package com.dbs.daas.fitch.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dbs.daas.fitch.exception.APIException;
import com.dbs.daas.fitch.model.ApiConstants;
import com.dbs.daas.fitch.model.SchemaModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class MessageHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageHandler.class);

    static byte[] msg = null;

    public static void publishMessage(SchemaModel model) throws IOException, TimeoutException, APIException {
        ConnectionFactory factory = new ConnectionFactory();
        Connection connection = null;
        Channel channel = null;

        if (model != null) {
            factory.setVirtualHost(model.getMqVirtualHost());
            factory.setHost(model.getMqHost());
            factory.setPort(model.getMqPort());
            factory.setUsername(model.getMqUsername());
            factory.setPassword(model.getMqPassword());
            if (null != model.getMqPassword()) {
                factory.setPassword(CommonUtil.decrypt(model.getMqPassword()));
            }
            try {
                connection = factory.newConnection();
                channel = connection.createChannel();
                channel.exchangeDeclare(model.getTopicName(), "fanout", true);
                Map<String, String> messageToSend = new HashMap<>();
                messageToSend.put("appName", model.getAppName());
                messageToSend.put("serviceName", ApiConstants.SERVICE_NAME);
                messageToSend.put("date", CommonUtil.dateFormatter(ApiConstants.YYYYMMDD));
                messageToSend.put("message", ApiConstants.NOTIFICATION_MSG);
                ObjectMapper objectMapper = new ObjectMapper();
                LOGGER.info("Publishing notification message for app: " + model.getAppName() + "  in queue: " + model.getTopicName());
                channel.basicPublish(model.getTopicName(), "", null, objectMapper.writeValueAsBytes(messageToSend));

            } finally {
                if (null != channel) {
                    channel.close();
                }
                if (null != channel) {
                    connection.close();
                }
            }
        }
    }

}