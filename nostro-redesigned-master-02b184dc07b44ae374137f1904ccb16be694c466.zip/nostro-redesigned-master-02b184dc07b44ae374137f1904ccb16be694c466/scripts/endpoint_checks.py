import requests
import json


def check_position_date(response, position_date):
    for entity in response['content']:
        if entity['positionDate'] != position_date:
            print('error. mismatch date: %s' % entity['positionDate'])


def create_session():
    session = requests.Session()
    session.trust_env = False
    return session


def registration(session, app_link, payload):
    registration_response = session.post(app_link + 'register', data=payload, headers={"content-type": "application/json"})
    return registration_response.status_code


# fetch data
def fetch_data_as_stream(session, app_link, app_name):
    fetch_data_url = app_link + app_name + '?replay=N&size=50'
    returned_payload = session.get(fetch_data_url)
    return json.loads(returned_payload.text)


if __name__ == '__main__':

    app_url = 'http://localhost:8080/nostro/v1/'
    registration_payload = '{"appName": "daas-nostro-1", "model": null, "topicName": null,"uriConn":null}'
    session_ = create_session()
    return_status_code = registration(session_, app_url, registration_payload)
    if return_status_code != 201:
        print('error registering app: %s' % return_status_code)

    page0 = fetch_data_as_stream(session_, app_url, 'daas-nostro-1')
    check_position_date(page0, '03012016')
