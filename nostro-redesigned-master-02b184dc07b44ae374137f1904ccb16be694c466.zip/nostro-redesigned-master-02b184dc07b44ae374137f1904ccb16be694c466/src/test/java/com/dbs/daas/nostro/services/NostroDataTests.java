package com.dbs.daas.nostro.services;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;

import java.io.InputStream;
import java.util.List;

import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.daas.nostro.batch.SCPBatch;
import com.dbs.daas.nostro.model.BatchFile;
import com.dbs.daas.nostro.model.EntityData;
import com.dbs.daas.nostro.model.SchemaModel;
import com.dbs.daas.nostro.model.SchemaModelDTO;
import com.dbs.daas.nostro.repositories.BatchFileRepository;
import com.dbs.daas.nostro.repositories.ClientStateRepository;
import com.dbs.daas.nostro.repositories.EntityDataRepository;
import com.dbs.daas.nostro.repositories.NotificationRepository;
import com.dbs.daas.nostro.utils.ApiConstants;
import com.dbs.daas.nostro.utils.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NostroDataTests {
	
	@Autowired
    private EntityDataRepository entityDataRepository;
    
    @Autowired
    private BatchFileRepository fileRepository;
    
    @Autowired
    ClientStateRepository clientStateRepository;
    
    @Autowired
    NotificationRepository notificationRepository;
    
    @Autowired
    private SchemaModelService schemaModelService;

    private final ObjectMapper mapper = new ObjectMapper();
    
    @Autowired
    private EntityDataService entityDataService;
    
    @Autowired
    private SCPBatch scpBatch;
    
    private Long timestampDate1;
    
    private Long timestampDate2;
	
	@Before
    public void setUp() throws Exception {
		entityDataRepository.deleteAll();
		fileRepository.deleteAll();
        clientStateRepository.deleteAll();
        notificationRepository.deleteAll();
        
        timestampDate1 = CommonUtil.stringToDate(ApiConstants.YYYYMMDD, "20170301").getTime();
        
        timestampDate2 = CommonUtil.stringToDate(ApiConstants.YYYYMMDD, "20160102").getTime();

    }

    @After
    public void tearDown() throws Exception {
		entityDataRepository.deleteAll();
		fileRepository.deleteAll();
        clientStateRepository.deleteAll();
        notificationRepository.deleteAll();
    }

    private void ingestData(String srcFile) throws Exception {  
    	InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(srcFile);
    	entityDataService.processFile(inputStream, "xxxxxxx", 0);
    }


    @Test
    public void testSavedDataCount() throws Exception {
        ingestData("SG_PSGL_TRAN.DAT");
        ingestData("HK_PSGL_Nostro.txt");

        assertThat(entityDataRepository.count(),equalTo(1043L));
    }

    @Test
    public void testGetLatestDataEntity() throws Exception {
        ingestData("SG_PSGL_TRAN.DAT");
        ingestData("HK_PSGL_Nostro.txt");

        assertThat(entityDataRepository.count(),equalTo(1043L));

        EntityData latest = entityDataRepository.getLatestDataEntity();

        assertThat(latest.getDateOfIngestion(), notNullValue());
    }

    @Test
    public void testGetAllByPositionDate() throws Exception {
        ingestData("SG_PSGL_TRAN.DAT");
        ingestData("HK_PSGL_Nostro.txt");

        assertThat(entityDataRepository.count(),equalTo(1043L));
        
        List<EntityData> data1 = entityDataRepository.getAllByPositionDate(timestampDate1);

        assertThat(data1, notNullValue());
        
        assertEquals(704L, data1.size());
        
        List<EntityData> data2 = entityDataRepository.getAllByPositionDate(timestampDate2);

        assertThat(data2, notNullValue());
        
        assertEquals(339L, data2.size());
    }

    @Test
    public void testGetExistingRecord() throws Exception {
        ingestData("SG_PSGL_TRAN.DAT");
        ingestData("HK_PSGL_Nostro.txt");

        assertThat(entityDataRepository.count(),equalTo(1043L));

        EntityData entityData = entityDataRepository.getExistingRecord(timestampDate1, "01032017", "10000010", "AUD", "SG");

        assertThat(entityData, notNullValue());
        
        assertThat(entityData.getDateOfIngestion(), notNullValue());

    }

    @Test
    public void testGetData_with_page_minus_1() throws Exception {

        ingestData("SG_PSGL_TRAN.DAT");
        ingestData("HK_PSGL_Nostro.txt");
        
        SchemaModelDTO dto = new SchemaModelDTO();
        dto.setAppName("daas-nostro-test");
        dto.setModel(null);
        dto.setTopicName(null);
        dto.setUriConn(null);

        schemaModelService.save(dto);

        SchemaModel model = schemaModelService.get("daas-nostro-test");

        String returnedData = entityDataService.getData(model, timestampDate1, "N", -1, 50, false);

        assertThat(returnedData,notNullValue());

        JSONObject jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("batchDate"), equalTo("01032017"));

        assertThat(jsonObject.get("totalElements"), equalTo(704));

    }

    @Test
    public void testGetData_with_replay_Y() throws Exception {

        ingestData("SG_PSGL_TRAN.DAT");
        ingestData("HK_PSGL_Nostro.txt");
        
        SchemaModelDTO dto = new SchemaModelDTO();
        dto.setAppName("daas-nostro-test");
        dto.setModel(null);
        dto.setTopicName(null);
        dto.setUriConn(null);

        schemaModelService.save(dto);

        SchemaModel model = schemaModelService.get("daas-nostro-test");

        String returnedData = entityDataService.getData(model, null, "Y", 2, 50, true);

        assertThat(returnedData,notNullValue());

        JSONObject jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("batchDate"), equalTo("01032017"));

        assertThat(jsonObject.get("totalElements"), equalTo(704));

    }

    @Test
    public void testPageConsistency() throws Exception {
    	ingestData("SG_PSGL_TRAN.DAT");
        ingestData("HK_PSGL_Nostro.txt");
        
        SchemaModelDTO dto = new SchemaModelDTO();
        dto.setAppName("daas-nostro-test-consistency");
        dto.setModel(null);
        dto.setTopicName(null);
        dto.setUriConn(null);

        schemaModelService.save(dto);

        SchemaModel model = schemaModelService.get("daas-nostro-test-consistency");

        String returnedData0 = entityDataService.getData(model, timestampDate1,"N", 1, 50, false);

        assertThat(returnedData0, notNullValue());

        JSONObject jsonObject = new JSONObject(returnedData0);

        assertThat(jsonObject.get("batchDate"),equalTo("01032017"));

        assertThat(jsonObject.get("totalElements"),equalTo(704));
        
        assertThat(jsonObject.get("pageNumber"), equalTo(1));

        String returnedData1 = entityDataService.getData(model, timestampDate1,"N", 1, 50, false);

        JSONObject jsonObject1 = new JSONObject(returnedData1);

        assertThat(jsonObject1.get("pageNumber"), equalTo(1));

        assertThat((jsonObject.get("content")).toString(),equalToIgnoringCase((jsonObject1.get("content")).toString()));

    }
    
    @Test
    public void testGetData_with_Different_BatchDate() throws Exception {

        SchemaModelDTO dto = new SchemaModelDTO();
        dto.setAppName("daas-nostro-test");
        dto.setModel(null);
        dto.setTopicName(null);
        dto.setUriConn(null);

        schemaModelService.save(dto);

        SchemaModel model = schemaModelService.get("daas-nostro-test");			

    	ingestData("SG_PSGL_TRAN.DAT"); // ingest data for 01032017

        String returnedData = entityDataService.getData(model, timestampDate1, "N", -1, 50, false); // get page 0

        assertThat(returnedData,notNullValue());

        JSONObject jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(0));

        assertThat(jsonObject.get("batchDate"),equalTo("01032017"));

        assertThat(jsonObject.get("totalElements"),equalTo(704));

        returnedData = entityDataService.getData(model, timestampDate1,"N",-1, 50, false); // get page 1

        assertThat(returnedData,notNullValue());

        jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(1));

        assertThat(jsonObject.get("batchDate"),equalTo("01032017"));

        assertThat(jsonObject.get("totalElements"),equalTo(704));

        returnedData = entityDataService.getData(model, timestampDate1, "N", -1, 50, false); // get page 2

        assertThat(returnedData,notNullValue());

        jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(2));

        assertThat(jsonObject.get("batchDate"),equalTo("01032017"));

        assertThat(jsonObject.get("totalElements"),equalTo(704));

        ingestData("HK_PSGL_Nostro.txt"); // ingest data for 02012016

        returnedData = entityDataService.getData(model, timestampDate2,"N", -1, 50, false); // get page 0

        assertThat(returnedData,notNullValue());

        jsonObject = new JSONObject(returnedData);

        assertThat(jsonObject.get("pageNumber"), equalTo(3));

        assertThat(jsonObject.get("batchDate"),equalTo("02012016"));

        assertThat(jsonObject.get("totalElements"),equalTo(339));

    }

    @Test
    public void test_notifyUsers() throws Exception {
    	
    	SchemaModelDTO dto = new SchemaModelDTO();
        dto.setAppName("daas-nostro-test");
        dto.setModel(null);
        dto.setTopicName("daas-nostro-test");
        dto.setUriConn("amqp://2b0e93de-298f-4779-a0d8-3a8e62825946:hsuei5thtipuk0iejnnu685l50@10.92.206.40/f711d2a5-4958-43ab-9dfb-8fef3f5379ed");

        schemaModelService.save(dto);
        
        scpBatch.notifyUsers("12345", "XXXXXX");
        
        scpBatch.notifyUsers("12345", "XXXXXX");
        
        scpBatch.notifyUsers("12345", "YYYYYYY");
        
        scpBatch.notifyUsers("54321", "XXXXXX");
    	
    }

    @Test
    public void test_updateFileStatus() throws Exception {
    	
    	BatchFile batchFile = entityDataService.getBatchFile("XXXXXX");
    	
    	assertThat(batchFile, nullValue());
    	
    	scpBatch.updateFileStatus(ApiConstants.BATCH_FILE_STATUS_INPROGRESS, "12345", "XXXXXX", "file");
    	
    	batchFile = entityDataService.getBatchFile("XXXXXX");
    	
    	assertThat(batchFile, notNullValue());
    	
    	assertThat(batchFile.getStatus(),equalTo(ApiConstants.BATCH_FILE_STATUS_INPROGRESS));
    	
    }

    @Test
    public void test_updateFileStatus_for_two_files() throws Exception {
    	
    	BatchFile batchFile0 = entityDataService.getBatchFile("XXXXXX");
    	
    	assertThat(batchFile0, nullValue());
    	
    	BatchFile batchFile1 = entityDataService.getBatchFile("YYYYYY");
    	
    	assertThat(batchFile1, nullValue());
    	
    	scpBatch.updateFileStatus(ApiConstants.BATCH_FILE_STATUS_INPROGRESS, "12345", "XXXXXX", "YYYYYY", "file1", "file2");
    	
    	batchFile0 = entityDataService.getBatchFile("XXXXXX");
    	
    	assertThat(batchFile0, notNullValue());
    	
    	assertThat(batchFile0.getStatus(),equalTo(ApiConstants.BATCH_FILE_STATUS_INPROGRESS));
    	
    	batchFile1 = entityDataService.getBatchFile("YYYYYY");
    	
    	assertThat(batchFile1, notNullValue());
    	
    	assertThat(batchFile1.getStatus(),equalTo(ApiConstants.BATCH_FILE_STATUS_INPROGRESS));
    	
    	scpBatch.updateFileStatus(ApiConstants.BATCH_FILE_STATUS_PROCESSED, "12345", "XXXXXX", "YYYYYY", "file1", "file2");
    	
    	batchFile0 = entityDataService.getBatchFile("XXXXXX");
    	
    	assertThat(batchFile0, notNullValue());
    	
    	assertThat(batchFile0.getStatus(),equalTo(ApiConstants.BATCH_FILE_STATUS_PROCESSED));
    	
    	batchFile1 = entityDataService.getBatchFile("YYYYYY");
    	
    	assertThat(batchFile1, notNullValue());
    	
    	assertThat(batchFile1.getStatus(),equalTo(ApiConstants.BATCH_FILE_STATUS_PROCESSED));
    	
    }

}
