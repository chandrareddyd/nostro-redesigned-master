package com.dbs.daas.nostro.controllers;


import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.dbs.daas.nostro.fixtures.EntityDataFixture;
import com.dbs.daas.nostro.fixtures.SchemaModelDTOFixture;
import com.dbs.daas.nostro.fixtures.SchemaModelFixture;
import com.dbs.daas.nostro.model.SchemaModel;
import com.dbs.daas.nostro.model.SchemaModelDTO;
import com.dbs.daas.nostro.services.EntityDataService;
import com.dbs.daas.nostro.services.SchemaModelService;

@RunWith(SpringRunner.class)
@WebMvcTest(APIController.class)
public class APIControllerTests {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SchemaModelService schemaModelService;

    @MockBean
    private EntityDataService entityDataService;

    @Test
    public void getDataTest1() throws Exception {
        when(schemaModelService.get(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
        when(entityDataService.getData(any(SchemaModel.class), anyLong(), anyString(), anyInt(), anyInt(), anyBoolean())).thenReturn(EntityDataFixture.getData());

        this.mockMvc.perform(get("/nostro/v1/TEST-APP?replay=N&page=0&size=1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].accountNumber", is("11000178")));
    }

    @Test
    public void getDataTest2() throws Exception {
        when(schemaModelService.get(anyString())).thenReturn(null);
        when(entityDataService.getData(any(SchemaModel.class), anyLong(), anyString(), anyInt(), anyInt(),anyBoolean())).thenReturn(EntityDataFixture.getData());

        this.mockMvc.perform(get("/nostro/v1/TEST-APP?replay=N&page=0&size=1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    public void registerModelTest1() throws Exception {
        when(schemaModelService.save(any(SchemaModelDTO.class))).thenReturn(SchemaModelDTOFixture.getSchemaModelDTO());

        this.mockMvc.perform(post("/nostro/v1/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(SchemaModelDTOFixture.getJsonRequest())
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
    }

    @Test
    public void registerModelTest2() throws Exception {
        when(schemaModelService.save(any(SchemaModelDTO.class))).thenReturn(null);

        this.mockMvc.perform(post("/nostro/v1/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(SchemaModelDTOFixture.getJsonRequest())
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
    }

    @Test
    public void registerModelTest3() throws Exception {
        when(schemaModelService.save(any(SchemaModelDTO.class))).thenReturn(SchemaModelDTOFixture.getSchemaModelDTO());

        this.mockMvc.perform(post("/nostro/v1/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(SchemaModelDTOFixture.getInvalidJsonRequest())
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void deleteModelTest1() throws Exception {
        when(schemaModelService.get(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
        when(schemaModelService.delete(anyString())).thenReturn(true);

        String response = this.mockMvc.perform(delete("/nostro/v1/TEST-APP")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

        assertThat(response, equalTo("{\"status\":\"success\"}"));
    }

    @Test
    public void deleteModelTest2() throws Exception {
        when(schemaModelService.get(anyString())).thenReturn(null);
        when(schemaModelService.delete(anyString())).thenReturn(true);

        this.mockMvc.perform(delete("/nostro/v1/TEST-APP")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    public void deleteModelTest3() throws Exception {
        when(schemaModelService.get(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
        when(schemaModelService.delete(anyString())).thenReturn(false);

        this.mockMvc.perform(delete("/nostro/v1/TEST-APP")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
    }

    @Test
    public void deleteModelTest4() throws Exception {
        when(schemaModelService.get(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
        when(schemaModelService.delete(anyString())).thenReturn(null);

        this.mockMvc.perform(delete("/nostro/v1/TEST-APP")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
    }

    @Test
    public void getModel_withModelName() throws Exception {
        when(schemaModelService.get(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());

        this.mockMvc.perform(get("/nostro/v1/model/TEST-APP")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.mqUsername", is("2b0e93de-298f-4779-a0d8-3a8e62825946")));
    }

    @Test
    public void getModel_withInvalidModelName() throws Exception {
        when(schemaModelService.get(anyString())).thenReturn(null);

        this.mockMvc.perform(get("/nostro/v1/model/TEST-APP-INVALID")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }
}
