package com.dbs.daas.nostro.services;


import static com.dbs.daas.nostro.utils.CommonUtil.stringToDate;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.dbs.daas.nostro.config.SCPSourceOptionsMetadata;
import com.dbs.daas.nostro.exceptions.APIException;
import com.dbs.daas.nostro.fixtures.BatchFileFixture;
import com.dbs.daas.nostro.fixtures.ClientStateFixture;
import com.dbs.daas.nostro.fixtures.EntityDataFixture;
import com.dbs.daas.nostro.fixtures.SchemaModelFixture;
import com.dbs.daas.nostro.model.BatchFile;
import com.dbs.daas.nostro.model.ClientState;
import com.dbs.daas.nostro.model.EntityData;
import com.dbs.daas.nostro.repositories.BatchFileRepository;
import com.dbs.daas.nostro.repositories.EntityDataRepository;
import com.dbs.daas.nostro.utils.ApiConstants;


public class EntityDataServiceTests {
	
	@Mock
	private SCPSourceOptionsMetadata options;

    @Mock
    private EntityDataRepository entityDataRepository;

    @Mock
    private BatchFileRepository fileRepository;
    
    @Mock
    private ClientStateService clientStateService;

    private EntityDataService entityDataService;

    @Before
    public void setup() throws IOException {
        MockitoAnnotations.initMocks(this);

        entityDataService = new EntityDataService(options, entityDataRepository, fileRepository, clientStateService);
        

    }

	@Test
	public void getLatestTransactionTest() throws Exception{
		when(entityDataRepository.findAll()).thenReturn(EntityDataFixture.getEntityData());
		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0));
		EntityData data = entityDataService.getLatestTransaction();
		assertNotNull(data);
	}

	@Test
	public void checkFileForProcessingTest1() throws Exception{
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileProcessed());
		Boolean result = entityDataService.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(false, result);
	}

	@Test
	public void checkFileForProcessingTest2() throws Exception{
		when(fileRepository.exists(anyString())).thenReturn(false);
		Boolean result = entityDataService.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(true, result);
	}

	@Test
	public void checkFileForProcessingTest3() throws Exception{
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileInprogressBeforeTime());
		Boolean result = entityDataService.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(false, result);
	}

	@Test
	public void checkFileForProcessingTest4() throws Exception{
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileInprogressAfterTime());
		Boolean result = entityDataService.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(true, result);
	}

	@Test
	public void checkFileForProcessingTest5() throws Exception{
		when(fileRepository.exists(anyString())).thenReturn(true);
		when(fileRepository.findOne(anyString())).thenReturn(BatchFileFixture.getBatchFileMismatch());
		Boolean result = entityDataService.checkFileForProcessing("FILE_NAME", "CHECKSUM1234");
		assertNotNull(result);
		assertEquals(true, result);
	}

	@Test
	public void createOrUpdateStatusTest() throws Exception{
		when(fileRepository.save(any(BatchFile.class))).thenReturn(BatchFileFixture.getBatchFileInprogressAfterTime());
		entityDataService.createOrUpdateStatus(BatchFileFixture.getBatchFileInprogressAfterTime());
	}
	
	@Test
	public void getDataTest1() throws Exception {
		String timestamp = "31122015";

		when(entityDataRepository.getAllByPositionDate(any())).thenReturn(EntityDataFixture.getEntityData());
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		when(clientStateService.get(anyString())).thenReturn(ClientStateFixture.getClientState());

		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0));
		String json = entityDataService.getData(SchemaModelFixture.getSchemaModel(), stringToDate(ApiConstants.DDMMYYYY,timestamp).getTime(), "N", 0, 2, false);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
	}
	
	@Test
	public void getDataTest2() throws Exception {
		long timestamp = -1;
		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(entityDataRepository.getAllByPositionDate(-1L)).thenReturn(null);
		when(clientStateService.get(anyString())).thenReturn(null);
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = entityDataService.getData(SchemaModelFixture.getSchemaModel(), timestamp, "N", 0, 2, false);
        JSONObject jsonObject = new JSONObject(json);
        assertThat(jsonObject.has("remarks"),equalTo(true));
	}
	
	@Test
	public void getDataTest3() throws Exception{
		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(entityDataRepository.getAllByPositionDate(any())).thenReturn(EntityDataFixture.getEntityData());
		when(clientStateService.get(anyString())).thenReturn(null);
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = entityDataService.getData(SchemaModelFixture.getSchemaModel(), 0L, "N", 0, 2, true);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("content"));
		assertEquals(2, jsonObject.get("numberOfElements"));
        verify(clientStateService, Mockito.times(1)).save(any(ClientState.class));
	}
	
	@Test
	public void getDataTest4() throws IOException, NumberFormatException, APIException, JSONException {	
		when(entityDataRepository.getLatestDataEntity()).thenReturn(null);
		when(entityDataRepository.getAllByPositionDate(any())).thenReturn(null);
		when(clientStateService.get(anyString())).thenReturn(null);
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = entityDataService.getData(SchemaModelFixture.getSchemaModel(), 0L, "N", 0, 2, true);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
	}
	
	@Test
	public void getDataTest5() throws IOException, NumberFormatException, APIException, JSONException {	
		when(clientStateService.save(any(ClientState.class))).thenReturn(true);
		String json = entityDataService.getData(null, 0L, "N", 0, 2, true);
		JSONObject jsonObject = new JSONObject(json);
		assertNotNull(jsonObject);
		assertNotNull(jsonObject.get("totalElements"));
		assertEquals(0, jsonObject.get("totalElements"));
	}
	
	@Test(expected = APIException.class)
	public void getDataTest6() throws Exception {
        when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0));
        when(entityDataRepository.getAllByPositionDate(any())).thenReturn(EntityDataFixture.getEntityData());
		when(clientStateService.get(anyString())).thenReturn(null);
		when(clientStateService.save(any(ClientState.class))).thenReturn(false);
		String json = entityDataService.getData(SchemaModelFixture.getSchemaModel(), 0L, "N", 0, 2, true);
	}
	
	@Test(expected = APIException.class)
	public void getDataTest7() throws Exception {
		when(entityDataRepository.getLatestDataEntity()).thenReturn(EntityDataFixture.getEntityData().get(0));
		when(entityDataRepository.getAllByPositionDate(any())).thenReturn(null);
		when(clientStateService.get(anyString())).thenReturn(ClientStateFixture.getClientState());
		when(clientStateService.save(any(ClientState.class))).thenReturn(false);
		String json = entityDataService.getData(SchemaModelFixture.getSchemaModel(), 0L, "N", 0, 2, true);
	}
	



	/*@Test
	public void readPositionDateTest() throws IOException {		
		String result = entityDataService.readPositionDate(getFileSource(0), 0);
		assertNotNull(result);
	}
	
	@Test
	public void processFileTest() throws IOException {	
		when(entityDataRepository.save(any(EntityData.class))).thenReturn(EntityDataFixture.getEntityDataPage(0,  2).getContent().get(0));
		int totalCount = entityDataService.processFile(getFileSource(0), "checksum", 0);
		assertEquals(5, totalCount);
		verify(entityDataRepository, Mockito.times(3)).save(any(EntityData.class));
	}
    
	public InputStream getFileSource(Integer fileIndex) throws IOException {
		ClassLoader classLoader = this.getClass().getClassLoader();
		File file;
		URL fileUrl = null;
		if(0 == fileIndex) {
			fileUrl = classLoader.getResource(ApiConstants.DEFAULT_SG_FILE_NAME);
		} else if(1 == fileIndex) {
			fileUrl = classLoader.getResource(ApiConstants.DEFAULT_HK_FILE_NAME);
		}
		if(null != fileUrl) {
			file = new File(fileUrl.getFile());
			return new FileInputStream(file);
		} else {
			return null;
		}
	}*/
}
