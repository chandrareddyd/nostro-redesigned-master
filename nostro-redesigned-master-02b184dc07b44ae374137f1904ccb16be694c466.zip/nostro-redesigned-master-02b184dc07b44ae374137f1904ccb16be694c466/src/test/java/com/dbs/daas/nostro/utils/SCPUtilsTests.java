package com.dbs.daas.nostro.utils;

import static com.dbs.daas.nostro.utils.ApiConstants.BATCH_FILE_STATUS_DOESNOT_EXIST;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.Arrays;

import org.apache.sshd.common.NamedFactory;
import org.apache.sshd.common.file.virtualfs.VirtualFileSystemFactory;
import org.apache.sshd.server.Command;
import org.apache.sshd.server.SshServer;
import org.apache.sshd.server.keyprovider.SimpleGeneratorHostKeyProvider;
import org.apache.sshd.server.scp.ScpCommandFactory;
import org.apache.sshd.server.subsystem.sftp.SftpSubsystemFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.daas.nostro.batch.SCPBatch;
import com.dbs.daas.nostro.config.SCPSourceOptionsMetadata;
import com.dbs.daas.nostro.exceptions.APIException;
import com.dbs.daas.nostro.model.BatchFile;
import com.dbs.daas.nostro.repositories.BatchFileRepository;
import com.dbs.daas.nostro.repositories.ClientStateRepository;
import com.dbs.daas.nostro.repositories.EntityDataRepository;
import com.dbs.daas.nostro.repositories.NotificationRepository;
import com.dbs.daas.nostro.services.EntityDataService;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;


@RunWith(SpringRunner.class)
@Import(SCPSourceOptionsMetadata.class)
@SpringBootTest
public class SCPUtilsTests {

	@Autowired
    private SCPSourceOptionsMetadata options;

	@Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

	private static final String LOCALHOST = "localhost";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    private SshServer sshd;

    @Autowired
    private EntityDataRepository entityDataRepository;
    
    @Autowired
    private BatchFileRepository fileRepository;
    
    @Autowired
    ClientStateRepository clientStateRepository;
    
    @Autowired
    NotificationRepository notificationRepository;
    
    @Autowired
	private SCPUtils scpUtil;
    
    @Autowired
    private EntityDataService entityDataService;
    
    @Autowired
    private SCPBatch scpBatch;

	@Before
	public void setup() throws IOException, InterruptedException {
		
		entityDataRepository.deleteAll();
		fileRepository.deleteAll();
        clientStateRepository.deleteAll();
        notificationRepository.deleteAll();

		setupSSHServer();
	}

	@After
	public void teardown() throws IOException {
		
		entityDataRepository.deleteAll();
		fileRepository.deleteAll();
        clientStateRepository.deleteAll();
        notificationRepository.deleteAll();
        
		if(null != sshd) {
			sshd.stop();
		}
	}

    @Test
    public void authenticateScpServerTest() throws JSchException {
    	Session session = scpUtil.authenticateScpServer(options);
    	assertNotNull(session);
    }

    @Test
    public void getRemoteFileTest() throws IOException, JSchException {
    	File file = scpUtil.getRemoteFile(ApiConstants.DEFAULT_SG_FILE_NAME, scpUtil.authenticateScpServer(options), 0, ApiConstants.SG_TMP_FILE_NAME);
    	assertNotNull(file);
    	file.delete();
    }

    @Test
    public void checkOutstandingAmountSumTest() throws IOException, JSchException {
    	boolean result0 = scpUtil.checkOutstandingAmountSum(options, 0, new FileInputStream(getFileSource(0)));
    	assertNotNull(result0);
    	assertEquals(false, result0);

    	boolean result1 = scpUtil.checkOutstandingAmountSum(options, 0, new FileInputStream(getFileSource(1)));
    	assertNotNull(result1);
    	assertEquals(true, result1);
    }

    @Test
    public void test_scpBatch_processFile() throws Exception {
    	
    	String localFileChecksum = scpUtil.checksumLocalFile(new FileInputStream(getFileSource(0)));
    	
    	BatchFile batchFile = entityDataService.getBatchFile(localFileChecksum);
    	
    	assertNull(batchFile);
    	
    	int count = scpBatch.processFile("12345", getFileSource(0), 0, scpUtil.authenticateScpServer(options), localFileChecksum);
    	
    	batchFile = entityDataService.getBatchFile(localFileChecksum);
    	
    	assertNotNull(batchFile);
    	
    	assertThat(batchFile.getStatus(),equalTo(ApiConstants.BATCH_FILE_STATUS_PROCESSED));
    	
    	assertEquals(706, count);
    	
    }

    @Test
    public void test_scpBatch_processNullFile() throws Exception {
    	
    	String localFileChecksum = scpUtil.checksumLocalFile(new FileInputStream(getFileSource(0)));
    	
    	BatchFile batchFile = entityDataService.getBatchFile(localFileChecksum);
    	
    	assertNull(batchFile);
    	
    	int count = 0;
    			
    	try {    	
    		count = scpBatch.processFile("12345", null, 0, scpUtil.authenticateScpServer(options), localFileChecksum);
    	}
    	catch(IOException e) {
    		System.out.println("Error occured: " + e.getMessage());
    	} finally {
    		batchFile = entityDataService.getBatchFile(localFileChecksum);
        	
        	assertNotNull(batchFile);
        	
        	assertThat(batchFile.getStatus(),equalTo(ApiConstants.BATCH_FILE_STATUS_DOESNOT_EXIST));
        	
        	assertEquals(0, count);
    	}
    }

    @Test
    public void test_scpBatch_processInvalidFile() throws Exception {
    	
    	String localFileChecksum = "XXXXXX";
    	
    	BatchFile batchFile = entityDataService.getBatchFile(localFileChecksum);
    	
    	assertNull(batchFile);
    	
    	int count = scpBatch.processFile("12345", getFileSource(0), 0, scpUtil.authenticateScpServer(options), localFileChecksum);
    	
    	batchFile = entityDataService.getBatchFile(localFileChecksum);
    	
    	assertNotNull(batchFile);
    	
    	assertThat(batchFile.getStatus(),equalTo(ApiConstants.BATCH_FILE_STATUS_MISMATCH));
    	
    	assertEquals(0, count);
    	
    }

    private void setupSSHServer() throws IOException, InterruptedException {
    	File file0 = getFileSource(0);
		Files.copy(file0.toPath(), tempFolder.getRoot().toPath().resolve(file0.getName()));
		File file1 = getFileSource(1);
		Files.copy(file1.toPath(), tempFolder.getRoot().toPath().resolve(file1.getName()));

    	sshd = SshServer.setUpDefaultServer();
        sshd.setFileSystemFactory(new VirtualFileSystemFactory(tempFolder.getRoot().toPath()));
        sshd.setHost(LOCALHOST);
        sshd.setPort(22222);
        sshd.setSubsystemFactories(Arrays.<NamedFactory<Command>>asList(new SftpSubsystemFactory()));
        sshd.setCommandFactory(new ScpCommandFactory());
        sshd.setKeyPairProvider(new SimpleGeneratorHostKeyProvider(tempFolder.newFile("hostkey.ser")));
        sshd.setPasswordAuthenticator((username, password, session) -> USERNAME.equals(username) && PASSWORD.equals(password));
        sshd.start();
    }

	private File getFileSource(Integer fileIndex) throws IOException {
		ClassLoader classLoader = this.getClass().getClassLoader();
		URL fileUrl = null;
		if(0 == fileIndex) {
			fileUrl = classLoader.getResource(ApiConstants.DEFAULT_SG_FILE_NAME);
		} else if(1 == fileIndex) {
				fileUrl = classLoader.getResource(ApiConstants.DEFAULT_HK_FILE_NAME);
			}
		if(null != fileUrl) {
			return new File(fileUrl.getFile());
		} else {
			return null;
		}
	}

}