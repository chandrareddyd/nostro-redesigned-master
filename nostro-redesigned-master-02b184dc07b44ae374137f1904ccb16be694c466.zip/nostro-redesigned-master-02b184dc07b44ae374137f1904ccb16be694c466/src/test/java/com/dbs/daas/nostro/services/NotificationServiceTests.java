package com.dbs.daas.nostro.services;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.dbs.daas.nostro.fixtures.NotificationFixture;
import com.dbs.daas.nostro.model.Notification;
import com.dbs.daas.nostro.repositories.NotificationRepository;


public class NotificationServiceTests {

    @Mock
    private NotificationRepository notificationRepository;

    private NotificationService service;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        service = new NotificationService(notificationRepository);
    }

    @Test
    public void getTest() throws Exception{
        when(notificationRepository.findOne(anyString())).thenReturn(NotificationFixture.getNotification());
        Notification state = service.get("TEST-APP");
        assertNotNull(state);
    }

    @Test
    public void saveTest1() throws Exception {
        when(notificationRepository.save(any(Notification.class))).thenReturn(NotificationFixture.getNotification());
        boolean result = service.save(NotificationFixture.getNotification());
        assertEquals(true, result);
        verify(notificationRepository, Mockito.times(1)).save(any(Notification.class));
    }

    @Test
    public void saveTest2() throws Exception {
        when(notificationRepository.save(any(Notification.class))).thenReturn(null);
        boolean result = service.save(NotificationFixture.getNotification());
        assertEquals(false, result);
        verify(notificationRepository, Mockito.times(1)).save(any(Notification.class));
    }

}
