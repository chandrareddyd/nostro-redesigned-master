package com.dbs.daas.nostro.fixtures;


import com.dbs.daas.nostro.model.SchemaModelDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.Arrays;

public class SchemaModelDTOFixture {
    public static SchemaModelDTO getSchemaModelDTO() {

        SchemaModelDTO dto = new SchemaModelDTO();

        dto.setAppName("TEST-APP");
        dto.setModel(new ArrayList<String>(Arrays.asList("fileName", "valueDate", "accountNumber", "outstandingAmount", "country")));
        dto.setTopicName("TEST-APP-MQ");
        dto.setUriConn("amqp://2b0e93de-298f-4779-a0d8-3a8e62825946:hsuei5thtipuk0iejnnu685l50@10.92.206.40/f711d2a5-4958-43ab-9dfb-8fef3f5379ed");

        return dto;
    }

    public static String getJsonRequest() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(getSchemaModelDTO());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getInvalidJsonRequest() {
        ObjectMapper mapper = new ObjectMapper();
        SchemaModelDTO dto = getSchemaModelDTO();
        dto.setAppName(null);
        try {
            return mapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }
}
