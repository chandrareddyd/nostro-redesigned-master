package com.dbs.daas.nostro.services;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.daas.nostro.config.GeodeTestConfig;
import com.dbs.daas.nostro.exceptions.APIException;
import com.dbs.daas.nostro.fixtures.ClientStateFixture;
import com.dbs.daas.nostro.fixtures.SchemaModelDTOFixture;
import com.dbs.daas.nostro.fixtures.SchemaModelFixture;
import com.dbs.daas.nostro.model.SchemaModel;
import com.dbs.daas.nostro.model.SchemaModelDTO;
import com.dbs.daas.nostro.repositories.SchemaModelRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = GeodeTestConfig.class)
public class SchemaModelServiceTests {

    @Mock
    private SchemaModelRepository schemaModelRepository;

    @Mock
    private ClientStateService clientStateService;

    private SchemaModelService service;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        service = new SchemaModelService(schemaModelRepository, clientStateService);
    }
	
	@Test
	public void deleteTest1() throws Exception{
		when(clientStateService.get(anyString())).thenReturn(ClientStateFixture.getClientState());
		when(clientStateService.delete(anyString())).thenReturn(true);
		doNothing().when(schemaModelRepository).delete(anyString());
		service.delete("TEST-APP");
	}
	
	@Test
	public void deleteTest2() {	
		when(clientStateService.get(anyString())).thenReturn(null);
		doNothing().when(schemaModelRepository).delete(anyString());
		service.delete("TEST-APP");
	}

    @Test
    public void getTest1() throws APIException {
        when(schemaModelRepository.findAll()).thenReturn(SchemaModelFixture.getSchemaModels());
        List<SchemaModel> models = service.get();
        assertNotNull(models);
        assertEquals(2, models.size());
    }

    @Test
    public void getTest2() throws APIException {
        when(schemaModelRepository.findOne(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
        SchemaModel model = service.get("TEST-APP");
        assertNotNull(model);
    }

    @Test
    public void saveTest1() throws IOException, APIException {
        when(schemaModelRepository.findOne(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
        when(schemaModelRepository.save(any(SchemaModel.class))).thenReturn(SchemaModelFixture.getSchemaModel());
        SchemaModelDTO dto = service.save(SchemaModelDTOFixture.getSchemaModelDTO());
        assertNotNull(dto);
        verify(schemaModelRepository, Mockito.times(1)).save(any(SchemaModel.class));
    }

    @Test
    public void saveTest2() throws IOException, APIException {
        SchemaModelDTO inputDTO = SchemaModelDTOFixture.getSchemaModelDTO();
        inputDTO.setTopicName(null);
        inputDTO.setUriConn(null);
        when(schemaModelRepository.findOne(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
        when(schemaModelRepository.save(any(SchemaModel.class))).thenReturn(SchemaModelFixture.getSchemaModel());
        SchemaModelDTO dto = service.save(inputDTO);
        assertNotNull(dto);
        verify(schemaModelRepository, Mockito.times(1)).save(any(SchemaModel.class));
    }

    @Test
    public void saveTest3() throws IOException, APIException {
        SchemaModelDTO inputDTO = SchemaModelDTOFixture.getSchemaModelDTO();
        inputDTO.setModel(null);
        when(schemaModelRepository.findOne(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
        when(schemaModelRepository.save(any(SchemaModel.class))).thenReturn(SchemaModelFixture.getSchemaModel());
        SchemaModelDTO dto = service.save(inputDTO);
        assertNotNull(dto);
        verify(schemaModelRepository, Mockito.times(1)).save(any(SchemaModel.class));
    }

    @Test(expected = APIException.class)
    public void saveTest4() throws IOException, APIException {
        SchemaModelDTO inputDTO = SchemaModelDTOFixture.getSchemaModelDTO();
        inputDTO.setUriConn("dsfdsfdsfljfk");
        when(schemaModelRepository.findOne(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
        when(schemaModelRepository.save(any(SchemaModel.class))).thenReturn(SchemaModelFixture.getSchemaModel());
        SchemaModelDTO dto = service.save(inputDTO);
    }

	@Test
	public void saveTest5() throws IOException, APIException {
		SchemaModelDTO inputDTO = SchemaModelDTOFixture.getSchemaModelDTO();
		inputDTO.setModel(null);
		when(schemaModelRepository.findOne(anyString())).thenReturn(SchemaModelFixture.getSchemaModel());
		when(schemaModelRepository.save(any(SchemaModel.class))).thenReturn(null);
		SchemaModelDTO dto = service.save(inputDTO);
		assertNull(dto);
		verify(schemaModelRepository, Mockito.times(1)).save(any(SchemaModel.class));
	}
}
