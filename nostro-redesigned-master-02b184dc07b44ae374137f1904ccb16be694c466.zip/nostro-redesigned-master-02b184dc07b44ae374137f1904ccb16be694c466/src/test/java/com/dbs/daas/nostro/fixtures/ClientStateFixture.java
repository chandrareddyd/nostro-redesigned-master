package com.dbs.daas.nostro.fixtures;


import com.dbs.daas.nostro.utils.ApiConstants;
import com.dbs.daas.nostro.model.ClientState;

import static com.dbs.daas.nostro.utils.CommonUtil.dateFormatter;
import static com.dbs.daas.nostro.utils.CommonUtil.stringToDate;


public class ClientStateFixture {
    public static ClientState getClientState() throws Exception{
        return new ClientState("TEST-APP", 0, System.currentTimeMillis(), stringToDate(ApiConstants.DDMMYYYY,"31122015").getTime());
    }
}
