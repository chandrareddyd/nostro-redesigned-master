package com.dbs.daas.nostro.fixtures;

import com.dbs.daas.nostro.model.BatchFile;
import com.dbs.daas.nostro.utils.ApiConstants;

public class BatchFileFixture {
    public static BatchFile getBatchFileProcessed() {
    	long sixHours = 6 * 60 * 60 * 1000;
        long sixHoursAhead = System.currentTimeMillis() + sixHours;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM1234");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(sixHoursAhead + sixHoursAhead + 10);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_PROCESSED);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
    
    public static BatchFile getBatchFileInprogressBeforeTime() {
    	long oneHours = 1 * 60 * 60 * 1000;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM1234");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(System.currentTimeMillis() + oneHours);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_INPROGRESS);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
    
    public static BatchFile getBatchFileInprogressAfterTime() {
    	long oneHours = 1 * 60 * 60 * 1000;
    	long sixHours = 6 * 60 * 60 * 1000;
        long sixHoursAhead = System.currentTimeMillis() - sixHours;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM1234");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(sixHoursAhead - oneHours);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_INPROGRESS);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
    
    public static BatchFile getBatchFileMismatch() {
    	long sixHours = 6 * 60 * 60 * 1000;
        long sixHoursAhead = System.currentTimeMillis() + sixHours;
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum("CHECKSUM12345");
        batchFile.setFileSource("FILE_SOURCE");
        batchFile.setDatetime(sixHoursAhead);
        batchFile.setStatus(ApiConstants.BATCH_FILE_STATUS_MISMATCH);
        batchFile.setBatchId("JOB_ID_1234");
        return batchFile;
    }
}
