package com.dbs.daas.nostro.utils;


import com.dbs.daas.nostro.config.SCPSourceOptionsMetadata;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;


public class FixedLengthPayloadParserTests {
	
	private SCPSourceOptionsMetadata options;
	
	private FixedLengthPayloadParser parser;
	
	@Before
	public void setup() {
		parser = new FixedLengthPayloadParser();
		
		options = new SCPSourceOptionsMetadata();
    	
    	Map<Integer, String> fileNames = new HashMap<>();
        fileNames.put(0, ApiConstants.DEFAULT_SG_FILE_NAME);

        options.setFileNames(fileNames);

        Map<Integer, String[]> headerColumnNames = new HashMap<>();
        headerColumnNames.put(0, new String[]{"positionDate"});

        options.setHeaderColumnNames(headerColumnNames);

        Map<Integer, String[]> headerColumnRanges = new HashMap<>();
        headerColumnRanges.put(0, new String[]{"1-8"});

        options.setHeaderColumnRanges(headerColumnRanges);

        Map<Integer, String[]> columnNames = new HashMap<>();
        columnNames.put(0, new String[]{"valueDate", "accountNumber", "currency", "outstandingAmount"});

        options.setColumnNames(columnNames);

        Map<Integer, String[]> columnRanges = new HashMap<>();
        columnRanges.put(0, new String[]{"1-8", "135-154", "271-273", "274-294"});

        options.setColumnRanges(columnRanges);

        Map<Integer, Boolean> validateCountInFooter = new HashMap<>();
        validateCountInFooter.put(0, true);

        options.setValidateCountInFooter(validateCountInFooter);
        
        Map<Integer, String[]> footerCountColumnRange = new HashMap<>();
        footerCountColumnRange.put(0, new String[]{"2-21", "22-51"});

        options.setFooterCountColumnRange(footerCountColumnRange);
	}

    @Test
    public void parseHeaderTest() {
    	Map<String, Object> result = parser.parseHeader("31122015  ", options, 0);
    	assertNotNull(result);
    	assertNotNull(result.get("positionDate"));
    }

    @Test
    public void parsePayloadTest() {
    	String payload = "31122015                                                                                                                              11000161                                                                                                                                EUR000000000000888972.08                                                                                       ";
    	Map<String, Object> result = parser.parsePayload(payload, options, 0);
    	assertNotNull(result);
    	assertNotNull(result.get("valueDate"));
    	assertNotNull(result.get("accountNumber"));
    	assertNotNull(result.get("currency"));
    	assertNotNull(result.get("outstandingAmount"));
    }

    @Test
    public void parseFooterTest() {
    	Map<String, Object> result = parser.parseFooter("C00000000000000000019000000000000000011790495614.33", options, 0);
    	assertNotNull(result);
    	assertNotNull(result.get("FOOTER_COUNT"));
    }
}