package com.dbs.daas.nostro.services;

import com.dbs.daas.nostro.config.SCPSourceOptionsMetadata;
import com.dbs.daas.nostro.utils.FixedLengthPayloadParser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;

import static org.junit.Assert.assertEquals;

/**
 * Created by carlos on 15/02/2017.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class EntityDataServiceFileProcessingTests {

    @Autowired
    SCPSourceOptionsMetadata options;

    private BufferedReader br;

    private FixedLengthPayloadParser parser;

    @Autowired
    private EntityDataService entityDataService;


    @Before
    public void setUp() throws Exception {
        parser = new FixedLengthPayloadParser();
    }

    @Test
    public void saveFileDataTest1() throws IOException {
        String header = "31122015  ";
        String payload = "31122015                                                                                                                              10000010                                                                                                                                AUD-00000000940739096.80                                                                                       ";
        String footer = "C00000000000000000004000000000000000049376867003.27";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(payload);
        stringBuilder.append("\n");
        stringBuilder.append(footer);
        StringReader stringReader = new StringReader(stringBuilder.toString());
        br = new BufferedReader(stringReader);
        int result = entityDataService.saveFileData(parser, br, header, 0, "31122015", "checksum");
        assertEquals(3, result);
    }

    @Test
    public void saveFileDataTest2() throws IOException {
        String header = "31122015  ";
        String payload = "";
        String footer = "C00000000000000000003000000000000000049376867003.27";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(payload);
        stringBuilder.append("\n");
        stringBuilder.append(footer);
        StringReader stringReader = new StringReader(stringBuilder.toString());
        br = new BufferedReader(stringReader);
        int result = entityDataService.saveFileData(parser, br, header, 0, "31122015", "checksum");
        assertEquals(3, result);
    }
}
