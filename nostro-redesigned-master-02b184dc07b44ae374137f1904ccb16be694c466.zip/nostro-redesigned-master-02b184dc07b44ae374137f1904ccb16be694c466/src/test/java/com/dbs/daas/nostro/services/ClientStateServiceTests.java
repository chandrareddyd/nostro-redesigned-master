package com.dbs.daas.nostro.services;


import com.dbs.daas.nostro.fixtures.ClientStateFixture;
import com.dbs.daas.nostro.model.ClientState;
import com.dbs.daas.nostro.repositories.ClientStateRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;


public class ClientStateServiceTests {

    @Mock
    private ClientStateRepository clientStateRepository;

    private ClientStateService service;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        service = new ClientStateService(clientStateRepository);
    }

    @Test
    public void getByAppNameTest() throws Exception{
        when(clientStateRepository.findOne(anyString())).thenReturn(ClientStateFixture.getClientState());
        ClientState state = service.get("TEST-APP");
        assertNotNull(state);
    }

    @Test
    public void saveTest1() throws Exception {
        when(clientStateRepository.save(any(ClientState.class))).thenReturn(ClientStateFixture.getClientState());
        boolean result = service.save(ClientStateFixture.getClientState());
        assertEquals(true, result);
        verify(clientStateRepository, Mockito.times(1)).save(any(ClientState.class));
    }

    @Test
    public void saveTest2() throws Exception {
        when(clientStateRepository.save(any(ClientState.class))).thenReturn(null);
        boolean result = service.save(ClientStateFixture.getClientState());
        assertEquals(false, result);
        verify(clientStateRepository, Mockito.times(1)).save(any(ClientState.class));
    }
	
	@Test
	public void deleteTest() {	
		doNothing().when(clientStateRepository).delete(anyString());
		service.delete("TEST-APP");
	}

}
