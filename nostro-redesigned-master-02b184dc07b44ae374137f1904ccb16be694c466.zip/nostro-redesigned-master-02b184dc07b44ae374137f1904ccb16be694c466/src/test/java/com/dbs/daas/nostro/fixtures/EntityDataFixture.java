package com.dbs.daas.nostro.fixtures;

import com.dbs.daas.nostro.model.EntityData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.dbs.daas.nostro.utils.ApiConstants.DDMMYYYY;
import static com.dbs.daas.nostro.utils.CommonUtil.stringToDate;

public class EntityDataFixture {
    public static Page<EntityData> getEntityDataPage(int page, int size) throws Exception{
        List<EntityData> entityDataList = getEntityData();

        PagedListHolder<EntityData> holder = new PagedListHolder<>(entityDataList);
        holder.setPage(page);
        holder.setPageSize(size);

        return new PageImpl<>(holder.getPageList(), createPageRequest(page, size), entityDataList.size());
    }

    public static List<EntityData> getEntityData() throws Exception{
        List<EntityData> entityDataList = new ArrayList<>();

        EntityData entityData = new EntityData();
        entityData.setFileName("HK_PSGL_Nostro.txt");
        entityData.setFileType("Outstanding");
        entityData.setPositionDate(stringToDate(DDMMYYYY,"31122015").getTime());
        entityData.setFileSource("PSGL");
        entityData.setValueDate("31122015");
        entityData.setAccountNumber("11000178");
        entityData.setCurrency("USD");
        entityData.setOutstandingAmount("000000000000000034.40");
        entityData.setCountry("HKL");
        entityData.setDateOfIngestion(stringToDate(DDMMYYYY,"20170112").getTime());
        entityDataList.add(entityData);

        entityData = new EntityData();
        entityData.setFileName("HK_PSGL_Nostro.txt");
        entityData.setFileType("Outstanding");
        entityData.setPositionDate(stringToDate(DDMMYYYY,"31122015").getTime());
        entityData.setFileSource("PSGL");
        entityData.setValueDate("31122015");
        entityData.setAccountNumber("11000174");
        entityData.setCurrency("USD");
        entityData.setOutstandingAmount("000000000000000000.00");
        entityData.setCountry("HKL");
        entityData.setDateOfIngestion(stringToDate(DDMMYYYY,"20170112").getTime());
        entityDataList.add(entityData);

        entityData = new EntityData();
        entityData.setFileName("HK_PSGL_Nostro.txt");
        entityData.setFileType("Outstanding");
        entityData.setPositionDate(stringToDate(DDMMYYYY,"31122015").getTime());
        entityData.setFileSource("PSGL");
        entityData.setValueDate("31122015");
        entityData.setAccountNumber("11000175");
        entityData.setCurrency("SGD");
        entityData.setOutstandingAmount("000000000000000000.00");
        entityData.setCountry("HKL");
        entityData.setDateOfIngestion(stringToDate(DDMMYYYY,"20170112").getTime());
        entityDataList.add(entityData);

        entityData = new EntityData();
        entityData.setFileName("PSGL_TRAN.DAT");
        entityData.setFileType("Outstanding");
        entityData.setPositionDate(stringToDate(DDMMYYYY,"31122015").getTime());
        entityData.setFileSource("PSGL");
        entityData.setValueDate("31122015");
        entityData.setAccountNumber("10000520");
        entityData.setCurrency("CAD");
        entityData.setOutstandingAmount("000000004363283904.65");
        entityData.setCountry("SG");
        entityData.setDateOfIngestion(stringToDate(DDMMYYYY,"20170112").getTime());
        entityDataList.add(entityData);

        entityData = new EntityData();
        entityData.setFileName("PSGL_TRAN.DAT");
        entityData.setFileType("Outstanding");
        entityData.setPositionDate(stringToDate(DDMMYYYY,"31122015").getTime());
        entityData.setFileSource("PSGL");
        entityData.setValueDate("31122015");
        entityData.setAccountNumber("10000040");
        entityData.setCurrency("AUD");
        entityData.setOutstandingAmount("-00000000929914145.71");
        entityData.setCountry("SG");
        entityData.setDateOfIngestion(stringToDate(DDMMYYYY,"20170112").getTime());
        entityDataList.add(entityData);

        entityData = new EntityData();
        entityData.setFileName("PSGL_TRAN.DAT");
        entityData.setFileType("Outstanding");
        entityData.setPositionDate(stringToDate(DDMMYYYY,"31122015").getTime());
        entityData.setFileSource("PSGL");
        entityData.setValueDate("31122015");
        entityData.setAccountNumber("10000020");
        entityData.setCurrency("AUD");
        entityData.setOutstandingAmount("-00000000032501634.31");
        entityData.setCountry("SG");
        entityData.setDateOfIngestion(stringToDate(DDMMYYYY,"20170112").getTime());
        entityDataList.add(entityData);
        return entityDataList;
    }

    public static Pageable createPageRequest(Integer page, Integer size) {
        return new PageRequest(page, size);
    }

    public static String getData() throws Exception{
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> responseJsonObject = new HashMap<>();
        List<EntityData> list = getEntityDataPage(0, 50).getContent();
        responseJsonObject.put("first", true);
        responseJsonObject.put("last", true);
        responseJsonObject.put("totalPages", 1);
        responseJsonObject.put("totalElements", list.size());
        responseJsonObject.put("pageNumber", 0);
        responseJsonObject.put("batchDate", "2017-01-18 19:20:08");
        responseJsonObject.put("sort", null);
        responseJsonObject.put("size", 50);
        responseJsonObject.put("content", list);
        responseJsonObject.put("numberOfElements", list.size());
        try {
            return mapper.writeValueAsString(responseJsonObject);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }
}
