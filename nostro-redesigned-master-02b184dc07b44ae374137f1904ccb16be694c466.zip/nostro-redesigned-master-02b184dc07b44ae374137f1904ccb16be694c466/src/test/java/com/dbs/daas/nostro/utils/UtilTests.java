package com.dbs.daas.nostro.utils;


import static com.dbs.daas.nostro.utils.CommonUtil.decrypt;
import static com.dbs.daas.nostro.utils.CommonUtil.encrypt;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.junit.Test;

import com.dbs.daas.nostro.exceptions.APIException;


public class UtilTests {

    @Test
    public void encryptTest() throws APIException {
        String plainText = "testing";
        String encryptedText = encrypt(plainText);
        assertNotNull(encryptedText);
        assertNotEquals(plainText, encryptedText);
    }

    @Test
    public void dencryptTest() throws APIException {
        String plainText = "testing";
        String encryptedText = encrypt(plainText);
        String dencryptedText = decrypt(encryptedText);
        assertNotNull(dencryptedText);
        assertEquals(plainText, dencryptedText);
    }

    @Test
    public void dateFormatterTest1() {
        String date = CommonUtil.dateFormatter(ApiConstants.YYYYMMDD);
        assertNotNull(date);
    }

    @Test
    public void dateFormatterTest2() {
        String date = CommonUtil.dateFormatter(ApiConstants.YYYYMMDD, new Date());
        assertNotNull(date);
    }

    @Test
    public void stringToDateTest() throws ParseException {
        Date date = CommonUtil.stringToDate(ApiConstants.YYYYMMDD, "20170101");
        assertNotNull(date);
    }

    @Test
    public void testChecksum() throws Exception {

        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("application.properties");
        SCPUtils scpUtils = new SCPUtils();
        String result = scpUtils.checksumLocalFile(inputStream);
        assertNotNull(result);
    }
}