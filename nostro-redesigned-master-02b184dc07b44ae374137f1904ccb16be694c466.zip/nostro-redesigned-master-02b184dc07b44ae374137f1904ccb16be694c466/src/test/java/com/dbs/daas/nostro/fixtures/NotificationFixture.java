package com.dbs.daas.nostro.fixtures;


import com.dbs.daas.nostro.model.Notification;


public class NotificationFixture {
    public static Notification getNotification() throws Exception{
    	Notification notification = new Notification();
        notification.setChecksum("XXXXX");
        notification.setAppName("TEST_APP");
        notification.setBatchId("123");
        notification.setDatetime(System.currentTimeMillis());
        notification.setStatus("SUCCESS");
        return notification;
    }
}
