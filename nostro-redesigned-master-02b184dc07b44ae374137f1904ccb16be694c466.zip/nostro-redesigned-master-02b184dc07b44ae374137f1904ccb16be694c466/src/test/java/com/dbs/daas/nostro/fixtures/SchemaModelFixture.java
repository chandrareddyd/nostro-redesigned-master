package com.dbs.daas.nostro.fixtures;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dbs.daas.nostro.model.SchemaModel;

public class SchemaModelFixture {
    public static SchemaModel getSchemaModel() {

        SchemaModel model = new SchemaModel();

        model.setAppName("TEST-APP");
        model.setModel(new ArrayList<String>(Arrays.asList("fileName", "valueDate", "accountNumber", "outstandingAmount", "country")));
        model.setTopicName("TEST-APP-MQ");
        model.setMqHost("10.92.206.40");
        model.setMqPort(5672);
        model.setMqUsername("2b0e93de-298f-4779-a0d8-3a8e62825946");
        model.setMqPassword("aHN1ZWk1dGh0aXB1azBpZWpubnU2ODVsNTA="); // encoded. Original - hsuei5thtipuk0iejnnu685l50
        model.setMqVirtualHost("f711d2a5-4958-43ab-9dfb-8fef3f5379ed");

        return model;
    }
    
    public static SchemaModel getSchemaModel2() {

        SchemaModel model = new SchemaModel();

        model.setAppName("TEST-APP");
        model.setModel(new ArrayList<String>(Arrays.asList("fileName", "valueDate", "accountNumber", "outstandingAmount", "country")));
        model.setTopicName("TEST-APP-MQ");
        model.setMqHost("10.92.206.40");
        model.setMqPort(5672);
        model.setMqUsername("bb522508-908c-4286-ba50-bab95e696fed");
        model.setMqPassword("ZmpyMzU4ZWVqMDZtNGRlMTc3ZTM2amI1MGs="); // encoded. Original - fjr358eej06m4de177e36jb50k
        model.setMqVirtualHost("48cb478a-81ed-4765-b003-1daa8e913afb");

        return model;
    }


    public static List<SchemaModel> getSchemaModels() {
        List<SchemaModel> models = new ArrayList<>();

        SchemaModel model = new SchemaModel();

        model.setAppName("TEST-APP");
        model.setModel(new ArrayList<String>(Arrays.asList("fileName", "valueDate", "accountNumber", "outstandingAmount", "country")));
        model.setTopicName("TEST-APP-MQ");
        model.setMqHost("10.92.206.40");
        model.setMqPort(5672);
        model.setMqUsername("2b0e93de-298f-4779-a0d8-3a8e62825946");
        model.setMqPassword("hsuei5thtipuk0iejnnu685l50");
        model.setMqVirtualHost("f711d2a5-4958-43ab-9dfb-8fef3f5379ed");
        models.add(model);

        model = new SchemaModel();

        model.setAppName("DEV-APP");
        model.setModel(new ArrayList<String>(Arrays.asList("fileName", "valueDate", "accountNumber", "outstandingAmount", "country")));
        model.setTopicName("DEV-APP-MQ");
        model.setMqHost("10.92.206.40");
        model.setMqPort(5672);
        model.setMqUsername("2b0e93de-298f-4779-a0d8-3a8e62825946");
        model.setMqPassword("hsuei5thtipuk0iejnnu685l50");
        model.setMqVirtualHost("f711d2a5-4958-43ab-9dfb-8fef3f5379ed");
        models.add(model);

        return models;
    }
}
