package com.dbs.daas.nostro.model;

import org.apache.geode.pdx.PdxReader;
import org.apache.geode.pdx.PdxSerializable;
import org.apache.geode.pdx.PdxWriter;
import org.springframework.data.annotation.Id;
import org.springframework.data.gemfire.mapping.Region;

/**
 * Created by carlos on 1/25/17.
 */
@Region("BatchFiles")
public class BatchFile implements PdxSerializable {

    @Id
    private String checksum;

    private String fileSource;

    private Long datetime;

    private String status;

    private String batchId;

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getChecksum() {
        return checksum;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public String getFileSource() {
        return fileSource;
    }

    public void setFileSource(String fileSource) {
        this.fileSource = fileSource;
    }

    public Long getDatetime() {
        return datetime;
    }

    public void setDatetime(Long datetime) {
        this.datetime = datetime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BatchFile batchFile = (BatchFile) o;

        if (checksum != null ? !checksum.equals(batchFile.checksum) : batchFile.checksum != null) return false;
        if (fileSource != null ? !fileSource.equals(batchFile.fileSource) : batchFile.fileSource != null) return false;
        if (datetime != null ? !datetime.equals(batchFile.datetime) : batchFile.datetime != null) return false;
        if (status != null ? !status.equals(batchFile.status) : batchFile.status != null) return false;
        return batchId != null ? batchId.equals(batchFile.batchId) : batchFile.batchId == null;
    }

    @Override
    public int hashCode() {
        int result = checksum != null ? checksum.hashCode() : 0;
        result = 31 * result + (fileSource != null ? fileSource.hashCode() : 0);
        result = 31 * result + (datetime != null ? datetime.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (batchId != null ? batchId.hashCode() : 0);
        return result;
    }

    @Override
    public void toData(PdxWriter pdxWriter) {
        pdxWriter.writeString("checksum",this.checksum);
        pdxWriter.writeLong("datetime",this.datetime);
        pdxWriter.writeString("fileSource",this.fileSource);
        pdxWriter.writeString("status",this.status);
        pdxWriter.writeString("batchId",this.batchId);
    }

    @Override
    public void fromData(PdxReader pdxReader) {
        this.checksum = pdxReader.readString("checksum");
        this.datetime = pdxReader.readLong("datetime");
        this.fileSource = pdxReader.readString("fileSource");
        this.status = pdxReader.readString("status");
        this.batchId = pdxReader.readString("batchId");
    }
}
