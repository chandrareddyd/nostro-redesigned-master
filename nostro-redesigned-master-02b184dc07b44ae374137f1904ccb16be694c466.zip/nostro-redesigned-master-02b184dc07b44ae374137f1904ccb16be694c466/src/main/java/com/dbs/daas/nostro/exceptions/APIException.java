package com.dbs.daas.nostro.exceptions;

public class APIException extends Exception {
    private static final long serialVersionUID = 1L;

    private Integer statusCode;

    public APIException(String message) {
        super(message);
    }

    public APIException(Integer statusCode, String message) {
        super(message);
        this.statusCode = statusCode;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }
}
