package com.dbs.daas.nostro.controllers;


import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.daas.nostro.exceptions.APIException;
import com.dbs.daas.nostro.model.SchemaModel;
import com.dbs.daas.nostro.model.SchemaModelDTO;
import com.dbs.daas.nostro.services.EntityDataService;
import com.dbs.daas.nostro.services.SchemaModelService;
import com.fasterxml.jackson.core.JsonProcessingException;

import static com.dbs.daas.nostro.utils.ApiConstants.DDMMYYYY;
import static com.dbs.daas.nostro.utils.CommonUtil.dateFormatter;
import static com.dbs.daas.nostro.utils.CommonUtil.stringToDate;


@RequestMapping(value = "/nostro/v1")
@RestController
public class APIController implements SwaggerApi {
    private static final Logger LOGGER = LoggerFactory.getLogger(APIController.class);

    private SchemaModelService schemaModelService;
    private EntityDataService entityDataService;

    @Autowired
    public APIController(SchemaModelService schemaModelService, EntityDataService entityDataService) {
        this.schemaModelService = schemaModelService;
        this.entityDataService = entityDataService;
    }

    @Override
    public ResponseEntity<String> getData(
            @PathVariable("appName") String appName,
            @RequestParam(value = "timestamp", required = false) String timestamp,
            @RequestParam(value = "replay", required = false, defaultValue = "N") String replay,
            @RequestParam(value = "page", required = false, defaultValue = "-1") Integer page,
            @RequestParam(value = "size", required = false, defaultValue = "50") Integer size) throws APIException, JsonProcessingException {

        long timestampDate;

        boolean latest = false;

        if(null == timestamp || timestamp.isEmpty()) {
            timestamp = dateFormatter(DDMMYYYY, new Date());
            latest = true;
        }
        try {

            timestampDate = stringToDate(DDMMYYYY, timestamp).getTime();

        } catch (ParseException e) {
            LOGGER.error("Bad request. Invalid timestamp. Error - " + e.getMessage());
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }

        if (null == appName || appName.isEmpty()) {
            LOGGER.error("Bad request. Invalid appName");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }
        SchemaModel schemaModel = schemaModelService.get(appName);
        if (null == schemaModel) {
            throw new APIException(Integer.parseInt(HttpStatus.NOT_FOUND.toString()),
                    HttpStatus.NOT_FOUND.getReasonPhrase());
        } else {
            return new ResponseEntity<>(entityDataService.getData(schemaModel, timestampDate, replay, page, size, latest), HttpStatus.OK);
        }
    }

    @Override
    public ResponseEntity<SchemaModelDTO> registerModel(@RequestBody SchemaModelDTO dto) throws APIException {
        if (null == dto) {
            LOGGER.error("Bad request. Invalid schema model");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }
        if (null == dto.getAppName()) {
            LOGGER.error("Bad request. Invalid schema model");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }
        SchemaModelDTO savedModel = schemaModelService.save(dto);
        if (null == savedModel) {
            LOGGER.error("Failed to save schema model");
            throw new APIException(Integer.parseInt(HttpStatus.INTERNAL_SERVER_ERROR.toString()),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
        }
        return new ResponseEntity<>(savedModel, HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<Map> deleteModel(@PathVariable("appName") String appName) throws APIException {

        Map<String, String> responseMessage = new HashMap<>();
        responseMessage.put("status", "success");

        if (null == appName || appName.isEmpty()) {
            LOGGER.error("Bad request. Invalid appName");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }

        SchemaModel schemaModel = schemaModelService.get(appName);
        if (null == schemaModel) {
            LOGGER.error("Failed to find schema registration for app " + appName);
            throw new APIException(Integer.parseInt(HttpStatus.NOT_FOUND.toString()),
                    HttpStatus.NOT_FOUND.getReasonPhrase());
        } else {
            Boolean isDeleted = schemaModelService.delete(appName);
            if (null == isDeleted || !isDeleted) {
                throw new APIException(Integer.parseInt(HttpStatus.INTERNAL_SERVER_ERROR.toString()),
                        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
            }
        }
        return new ResponseEntity<>(responseMessage, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SchemaModel> getModel(@PathVariable(value = "modelName") String modelName) throws APIException {

        if (null == modelName || modelName.isEmpty()) {
            LOGGER.error("Bad request. Invalid modelName");
            throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()),
                    HttpStatus.BAD_REQUEST.getReasonPhrase());
        }

        SchemaModel schemaModel = schemaModelService.get(modelName);
        if (null == schemaModel) {
            throw new APIException(Integer.parseInt(HttpStatus.NOT_FOUND.toString()),
                    HttpStatus.NOT_FOUND.getReasonPhrase());
        } else {
            return new ResponseEntity<>(schemaModel, HttpStatus.OK);
        }

    }


}
