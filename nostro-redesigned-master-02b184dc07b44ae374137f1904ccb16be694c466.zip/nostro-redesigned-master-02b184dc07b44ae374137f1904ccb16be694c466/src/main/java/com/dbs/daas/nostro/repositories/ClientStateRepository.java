package com.dbs.daas.nostro.repositories;


import com.dbs.daas.nostro.model.ClientState;
import org.springframework.data.gemfire.repository.GemfireRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClientStateRepository extends GemfireRepository<ClientState, String> {

}
