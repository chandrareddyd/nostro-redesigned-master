package com.dbs.daas.nostro.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.apache.geode.pdx.PdxReader;
import org.apache.geode.pdx.PdxSerializable;
import org.apache.geode.pdx.PdxWriter;
import org.springframework.data.annotation.Id;
import org.springframework.data.gemfire.mapping.Region;


@Region("ClientState")
public class ClientState implements PdxSerializable {

    @Id
    private String appName;

    private Integer pageNo;

    @JsonSerialize(using = ToStringSerializer.class)
    private Long dateOfRequest; // yyyyMMdd

    @JsonSerialize(using = ToStringSerializer.class)
    private Long batchDate; // yyyy-MM-dd HH:mm:ss

    public ClientState() {
    }


    public ClientState(String appName, Integer pageNo, Long timestamp, Long batchDate) {
        this.appName = appName;
        this.pageNo = pageNo;
        this.dateOfRequest = timestamp;
        this.batchDate = batchDate;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Long getDateOfRequest() {
        return dateOfRequest;
    }

    public void setDateOfRequest(Long dateOfRequest) {
        this.dateOfRequest = dateOfRequest;
    }

    public Long getBatchDate() {
        return batchDate;
    }

    public void setBatchDate(Long batchDate) {
        this.batchDate = batchDate;
    }

    @Override
    public void toData(PdxWriter pdxWriter) {
        pdxWriter.writeString("appName",this.appName);
        pdxWriter.writeInt("pageNo", this.pageNo);
        pdxWriter.writeLong("dateOfRequest", this.dateOfRequest);
        pdxWriter.writeLong("batchDate", this.batchDate);
    }

    @Override
    public void fromData(PdxReader pdxReader) {
        this.appName = pdxReader.readString("appName");
        this.pageNo = pdxReader.readInt("pageNo");
        this.dateOfRequest = pdxReader.readLong("dateOfRequest");
        this.batchDate = pdxReader.readLong("batchDate");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ClientState that = (ClientState) o;

        if (appName != null ? !appName.equals(that.appName) : that.appName != null) return false;
        if (pageNo != null ? !pageNo.equals(that.pageNo) : that.pageNo != null) return false;
        if (dateOfRequest != null ? !dateOfRequest.equals(that.dateOfRequest) : that.dateOfRequest != null) return false;
        return batchDate != null ? batchDate.equals(that.batchDate) : that.batchDate == null;
    }

    @Override
    public int hashCode() {
        int result = appName != null ? appName.hashCode() : 0;
        result = 31 * result + (pageNo != null ? pageNo.hashCode() : 0);
        result = 31 * result + (dateOfRequest != null ? dateOfRequest.hashCode() : 0);
        result = 31 * result + (batchDate != null ? batchDate.hashCode() : 0);
        return result;
    }
}
