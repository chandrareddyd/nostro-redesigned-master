package com.dbs.daas.nostro.utils;


import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;
import java.util.Date;

import static com.dbs.daas.nostro.utils.ApiConstants.DDMMYYYY;
import static com.dbs.daas.nostro.utils.CommonUtil.dateFormatter;

/**
 * Created by carlos on 2/13/17.
 */
public class LongToDateStringSerializer extends JsonSerializer<Long> {

    @Override
    public void serialize(Long aLong, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException, JsonProcessingException {
        jsonGenerator.writeString(dateFormatter(DDMMYYYY,new Date(aLong)));
    }
}
