package com.dbs.daas.nostro.repositories;


import com.dbs.daas.nostro.model.SchemaModel;
import org.springframework.data.gemfire.repository.GemfireRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SchemaModelRepository extends GemfireRepository<SchemaModel, String> {


}
