package com.dbs.daas.nostro.model;

import com.dbs.daas.nostro.utils.LongToDateStringSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.apache.geode.pdx.PdxReader;
import org.apache.geode.pdx.PdxSerializable;
import org.apache.geode.pdx.PdxWriter;
import org.springframework.data.annotation.Id;
import org.springframework.data.gemfire.mapping.Region;

import java.util.Date;


@Region("EntityData")
public class EntityData implements PdxSerializable {

    @Id
    private String id;

    private String fileName;

    private String fileType;

    @JsonSerialize(using = LongToDateStringSerializer.class)
    private Long positionDate; // ddMMyyyy

    private String fileSource;

    private String valueDate;

    private String accountNumber;

    private String currency;

    private String outstandingAmount;

    private String country;

    @JsonSerialize(using = ToStringSerializer.class)
    private Long dateOfIngestion; //yyyyMMdd

    private String fileChecksum;

    public String getFileChecksum() {
        return fileChecksum;
    }

    public void setFileChecksum(String fileChecksum) {
        this.fileChecksum = fileChecksum;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public Long getPositionDate() {
        return positionDate;
    }

    public void setPositionDate(Long positionDate) {
        this.positionDate = positionDate;
    }

    public String getFileSource() {
        return fileSource;
    }

    public void setFileSource(String fileSource) {
        this.fileSource = fileSource;
    }

    public String getValueDate() {
        return valueDate;
    }

    public void setValueDate(String valueDate) {
        this.valueDate = valueDate;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getOutstandingAmount() {
        return outstandingAmount;
    }

    public void setOutstandingAmount(String outstandingAmount) {
        this.outstandingAmount = outstandingAmount;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Long getDateOfIngestion() {
        return dateOfIngestion;
    }

    public void setDateOfIngestion(Long dateOfIngestion) {
        this.dateOfIngestion = dateOfIngestion;
    }

    @Override
    public void toData(PdxWriter pdxWriter) {
        pdxWriter.writeString("id",this.id);
        pdxWriter.writeString("accountNumber",this.accountNumber);
        pdxWriter.writeString("country",this.country);
        pdxWriter.writeString("currency",this.currency);
        pdxWriter.writeString("fileName",this.fileName);
        pdxWriter.writeString("fileSource",this.fileSource);
        pdxWriter.writeString("fileType",this.fileType);
        pdxWriter.writeString("fileChecksum",this.fileChecksum);
        pdxWriter.writeLong("dateOfIngestion",this.dateOfIngestion);
        pdxWriter.writeLong("positionDate",this.positionDate);
        pdxWriter.writeString("valueDate",this.valueDate);
        pdxWriter.writeString("outstandingAmount",this.outstandingAmount);
    }

    @Override
    public void fromData(PdxReader pdxReader) {
        this.id = pdxReader.readString("id");
        this.accountNumber = pdxReader.readString("accountNumber");
        this.country = pdxReader.readString("country");
        this.currency = pdxReader.readString("currency");
        this.fileName = pdxReader.readString("fileName");
        this.fileSource = pdxReader.readString("fileSource");
        this.fileType = pdxReader.readString("fileType");
        this.fileChecksum = pdxReader.readString("fileChecksum");
        this.dateOfIngestion = pdxReader.readLong("dateOfIngestion");
        this.positionDate = pdxReader.readLong("positionDate");
        this.valueDate = pdxReader.readString("valueDate");
        this.outstandingAmount = pdxReader.readString("outstandingAmount");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EntityData that = (EntityData) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (fileName != null ? !fileName.equals(that.fileName) : that.fileName != null) return false;
        if (fileType != null ? !fileType.equals(that.fileType) : that.fileType != null) return false;
        if (positionDate != null ? !positionDate.equals(that.positionDate) : that.positionDate != null) return false;
        if (fileSource != null ? !fileSource.equals(that.fileSource) : that.fileSource != null) return false;
        if (valueDate != null ? !valueDate.equals(that.valueDate) : that.valueDate != null) return false;
        if (accountNumber != null ? !accountNumber.equals(that.accountNumber) : that.accountNumber != null)
            return false;
        if (currency != null ? !currency.equals(that.currency) : that.currency != null) return false;
        if (outstandingAmount != null ? !outstandingAmount.equals(that.outstandingAmount) : that.outstandingAmount != null)
            return false;
        if (country != null ? !country.equals(that.country) : that.country != null) return false;
        if (dateOfIngestion != null ? !dateOfIngestion.equals(that.dateOfIngestion) : that.dateOfIngestion != null) return false;
        return fileChecksum != null ? fileChecksum.equals(that.fileChecksum) : that.fileChecksum == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (fileName != null ? fileName.hashCode() : 0);
        result = 31 * result + (fileType != null ? fileType.hashCode() : 0);
        result = 31 * result + (positionDate != null ? positionDate.hashCode() : 0);
        result = 31 * result + (fileSource != null ? fileSource.hashCode() : 0);
        result = 31 * result + (valueDate != null ? valueDate.hashCode() : 0);
        result = 31 * result + (accountNumber != null ? accountNumber.hashCode() : 0);
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (outstandingAmount != null ? outstandingAmount.hashCode() : 0);
        result = 31 * result + (country != null ? country.hashCode() : 0);
        result = 31 * result + (dateOfIngestion != null ? dateOfIngestion.hashCode() : 0);
        result = 31 * result + (fileChecksum != null ? fileChecksum.hashCode() : 0);
        return result;
    }


}
