package com.dbs.daas.nostro.batch;

import static com.dbs.daas.nostro.utils.ApiConstants.BATCH_FILE_STATUS_DOESNOT_EXIST;
import static com.dbs.daas.nostro.utils.ApiConstants.BATCH_FILE_STATUS_INPROGRESS;
import static com.dbs.daas.nostro.utils.ApiConstants.BATCH_FILE_STATUS_MISMATCH;
import static com.dbs.daas.nostro.utils.ApiConstants.BATCH_FILE_STATUS_PROCESSED;
import static com.dbs.daas.nostro.utils.ApiConstants.HK_TMP_FILE_NAME;
import static com.dbs.daas.nostro.utils.ApiConstants.SG_TMP_FILE_NAME;
import static com.dbs.daas.nostro.utils.MessageHandler.publishMessage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dbs.daas.nostro.config.SCPSourceOptionsMetadata;
import com.dbs.daas.nostro.model.BatchFile;
import com.dbs.daas.nostro.model.Notification;
import com.dbs.daas.nostro.model.SchemaModel;
import com.dbs.daas.nostro.services.EntityDataService;
import com.dbs.daas.nostro.services.NotificationService;
import com.dbs.daas.nostro.services.SchemaModelService;
import com.dbs.daas.nostro.utils.ApiConstants;
import com.dbs.daas.nostro.utils.SCPUtils;
import com.jcraft.jsch.Session;

@Component
public class SCPBatch implements JobExecutionListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(SCPBatch.class);

    private SCPSourceOptionsMetadata options;

    private SCPUtils scpUtils;

    private EntityDataService entityDataService;

    private SchemaModelService schemaModelService;

    private NotificationService notificationService;


    @Autowired
    public SCPBatch(SCPSourceOptionsMetadata options, SCPUtils scpUtil, EntityDataService entityDataService,
                    SchemaModelService schemaModelService, NotificationService notificationService) {
        this.options = options;
        this.scpUtils = scpUtil;
        this.entityDataService = entityDataService;
        this.schemaModelService = schemaModelService;
        this.notificationService = notificationService;
    }

    public void copyRemoteFilesAndProcessThem(String jobId) throws IOException {
        Session session = null;
        int rowsProcessed0 = 0;
        int rowsProcessed1 = 0;
        
        File file0 = null;        
        File file1 = null;
        
        String file0Checksum = null;
        String file1Checksum = null;
        
        boolean file0IsOKForProcessing = false;
        boolean file1IsOKForProcessing = false;
        
        String file0InprogressName = "/" + FilenameUtils.getPath(options.getFileNames().get(0)) + System.currentTimeMillis() + "_" + ApiConstants.INPROGRESS_SG_FILE_NAME;
        String file1InprogressName = "/" + FilenameUtils.getPath(options.getFileNames().get(1)) + System.currentTimeMillis() + "_" + ApiConstants.INPROGRESS_HK_FILE_NAME;
        
        try {
        	
        	Random random = new Random();
        	Integer min = 10000;
        	Integer max = 30000;
        	Long radomeSleepTime = (long) (random.nextInt(max-min) + min);
        	
        	LOGGER.info("Sleeping current thread for " + radomeSleepTime + " milliseconds");
        	Thread.sleep(radomeSleepTime);

            session = scpUtils.authenticateScpServer(options);
            
            if(scpUtils.validateRemoteFileAttributes(session, options.getFileNames().get(0)) && 
            		scpUtils.validateRemoteFileAttributes(session, options.getFileNames().get(1))) {
            	
            	file0Checksum = scpUtils.shasumRemoteFile(options, session, 0, options.getFileNames().get(0));                       
            	file1Checksum = scpUtils.shasumRemoteFile(options, session, 1, options.getFileNames().get(1)); 
            	
                file0IsOKForProcessing = entityDataService.checkFileForProcessing(options.getFileNames().get(0), file0Checksum); 
                file1IsOKForProcessing = entityDataService.checkFileForProcessing(options.getFileNames().get(1), file1Checksum); 
                
                if(file0IsOKForProcessing && file1IsOKForProcessing) {
                    
                	updateFileStatus(BATCH_FILE_STATUS_INPROGRESS, jobId, file0Checksum, file1Checksum, options.getFileNames().get(0), options.getFileNames().get(1));   
                	
                	LOGGER.info("Renaming " + options.getFileNames().get(0) + " to " + file0InprogressName);
            		scpUtils.renameRemoteFile(session, options.getFileNames().get(0), file0InprogressName);
            		LOGGER.info("Renaming " + options.getFileNames().get(1) + " to " + file1InprogressName);
            		scpUtils.renameRemoteFile(session, options.getFileNames().get(1), file1InprogressName);   
                    
                	file0 = scpUtils.getRemoteFile(file0InprogressName, session, 0, SG_TMP_FILE_NAME);   
                    file1 = scpUtils.getRemoteFile(file1InprogressName, session, 1, HK_TMP_FILE_NAME);    
                }
            }                    
        	
            if (null != file0 && file0.exists() && null != file1 && file1.exists()) {                   
                
                if(file0IsOKForProcessing && file1IsOKForProcessing) {               	 
                	
    	            try {
    	                rowsProcessed0 = processFile(jobId, file0, 0, session, file0Checksum);
    	            
    	                rowsProcessed1 = processFile(jobId, file1, 1, session, file1Checksum);
    	                
    	            } catch (IOException e) {
    	                LOGGER.error("error copying file", e);
    	            }  

                    int totalCount = rowsProcessed0 + rowsProcessed1;

                    if (totalCount > 0) {
                    	if(entityDataService.getBatchFile(file0Checksum).getStatus().equalsIgnoreCase(BATCH_FILE_STATUS_PROCESSED) && entityDataService.getBatchFile(file1Checksum).getStatus().equalsIgnoreCase(BATCH_FILE_STATUS_PROCESSED)) {
                    		notifyUsers(jobId, file0Checksum + "##" + file1Checksum);
                    	}
                    }
                }            	
            }

        } catch (Exception e) {

            LOGGER.error("error authenticating to server", e);

        } finally {
        	  
        	if(file0IsOKForProcessing && scpUtils.validateRemoteFileAttributes(session, file0InprogressName)) {
        		LOGGER.info("Renaming " + file0InprogressName + " to " + options.getFileNames().get(0));
        		scpUtils.renameRemoteFile(session, file0InprogressName, options.getFileNames().get(0));
        	}
        	
        	if(file1IsOKForProcessing && scpUtils.validateRemoteFileAttributes(session, file1InprogressName)) {
        		LOGGER.info("Renaming " + file1InprogressName + " to " + options.getFileNames().get(1));
        		scpUtils.renameRemoteFile(session, file1InprogressName, options.getFileNames().get(1));    
        	}

            if (null != session) {
                try {
                    session.disconnect();
                } catch (Exception e) {
                    LOGGER.warn("Error occurred while disconnecting ssh session", e);
                }
            }
            
            if (null != file0 && file0.delete()) {
                LOGGER.debug("Temporary file0 deleted successfully");
            }
            
            if (null != file1 && file1.delete()) {
                LOGGER.debug("Temporary file1 deleted successfully");
            }

        }

    }

    public int processFile(String jobId, File file, int fileIndex, Session session, String fileChecksum) throws IOException {
        InputStream inputStream = null;
        int count = 0;
        try {
            if (null == file || !file.exists()) {
                updateFileStatus(BATCH_FILE_STATUS_DOESNOT_EXIST, jobId, fileChecksum, options.getFileNames().get(fileIndex));
                throw new IOException("File doesn't exist on remote server: " + options.getFileNames().get(fileIndex));
            }
            inputStream = new FileInputStream(file);
            String localFileChecksum = scpUtils.checksumLocalFile(new FileInputStream(file));
            if (localFileChecksum.equalsIgnoreCase(fileChecksum)) { //remote file matches local file.
//                    boolean isOutStdindAmtValid = scpUtils.checkOutstandingAmountSum(options, fileIndex, new FileInputStream(file)); // checking amount in file 0
                boolean isOutStdindAmtValid = true; //temporary removal.
                if (!isOutStdindAmtValid) {
                    LOGGER.error("Total outstanding amount does not match with the footer value for " + options.getFileNames().get(fileIndex));
                } else {
                    count = entityDataService.processFile(inputStream, fileChecksum, fileIndex);
                    updateFileStatus(BATCH_FILE_STATUS_PROCESSED, jobId, fileChecksum, options.getFileNames().get(fileIndex));
                }
            } else {
                updateFileStatus(BATCH_FILE_STATUS_MISMATCH, jobId, fileChecksum, options.getFileNames().get(fileIndex));
            }            
        } finally {
            if (null != inputStream) {
                inputStream.close();
            }
        }
        return count;
    }

    public void updateFileStatus(String status, String jobId, String fileChecksum, String fileName) {
        BatchFile batchFile = new BatchFile();
        batchFile.setChecksum(fileChecksum);
        batchFile.setFileSource(fileName);
        batchFile.setDatetime(System.currentTimeMillis());
        batchFile.setStatus(status);
        batchFile.setBatchId(jobId);
        entityDataService.createOrUpdateStatus(batchFile);
    }

    public void updateFileStatus(String status, String jobId, String file0Checksum, String file1Checksum, String file0Name, String file1Name) {
    	BatchFile batchfile0 = entityDataService.getBatchFile(file0Checksum);
    	if(null == batchfile0) {
    		batchfile0 = new BatchFile();
    	}
    	batchfile0.setChecksum(file0Checksum);
    	batchfile0.setFileSource(file0Name);
    	batchfile0.setDatetime(System.currentTimeMillis());
    	batchfile0.setStatus(status);
    	batchfile0.setBatchId(jobId);
        entityDataService.createOrUpdateStatus(batchfile0);
        
        BatchFile batchfile1 = entityDataService.getBatchFile(file1Checksum);
    	if(null == batchfile1) {
    		batchfile1 = new BatchFile();
    	}
    	batchfile1.setChecksum(file1Checksum);
    	batchfile1.setFileSource(file1Name);
    	batchfile1.setDatetime(System.currentTimeMillis());
    	batchfile1.setStatus(status);
    	batchfile1.setBatchId(jobId);
        entityDataService.createOrUpdateStatus(batchfile1);
    }

    public void notifyUsers(String jobId, String checksum) {
        List<SchemaModel> models = schemaModelService.get();
        if (null != models && !models.isEmpty()) {
            for (SchemaModel model : models) {
                if (null != model.getTopicName() && !model.getTopicName().isEmpty() && null != model.getMqHost()
                        && !model.getMqHost().isEmpty() && 0 != model.getMqPort()
                        && null != model.getMqUsername() && !model.getMqUsername().isEmpty()
                        && null != model.getMqPassword() && !model.getMqPassword().isEmpty()
                        && null != model.getMqVirtualHost() && !model.getMqVirtualHost().isEmpty()) {
                    try {
                    	if(null == notificationService.get(checksum)) {
                    		LOGGER.info("Publishing notification message for " + model.getAppName() + " and checksum " + checksum + " in queue - " + model.getTopicName());
                            publishMessage(model);
                            updateNotificationStatus(checksum, model.getAppName(), "SUCCESS", jobId, System.currentTimeMillis());
                    	} else {
                    		LOGGER.info("Notification message is already published for " + model.getAppName()+ " and checksum " + checksum + " in queue - " + model.getTopicName());                            
                    	}
                    } catch (Exception e) {
                        LOGGER.error("Failed to publish message for " + model.getAppName(), e);
                    }
                }
            }
        }
    }

    private void updateNotificationStatus(String checksum, String appName, String status, String batchId, Long datetime) {
        Notification notification = new Notification();
        notification.setChecksum(checksum);
        notification.setAppName(appName);
        notification.setBatchId(batchId);
        notification.setDatetime(datetime);
        notification.setStatus(status);
        notificationService.save(notification);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        String jobId = jobExecution.getExecutionContext().getString("JOBID");
        String date = new Date().toString();
        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
            LOGGER.info(String.format("SCP Source job: %s completed at %s", jobId, date));
        } else if (jobExecution.getStatus() == BatchStatus.FAILED) {
            LOGGER.info(String.format("SCP Source job: %s failed at %s", jobId, date));
        }
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        String jobId = UUID.randomUUID().toString();
        String date = new Date().toString();
        LOGGER.info(String.format("SCP Source job: %s started at %s", jobId, date));
        jobExecution.getExecutionContext().putString("JOBID", jobId);


    }

}
