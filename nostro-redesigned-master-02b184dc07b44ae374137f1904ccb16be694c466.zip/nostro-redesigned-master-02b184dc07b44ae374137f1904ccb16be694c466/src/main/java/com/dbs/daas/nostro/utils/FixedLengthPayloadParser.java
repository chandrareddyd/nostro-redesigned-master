package com.dbs.daas.nostro.utils;


import com.dbs.daas.nostro.config.SCPSourceOptionsMetadata;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

public class FixedLengthPayloadParser {

    public Map<String, Object> parseHeader(String header, SCPSourceOptionsMetadata options, Integer fileIndex) {

        return parse(header, options.getHeaderColumnNames().get(fileIndex),
                options.getHeaderColumnRanges().get(fileIndex));
    }

    public Map<String, Object> parsePayload(String payload, SCPSourceOptionsMetadata options, Integer fileIndex) {

        return parse(payload, options.getColumnNames().get(fileIndex), options.getColumnRanges().get(fileIndex));
    }

    public Map<String, Object> parseFooter(String footer, SCPSourceOptionsMetadata options, Integer fileIndex) {

        return parse(footer, new String[]{ApiConstants.FOOTER_COUNT, ApiConstants.OUTSTANDING_AMOUNT},
                options.getFooterCountColumnRange().get(fileIndex));
    }

    private Map<String, Object> parse(String payload, String[] columnNames, String[] columnRanges) {

        Map<String, Object> result = new HashMap<>();

        FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
        tokenizer.setNames(columnNames);
        tokenizer.setColumns(convertToRange(columnRanges));
        tokenizer.setStrict(false);

        FieldSet fieldSet = tokenizer.tokenize(payload);

        if (fieldSet.getNames() != null) {
            for (int i = 0; i < fieldSet.getNames().length; i++) {
                if (fieldSet.getValues()[i] != null) {
                    result.put(fieldSet.getNames()[i], fieldSet.getValues()[i].trim());
                } else {
                    result.put(fieldSet.getNames()[i], null);
                }
            }
        }

        return result;
    }

    private Range[] convertToRange(String[] strRanges) {

        //split text into ranges
        Range[] ranges = new Range[strRanges.length];

        //parse ranges and create array of Range objects
        for (int i = 0; i < strRanges.length; i++) {
            String[] range = strRanges[i].split("-");

            int min;
            int max;

            if ((range.length == 1) && (StringUtils.hasText(range[0]))) {
                min = Integer.parseInt(range[0].trim());
                // correct max value will be assigned later
                ranges[i] = new Range(min);
            } else if ((range.length == 2) && (StringUtils.hasText(range[0]))
                    && (StringUtils.hasText(range[1]))) {
                min = Integer.parseInt(range[0].trim());
                max = Integer.parseInt(range[1].trim());
                ranges[i] = new Range(min, max);
            } else {
                throw new IllegalArgumentException("Range[" + i + "]: range (" + strRanges[i] + ") is invalid");
            }
        }

        return ranges;
    }


}
