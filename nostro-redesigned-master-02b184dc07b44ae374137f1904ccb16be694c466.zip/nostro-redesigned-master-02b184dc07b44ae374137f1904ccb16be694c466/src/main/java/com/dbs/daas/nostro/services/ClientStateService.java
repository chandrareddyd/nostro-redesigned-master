package com.dbs.daas.nostro.services;

import com.dbs.daas.nostro.model.ClientState;
import com.dbs.daas.nostro.repositories.ClientStateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientStateService {
    private ClientStateRepository clientStateRepository;

    @Autowired
    public ClientStateService(ClientStateRepository clientStateRepository) {
        this.clientStateRepository = clientStateRepository;
    }

    public ClientState get(String appName) {
        return clientStateRepository.findOne(appName);
    }

    public boolean save(ClientState state) {
        return clientStateRepository.save(state) != null;
    }

    public boolean delete(String appName) {
        clientStateRepository.delete(appName);
        return true;
    }
}
