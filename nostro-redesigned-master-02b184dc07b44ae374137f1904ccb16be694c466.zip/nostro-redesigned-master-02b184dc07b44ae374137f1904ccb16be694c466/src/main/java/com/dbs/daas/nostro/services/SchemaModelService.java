package com.dbs.daas.nostro.services;

import static com.dbs.daas.nostro.utils.CommonUtil.encrypt;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.IteratorUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dbs.daas.nostro.exceptions.APIException;
import com.dbs.daas.nostro.utils.ApiConstants;
import com.dbs.daas.nostro.model.ClientState;
import com.dbs.daas.nostro.model.SchemaModel;
import com.dbs.daas.nostro.model.SchemaModelDTO;
import com.dbs.daas.nostro.repositories.SchemaModelRepository;


@Service
public class SchemaModelService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SchemaModelService.class);

    private SchemaModelRepository schemaModelRepository;

	private ClientStateService clientStateService;

    @Autowired
    public SchemaModelService(SchemaModelRepository schemaModelRepository, ClientStateService clientStateService) {
        this.schemaModelRepository = schemaModelRepository;
        this.clientStateService = clientStateService;

    }

    public List<SchemaModel> get() {
        return IteratorUtils.toList(schemaModelRepository.findAll().iterator());
    }

    public SchemaModel get(String identifier) {
        return schemaModelRepository.findOne(identifier);
    }

    public Boolean delete(String appName) {
		ClientState currentState = clientStateService.get(appName);
		if(null != currentState) {
			clientStateService.delete(appName);
		}
        schemaModelRepository.delete(appName);
        return true;
    }

    public SchemaModelDTO save(SchemaModelDTO dto) throws APIException {
        SchemaModel model = new SchemaModel();
        model.setAppName(dto.getAppName());
        if (null != dto.getTopicName() && !dto.getTopicName().isEmpty() && null != dto.getUriConn() && !dto.getUriConn().isEmpty()) {
            try {
                model = getSchemaWithMQDetails(model, dto.getUriConn());
            } catch (Exception e) {
                LOGGER.error("Bad request. Invalid MQ URI Connection details. Error - " + e);
                throw new APIException(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()), HttpStatus.BAD_REQUEST.getReasonPhrase());
            }
            model.setTopicName(dto.getTopicName());
        }
        model.setModel(dto.getModel());
        if (null == model.getModel() || (null != model.getModel() && model.getModel().isEmpty())) {
            List<String> defaultModelList = new ArrayList<>();
            defaultModelList.addAll(ApiConstants.ENTITY_DATA_MODEL_FIELDS);
            model.setModel(defaultModelList);
        }

        if (schemaModelRepository.save(model) != null) {
            dto.setModel(model.getModel());
            return dto;
        } else {
            LOGGER.error("Error while saving schema model");
            return null;
        }
    }

    private SchemaModel getSchemaWithMQDetails(SchemaModel model, String uri) throws APIException {
        try {
            /* amqp://USERNAME:PASSWORD@HOST/VIRTUAL_HOST */
            String modifiedUri = uri.replaceAll("amqp://", "");
	    	/* USERNAME:PASSWORD@HOST/VIRTUAL_HOST */
            modifiedUri = modifiedUri.replaceAll(":", ",");
	    	/* USERNAME,PASSWORD@HOST/VIRTUAL_HOST */
            modifiedUri = modifiedUri.replaceAll("@", ",");
	    	/* USERNAME,PASSWORD,HOST/VIRTUAL_HOST */
            modifiedUri = modifiedUri.replaceAll("/", ",");
	    	/* USERNAME,PASSWORD,HOST,VIRTUAL_HOST */
            String[] uriConnArr = modifiedUri.split(",");

            model.setMqUsername(uriConnArr[0]);
            model.setMqPassword(uriConnArr[1]);
            if (null != model.getMqPassword()) {
                model.setMqPassword(encrypt(model.getMqPassword()));
            }
            model.setMqHost(uriConnArr[2]);
            model.setMqPort(5672);
            model.setMqVirtualHost(uriConnArr[3]);

            return model;
        } catch (Exception e) {
            LOGGER.error("Error while reading queue details from request. Error - ", e);
            throw new APIException(Integer.parseInt(HttpStatus.INTERNAL_SERVER_ERROR.toString()), e.getMessage());
        }
    }
}
