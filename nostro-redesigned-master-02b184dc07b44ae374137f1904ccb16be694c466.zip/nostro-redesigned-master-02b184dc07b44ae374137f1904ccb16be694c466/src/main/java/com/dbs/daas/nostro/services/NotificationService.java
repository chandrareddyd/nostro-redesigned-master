package com.dbs.daas.nostro.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.daas.nostro.model.Notification;
import com.dbs.daas.nostro.repositories.NotificationRepository;

@Service
public class NotificationService {
    private NotificationRepository notificationRepository;

    @Autowired
    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    public Notification get(String checksum) {
        return notificationRepository.findOne(checksum);
    }

    public boolean save(Notification notification) {
        return notificationRepository.save(notification) != null;
    }
}
