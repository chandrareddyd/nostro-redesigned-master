package com.dbs.daas.nostro.utils;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class ApiConstants {

	public static final String SERVICE_NAME = "nostro";
    public static final String HEADER = "header";
    public static final String PAYLOAD = "payload";
    public static final String FOOTER = "footer";
    public static final String FOOTER_COUNT = "FOOTER_COUNT";
    public static final String ERR_DOWNLOAD_FILE_CD = "CAP-100";
    public static final String ERR_PROCESSING_FILE_CD = "CAP-101";
    public static final String ERR_PROCESSING_LINE_CD = "CAP-102";
    public static final String ERR_VALIDATE_FOOTER_CD = "CAP-103";
    public static final String BATCH_JOB_STATUS_FLAG = "scp_source_job";
    public static final String BATCH_JOB_RUNNING = "running";
    public static final String BATCH_JOB_FINISHED = "finished";
    public static final String BATCH_JOB_NA = "na";
    public static final String BATCH_FILE_STATUS_PROCESSED = "PROCESSED";
    public static final String BATCH_FILE_STATUS_INPROGRESS = "INPROGRESS";
    public static final String BATCH_FILE_STATUS_MISMATCH = "FILE_MISMATCH";
    public static final String BATCH_FILE_STATUS_DOESNOT_EXIST = "FILE_DOESNOT_EXIST";
    public static final String DDMMYYYY = "ddMMyyyy";
    public static final String YYYYMMDD = "yyyyMMdd";
    public static final String YYYY_MM_DD_HHMMSS = "yyyy-MM-dd HH:mm:ss";
    public static final String COL_ID = "id";
    public static final String COL_ACCOUNT_NO = "accountNumber";
    public static final String COL_CURRENCY = "currency";
    public static final String COL_COUNTRY = "country";
    public static final String COL_FILE_NAME = "fileName";
    public static final String COL_FILE_TYPE = "fileType";
    public static final String COL_POSITION_DATE = "positionDate";
    public static final String COL_FILE_SOURCE = "fileSource";
    public static final String COL_TIMESTAMP = "dateOfIngestion";
    public static final String COL_FILECHECKSUM = "fileChecksum";
    public static final String OUTSTANDING_AMOUNT = "outstandingAmount";
    public static final String SG_TMP_FILE_NAME = "PSGL-SG-output.tmp";
    public static final String HK_TMP_FILE_NAME = "PSGL-HK-output.tmp";
    public static final String DEFAULT_SG_FILE_NAME = "SG_PSGL_TRAN.DAT";
    public static final String INPROGRESS_SG_FILE_NAME = "SG_INPROGRESS.DAT";
    public static final String DEFAULT_HK_FILE_NAME = "HK_PSGL_Nostro.txt";
    public static final String INPROGRESS_HK_FILE_NAME = "HK_INPROGRESS.txt";
    public static final String NOTIFICATION_MSG = "File data is ready to consume";
    public static final String ENCRYPTION_ALGORITHM_NAME = "AES";
    public static final String CIPHER_TRANSFORMATION = "AES/CBC/PKCS5PADDING";
    public static final String SECRET_KEY_1 = "ssdkF$HUy2A#D%kd";
    public static final String SECRET_KEY_2 = "DaaS-Nostro-Salt";
    public static final String[] ENTITY_DATA_MODEL_FIELDS_ARRAY = {"fileName", "fileType", "positionDate", "fileSource", "valueDate", "accountNumber", "currency", "outstandingAmount", "country"};
    public static final Set<String> ENTITY_DATA_MODEL_FIELDS = new TreeSet<>(Arrays.asList(ENTITY_DATA_MODEL_FIELDS_ARRAY));
    private ApiConstants() {
    }
}
