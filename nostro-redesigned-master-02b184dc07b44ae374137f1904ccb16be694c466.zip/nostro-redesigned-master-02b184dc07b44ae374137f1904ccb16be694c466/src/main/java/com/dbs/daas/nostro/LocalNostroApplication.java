package com.dbs.daas.nostro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalNostroApplication {
	

    public static void main(String[] args) {
        SpringApplication.run(LocalNostroApplication.class, args); //NOSONAR
    }
}
