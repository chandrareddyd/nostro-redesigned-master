package com.dbs.daas.nostro.repositories;

import com.dbs.daas.nostro.model.BatchFile;
import org.springframework.data.gemfire.repository.GemfireRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by carlos on 1/25/17.
 */
@Repository
public interface BatchFileRepository extends GemfireRepository<BatchFile, String> {

}
