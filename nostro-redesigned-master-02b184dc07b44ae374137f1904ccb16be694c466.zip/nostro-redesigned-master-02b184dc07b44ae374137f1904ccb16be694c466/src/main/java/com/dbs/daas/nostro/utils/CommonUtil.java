package com.dbs.daas.nostro.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dbs.daas.nostro.exceptions.APIException;


public class CommonUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtil.class);

    private CommonUtil() {
    }

    public static String encrypt(String strClearText) throws APIException {
        return Base64.getEncoder().encodeToString(strClearText.getBytes());
    }

    public static String decrypt(String strEncrypted) throws APIException {
        return new String(Base64.getDecoder().decode(strEncrypted));
    }

    public static String dateFormatter(String format) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.format(Calendar.getInstance().getTime());
    }

    public static String dateFormatter(String format, Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.format(date);
    }

    public static Date stringToDate(String format, String date) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.parse(date);
    }


}
