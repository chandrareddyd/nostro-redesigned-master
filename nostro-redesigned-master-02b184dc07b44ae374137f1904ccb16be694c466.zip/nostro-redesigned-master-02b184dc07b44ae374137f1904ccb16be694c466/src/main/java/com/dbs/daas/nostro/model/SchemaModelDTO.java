package com.dbs.daas.nostro.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class SchemaModelDTO {

    @JsonProperty("appName")
    /** client that register schema model*/
    private String appName;

    @JsonProperty("model")
    /** list of fields that represents the schema model */
    private List<String> model;

    @JsonProperty("topicName")
    /** Queue name */
    private String topicName;

    @JsonProperty("uriConn")
    /** URI connection details for Queue */
    private String uriConn;

    public SchemaModelDTO() {
    }

    public SchemaModelDTO(String appName, List<String> model, String topicName, String uriConn) {
        this.appName = appName;
        this.model = model;
        this.topicName = topicName;
        this.uriConn = uriConn;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public List<String> getModel() {
        return model;
    }

    public void setModel(List<String> model) {
        this.model = model;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public String getUriConn() {
        return uriConn;
    }

    public void setUriConn(String uriConn) {
        this.uriConn = uriConn;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((appName == null) ? 0 : appName.hashCode());
        result = prime * result + ((model == null) ? 0 : model.hashCode());
        result = prime * result + ((topicName == null) ? 0 : topicName.hashCode());
        result = prime * result + ((uriConn == null) ? 0 : uriConn.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SchemaModelDTO other = (SchemaModelDTO) obj;
        if (appName == null) {
            if (other.appName != null)
                return false;
        } else if (!appName.equals(other.appName))
            return false;
        if (model == null) {
            if (other.model != null)
                return false;
        } else if (!model.equals(other.model))
            return false;
        if (topicName == null) {
            if (other.topicName != null)
                return false;
        } else if (!topicName.equals(other.topicName))
            return false;
        if (uriConn == null) {
            if (other.uriConn != null)
                return false;
        } else if (!uriConn.equals(other.uriConn))
            return false;
        return true;
    }
}
