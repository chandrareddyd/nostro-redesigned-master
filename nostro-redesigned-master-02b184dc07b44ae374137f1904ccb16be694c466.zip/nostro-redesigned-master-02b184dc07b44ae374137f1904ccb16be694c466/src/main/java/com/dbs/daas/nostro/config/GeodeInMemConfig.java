package com.dbs.daas.nostro.config;


import java.util.Properties;

import org.apache.geode.cache.GemFireCache;
import org.apache.geode.cache.query.QueryService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Profile;
import org.springframework.data.gemfire.CacheFactoryBean;
import org.springframework.data.gemfire.IndexFactoryBean;
import org.springframework.data.gemfire.IndexType;
import org.springframework.data.gemfire.PartitionedRegionFactoryBean;
import org.springframework.data.gemfire.repository.config.EnableGemfireRepositories;

import com.dbs.daas.nostro.LocalNostroApplication;
import com.dbs.daas.nostro.model.BatchFile;
import com.dbs.daas.nostro.model.ClientState;
import com.dbs.daas.nostro.model.EntityData;
import com.dbs.daas.nostro.model.Notification;
import com.dbs.daas.nostro.model.SchemaModel;


@Configuration
@Profile({"inmem", "dev"})
@EnableGemfireRepositories(value = "com.dbs.daas.nostro.repositories")
public class GeodeInMemConfig {

    protected static final String DEFAULT_GEMFIRE_LOG_LEVEL = "error";

    protected String applicationName() {
        return LocalNostroApplication.class.getSimpleName();
    }

    protected String logLevel() {
        return System.getProperty("gemfire.log-level", DEFAULT_GEMFIRE_LOG_LEVEL);
    }

    public Properties geodeProperties() {
        Properties gemfireProperties = new Properties();

        gemfireProperties.setProperty("name", applicationName());
        gemfireProperties.setProperty("mcast-port", "0");
        gemfireProperties.setProperty("log-level", logLevel());

        return gemfireProperties;
    }

    @Bean
    public CacheFactoryBean geodeCache() {
        CacheFactoryBean gemfireCache = new CacheFactoryBean();
        gemfireCache.setClose(true);
        gemfireCache.setProperties(geodeProperties());
        return gemfireCache;
    }

    @Bean("EntityData")
    public PartitionedRegionFactoryBean<String, EntityData> dataEntitiesRegion(GemFireCache gemfireCache) {

        PartitionedRegionFactoryBean<String, EntityData> dataEntitiesRegion = new PartitionedRegionFactoryBean<>();
        dataEntitiesRegion.setCache(gemfireCache);
        dataEntitiesRegion.setClose(false);
        dataEntitiesRegion.setPersistent(false);
        dataEntitiesRegion.setName("EntityData");
        return dataEntitiesRegion;
    }

    @Bean
    public PartitionedRegionFactoryBean<String, SchemaModel> schemaModelPartitionedRegionFactoryBean(GemFireCache gemfireCache) {

        PartitionedRegionFactoryBean<String, SchemaModel> schemaModelPartitionedRegionFactoryBean = new PartitionedRegionFactoryBean<>();
        schemaModelPartitionedRegionFactoryBean.setCache(gemfireCache);
        schemaModelPartitionedRegionFactoryBean.setClose(false);
        schemaModelPartitionedRegionFactoryBean.setPersistent(false);
        schemaModelPartitionedRegionFactoryBean.setName("Schemas");
        return schemaModelPartitionedRegionFactoryBean;
    }

    @Bean
    public PartitionedRegionFactoryBean<String, BatchFile> batchFilePartitionedRegionFactoryBean(GemFireCache gemfireCache) {

        PartitionedRegionFactoryBean<String, BatchFile> batchFilePartitionedRegionFactoryBean = new PartitionedRegionFactoryBean<>();
        batchFilePartitionedRegionFactoryBean.setCache(gemfireCache);
        batchFilePartitionedRegionFactoryBean.setClose(false);
        batchFilePartitionedRegionFactoryBean.setPersistent(false);
        batchFilePartitionedRegionFactoryBean.setName("BatchFiles");
        return batchFilePartitionedRegionFactoryBean;
    }

    @Bean
    public PartitionedRegionFactoryBean<String, ClientState> clientStatePartitionedRegionFactoryBean(GemFireCache gemfireCache) {

        PartitionedRegionFactoryBean<String, ClientState> clientStatePartitionedRegionFactoryBean = new PartitionedRegionFactoryBean<>();
        clientStatePartitionedRegionFactoryBean.setCache(gemfireCache);
        clientStatePartitionedRegionFactoryBean.setClose(false);
        clientStatePartitionedRegionFactoryBean.setPersistent(false);
        clientStatePartitionedRegionFactoryBean.setName("ClientState");
        return clientStatePartitionedRegionFactoryBean;
    }

    @Bean
    public PartitionedRegionFactoryBean<String, Notification> notificationPartitionedRegionFactoryBean(GemFireCache gemfireCache) {

        PartitionedRegionFactoryBean<String, Notification> notificationPartitionedRegionFactoryBean = new PartitionedRegionFactoryBean<>();
        notificationPartitionedRegionFactoryBean.setCache(gemfireCache);
        notificationPartitionedRegionFactoryBean.setClose(false);
        notificationPartitionedRegionFactoryBean.setPersistent(false);
        notificationPartitionedRegionFactoryBean.setName("Notifications");
        return notificationPartitionedRegionFactoryBean;
    }

    @Bean
    @DependsOn("EntityData")
    public IndexFactoryBean indexFactoryBean(GemFireCache gemfireCache) {

        IndexFactoryBean indexFactoryBean = new IndexFactoryBean();
        indexFactoryBean.setCache(gemfireCache);

        indexFactoryBean.setType(IndexType.HASH);
        indexFactoryBean.setFrom("/EntityData");
        indexFactoryBean.setName("dataEntities_PositionDateIdx");
        indexFactoryBean.setExpression("positionDate");
        return indexFactoryBean;
    }

    @Bean
    public QueryService queryService(GemFireCache gemfireCache) {
        return gemfireCache.getQueryService();
    }

}
