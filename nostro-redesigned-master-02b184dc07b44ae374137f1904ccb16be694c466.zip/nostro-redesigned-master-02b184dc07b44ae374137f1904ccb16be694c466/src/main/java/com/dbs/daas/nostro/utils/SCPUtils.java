package com.dbs.daas.nostro.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.dbs.daas.nostro.config.SCPSourceOptionsMetadata;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;

@Component
public class SCPUtils {


    private static final Logger LOGGER = LoggerFactory.getLogger(SCPUtils.class);

    public Session authenticateScpServer(SCPSourceOptionsMetadata options) throws JSchException {
        JSch jsch = new JSch();

        java.util.Properties config = new java.util.Properties();
        config.put("StrictHostKeyChecking", "no");

        Session session = jsch.getSession(options.getUsername(), options.getHostname(), options.getPort());
        
        if(!StringUtils.isEmpty(options.getPrivateKey())) {
        	
        	String escapedPrivateKey = StringEscapeUtils.unescapeJava(options.getPrivateKey());
        	jsch.addIdentity("privateKey", escapedPrivateKey.getBytes(), null, null);
        	
        } else {
            session.setPassword(options.getPassword());
        }
        
        session.setConfig(config);

        session.connect();

        return session;
    }

    public String shasumRemoteFile(SCPSourceOptionsMetadata options, Session session, Integer fileIndex, String remoteFileName) throws IOException {


        BufferedReader reader = null;
        Channel channel = null;

        try {

            // exec 'shasum rfile' remotely,
            String command = "shasum -a 512 " + remoteFileName;
            channel = session.openChannel("exec");

            reader = new BufferedReader(new InputStreamReader(channel.getInputStream()));
            ((ChannelExec) channel).setCommand(command);

            channel.connect();

            String msg;
            StringBuilder stringBuilder = new StringBuilder();

            while ((msg = reader.readLine()) != null) {

                stringBuilder.append(msg);
            }

            return parseShasumReturn(stringBuilder.toString());

        } catch (JSchException e) {
            LOGGER.error("error hashing file: " + options.getFileNames().get(fileIndex), e);
        } finally {

            if (reader != null) {
                reader.close();
            }

            if (channel != null) 
            	channel.disconnect();
        }

        return "";

    }

    public String parseShasumReturn(String returnedString) {
        String[] lines = returnedString.split("\n");
        String lineOfInterest = lines[lines.length - 1];
        String[] contentOfInterest = lineOfInterest.split("\\s");
        return contentOfInterest[0];
    }

    public String checksumLocalFile(InputStream inputStream) {

        MessageDigest md = null;

        Formatter formatter = new Formatter();
        try {

            md = MessageDigest.getInstance("SHA-512");
            DigestInputStream dis = new DigestInputStream(inputStream, md);
            byte[] buffer = new byte[1024];
            int read = dis.read(buffer);
            while (read > -1) {
                read = dis.read(buffer);
            }
            byte[] digest = md.digest();


            for (byte b : digest) {
                formatter.format("%02x", b);
            }
            String hex = formatter.toString();

            return hex;

        } catch (NoSuchAlgorithmException e) {
            LOGGER.error("Error processing checksum (sha1) local file: ", e);
        } catch (IOException e) {
            LOGGER.error("Error processing checksum (sha1) local file: ", e);
        } finally {
            formatter.close();
            try {
                inputStream.close();
            } catch (IOException e) {
                LOGGER.error("Error closing inputstream", e);
            }
        }
        return null;

    }

    public File getRemoteFile(String remoteFileName, Session session, Integer fileIndex, String tempFileName) throws IOException {
        InputStream in = null;
        OutputStream out = null;
        FileOutputStream fos = null;
        boolean isDeleted;
        try {


            File tempFile = new File(tempFileName);
            if (tempFile.exists()) {
                tempFile.delete();
            }

            // exec 'scp -f rfile' remotely
            String command = "scp -f " + remoteFileName;
            Channel channel = session.openChannel("exec");
            ((ChannelExec) channel).setCommand(command);

            out = channel.getOutputStream();
            in = channel.getInputStream();
            channel.connect();
            byte[] buf = new byte[1024];
            buf[0] = 0;
            out.write(buf, 0, 1);
            out.flush();

            while (true) {
                int c = checkAck(in);
                if (c != 'C') {
                    break;
                }

                // read '0644 '
                in.read(buf, 0, 5);

                long filesize = 0L;
                while (true) {
                    if (in.read(buf, 0, 1) < 0) {
                        // error
                        break;
                    }
                    if (buf[0] == ' ')
                        break;
                    filesize = filesize * 10L + (long) (buf[0] - '0');
                }

                String filename = null;
                for (int i = 0; ; i++) {
                    in.read(buf, i, 1);
                    if (buf[i] == (byte) 0x0a) {
                        filename = new String(buf, 0, i);
                        break;
                    }
                }

                buf[0] = 0;
                out.write(buf, 0, 1);
                out.flush();

                // read a content of tempFileName
                fos = new FileOutputStream(tempFileName);
                int foo;
                while (true) {
                    if (buf.length < filesize)
                        foo = buf.length;
                    else
                        foo = (int) filesize;
                    foo = in.read(buf, 0, foo);
                    if (foo < 0) {
                        // error
                        break;
                    }
                    fos.write(buf, 0, foo);
                    filesize -= foo;
                    if (0L == filesize)
                        break;
                }
                fos.close();
                fos = null;

                // send '\0'
                buf[0] = 0;
                out.write(buf, 0, 1);
                out.flush();
            }
        } catch (Exception e) {
            LOGGER.error("error copying file", e);
        } finally {
            try {
                if (fos != null)
                    fos.close();
                
                if (out != null)
                    out.close();
                
                if (in != null)
                	in.close();
            } catch (Exception e2) {
                LOGGER.warn("error closing file output stream session", e2);
            }
        }
        return new File(tempFileName);
    }
    
    public Boolean validateRemoteFileAttributes(Session session, String filePath) {

		Channel channel = null;
		ChannelSftp channelSftp = null;
		SftpATTRS fileAttributes = null;
    	
    	try {
    		
    		channel = session.openChannel("sftp");
    		channel.connect();
    		channelSftp = (ChannelSftp) channel;
    		
    		fileAttributes = channelSftp.lstat(filePath);
    		
    		if(null == fileAttributes) {
    			return false;
    		} else {
    			if(fileAttributes.isDir()) {
        			LOGGER.info(filePath + " is a direcotry");
    				return false;
    			} else if(fileAttributes.getSize() <= 0L) {
        			LOGGER.info(filePath + " is empty.");
    				return false;
        		}
    			LOGGER.info(filePath + " exists with permissions: " + fileAttributes.getPermissions() + " (" + fileAttributes.getPermissionsString() + ")");
    		}			
		} catch (Exception e) {
			LOGGER.error("Error occured while checking remote file attributes for " + filePath + ". Error: " + e.getMessage());
			return false;
		} finally {			
			if (null != channelSftp) {
				channelSftp.disconnect();
			}
			if (null != channel) {
				channel.disconnect();
			}
		}
		return true;
    }
    
    public void renameRemoteFile(Session session, String oldFileName, String newFileName) {

		Channel channel = null;
    	
    	try {

			String command = "mv -f " + oldFileName + " " + newFileName;
	        channel = session.openChannel("exec");
	        ((ChannelExec) channel).setCommand(command);	        
			channel.connect();	
			
		} catch (Exception e) {
			LOGGER.error("Exception occured while renaming the remote file.", e);
		} finally {			
			if (null != channel) {
				channel.disconnect();
			}
		}
    }

    private int checkAck(InputStream in) throws IOException {
        int b = in.read();
        // b may be 0 for success,
        // 1 for error,
        // 2 for fatal error,
        // -1
        if (b == 0)
            return b;
        if (b == -1)
            return b;

        if (b == 1 || b == 2) {
            StringBuilder sb = new StringBuilder();
            int c;
            do {
                c = in.read();
                sb.append((char) c);
            } while (c != '\n');
            if (b == 1) { // error
                LOGGER.error(sb.toString());
            }
            if (b == 2) { // fatal error
                LOGGER.error(sb.toString());
            }
        }
        return b;
    }

    public boolean checkOutstandingAmountSum(SCPSourceOptionsMetadata options, Integer fileIndex, InputStream inputStream) throws IOException {
    	if(null == inputStream) {
    		return false;
    	}
    	ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    	FixedLengthPayloadParser parser = new FixedLengthPayloadParser();
        BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
        String line = br.readLine();

        BigDecimal outstandingAmountSum = new BigDecimal(0);
        int totalCount = 0;
        int lineNo = 0;
        String footer = null;
        String currentLine = null;
        while (line != null) {
            try {
                currentLine = line;
                line = br.readLine();
                lineNo++;
                boolean isLastLine = line == null;

                if (isLastLine) {
                    footer = currentLine;
                }

                if (!isLastLine && 1 < lineNo) {
                    Map<String, Object> payloadMap = parser.parsePayload(currentLine, options, fileIndex);

                    if (null != payloadMap && !payloadMap.isEmpty()) {
                           if(null != payloadMap.get(ApiConstants.OUTSTANDING_AMOUNT)) {
                        	   outstandingAmountSum = outstandingAmountSum.add(new BigDecimal((String)payloadMap.get(ApiConstants.OUTSTANDING_AMOUNT)));
                           }
                    }
                }
            } catch (Exception ex) {
                LOGGER.warn("Error proccessing line " + totalCount, ex);
            } finally {
                totalCount++;
            }
        }
        Map<String, Object> footerMap = parser.parseFooter(footer, options, fileIndex);
        BigDecimal footerOutstandingAmountSum = null;
        if (null != footerMap && !footerMap.isEmpty()) {
            if(null!=footerMap.get(ApiConstants.OUTSTANDING_AMOUNT)) {
            	footerOutstandingAmountSum = new BigDecimal((String)footerMap.get(ApiConstants.OUTSTANDING_AMOUNT));
            }
        }
        if(null != footerOutstandingAmountSum && outstandingAmountSum.equals(footerOutstandingAmountSum)) {
        	return true;
        }
        return false;
    }
}
