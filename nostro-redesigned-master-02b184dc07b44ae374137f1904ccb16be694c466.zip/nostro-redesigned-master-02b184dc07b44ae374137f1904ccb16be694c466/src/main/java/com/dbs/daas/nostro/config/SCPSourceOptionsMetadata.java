package com.dbs.daas.nostro.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.util.Map;


/**
 * Metadata for DaasNostroApplication
 */
//@RefreshScope
@ConfigurationProperties(prefix = "scp")
@Component
public class SCPSourceOptionsMetadata {

    /**
     * cron expression to start processing source
     */
    private String cron;

    @NotNull
    /** hostname of remote server*/
    private String hostname;

    /**
     * port of remote server (default: 22)
     */
    private int port = 22;

    @NotNull
    /** username for login on remote server*/
    private String username;

    /**
     * password for login on remote server
     */
    private String password;

    /**
     * privateKey (content in a single line) for login on remote server
     */
    private String privateKey;

    /**
     * remote source system name
     */
    private String fileSource;

    /**
     * type of file
     */
    private Map<Integer, String> fileTypes;

    /**
     * endpoint of cloud storage
     */
    private String minioEndpoint;

    /**
     * access key for cloud storage
     */
    private String minioAccessKey;

    /**
     * secret key for cloud storage
     */
    private String minioSecretKey;

    /**
     * bucket name for cloud storage
     */
    private String minioBucketName;

    /**
     * number of lines to send per message (default: 1)
     */
    private int noOfLines = 1;

    @NotNull
    /** remote files to be copied (scp) over */
    private Map<Integer, String> fileNames;

    /**
     * column names in header line (separated by comma)
     */
    private Map<Integer, String[]> headerColumnNames;

    /**
     * column names in payload (separated by comma)
     */
    private Map<Integer, String[]> columnNames;

    /**
     * whether to skip sending header line (true or false)
     */
    private Map<Integer, Boolean> skipHeader;

    /**
     * whether to skip sending footer line (true or false)
     */
    private Map<Integer, Boolean> skipFooter;

    /**
     * whether to validate count provided in footer line (true or false)
     */
    private Map<Integer, Boolean> validateCountInFooter;

    /**
     * type of content (valid values: delimited or fixedlength)
     */
    private Map<Integer, String> contentType;

    /**
     * required for delimited type (if headerColumnNames is specified): column indexes in header line (starting from 0 and separated by comma)
     */
    private Map<Integer, Integer[]> headerColumnDataIndexes;

    /**
     * required for delimited type (if validateCountInFooter is true): column index in footer line with record count (starting from 0)
     */
    private Map<Integer, Integer[]> footerCountColumnIndex;

    /**
     * required for delimited type: column indexes in payload (starting from 0 and separated by comma)
     */
    private Map<Integer, Integer[]> columnDataIndexes;

    /**
     * required for delimited type: column delimiter in payload
     */
    private Map<Integer, String> columnDelimiter;

    /**
     * required for fixedlength type (if headerColumnNames is specified): column ranges in header line (range index start from 1 and separated by comma)
     */
    private Map<Integer, String[]> headerColumnRanges;

    /**
     * required for fixedlength type (if validateCountInFooter is true): column range in footer line with record count (range index start from 1)
     */
    private Map<Integer, String[]> footerCountColumnRange;

    /**
     * required for fixedlength type: column ranges in payload (range index start from 1 and separated by comma)
     */
    private Map<Integer, String[]> columnRanges;

    private Map<Integer, String> country;

    /**
     * owner responsible to follow up in event of any error during source processing
     */
    private String errorOwner;

    /**
     * queue where message will be sent to
     */
    private String queue;

    /**
     * queue where error message will be sent to in event of any error during source processing
     */
    private String errorq;

    /**
     * Reference File to indicate the reference file when there is more than one file
     **/
    private Map<Integer, Boolean> referenceFile;

    public String getCron() {
        return cron;
    }

    public void setCron(String cron) {
        this.cron = cron;
    }

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPrivateKey() {
        return privateKey;
    }

    public void setPrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }

    public String getFileSource() {
        return fileSource;
    }

    public void setFileSource(String fileSource) {
        this.fileSource = fileSource;
    }

    public Map<Integer, String> getFileTypes() {
        return fileTypes;
    }

    public void setFileTypes(Map<Integer, String> fileTypes) {
        this.fileTypes = fileTypes;
    }

    public String getMinioEndpoint() {
        return minioEndpoint;
    }

    public void setMinioEndpoint(String minioEndpoint) {
        this.minioEndpoint = minioEndpoint;
    }

    public String getMinioAccessKey() {
        return minioAccessKey;
    }

    public void setMinioAccessKey(String minioAccessKey) {
        this.minioAccessKey = minioAccessKey;
    }

    public String getMinioSecretKey() {
        return minioSecretKey;
    }

    public void setMinioSecretKey(String minioSecretKey) {
        this.minioSecretKey = minioSecretKey;
    }

    public String getMinioBucketName() {
        return minioBucketName;
    }

    public void setMinioBucketName(String minioBucketName) {
        this.minioBucketName = minioBucketName;
    }

    public int getNoOfLines() {
        return noOfLines;
    }

    public void setNoOfLines(int noOfLines) {
        this.noOfLines = noOfLines;
    }

    public Map<Integer, String> getFileNames() {
        return fileNames;
    }

    public void setFileNames(Map<Integer, String> fileNames) {
        this.fileNames = fileNames;
    }

    public Map<Integer, String[]> getHeaderColumnNames() {
        return headerColumnNames;
    }

    public void setHeaderColumnNames(Map<Integer, String[]> headerColumnNames) {
        this.headerColumnNames = headerColumnNames;
    }

    public Map<Integer, String[]> getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(Map<Integer, String[]> columnNames) {
        this.columnNames = columnNames;
    }

    public Map<Integer, Boolean> getSkipHeader() {
        return skipHeader;
    }

    public void setSkipHeader(Map<Integer, Boolean> skipHeader) {
        this.skipHeader = skipHeader;
    }

    public Map<Integer, Boolean> getSkipFooter() {
        return skipFooter;
    }

    public void setSkipFooter(Map<Integer, Boolean> skipFooter) {
        this.skipFooter = skipFooter;
    }

    public Map<Integer, Boolean> getValidateCountInFooter() {
        return validateCountInFooter;
    }

    public void setValidateCountInFooter(Map<Integer, Boolean> validateCountInFooter) {
        this.validateCountInFooter = validateCountInFooter;
    }

    public Map<Integer, String> getContentType() {
        return contentType;
    }

    public void setContentType(Map<Integer, String> contentType) {
        this.contentType = contentType;
    }

    public Map<Integer, Integer[]> getHeaderColumnDataIndexes() {
        return headerColumnDataIndexes;
    }

    public void setHeaderColumnDataIndexes(Map<Integer, Integer[]> headerColumnDataIndexes) {
        this.headerColumnDataIndexes = headerColumnDataIndexes;
    }

    public Map<Integer, Integer[]> getFooterCountColumnIndex() {
        return footerCountColumnIndex;
    }

    public void setFooterCountColumnIndex(Map<Integer, Integer[]> footerCountColumnIndex) {
        this.footerCountColumnIndex = footerCountColumnIndex;
    }

    public Map<Integer, Integer[]> getColumnDataIndexes() {
        return columnDataIndexes;
    }

    public void setColumnDataIndexes(Map<Integer, Integer[]> columnDataIndexes) {
        this.columnDataIndexes = columnDataIndexes;
    }

    public Map<Integer, String> getColumnDelimiter() {
        return columnDelimiter;
    }

    public void setColumnDelimiter(Map<Integer, String> columnDelimiter) {
        this.columnDelimiter = columnDelimiter;
    }

    public Map<Integer, String[]> getHeaderColumnRanges() {
        return headerColumnRanges;
    }

    public void setHeaderColumnRanges(Map<Integer, String[]> headerColumnRanges) {
        this.headerColumnRanges = headerColumnRanges;
    }

    public Map<Integer, String[]> getFooterCountColumnRange() {
        return footerCountColumnRange;
    }

    public void setFooterCountColumnRange(Map<Integer, String[]> footerCountColumnRange) {
        this.footerCountColumnRange = footerCountColumnRange;
    }

    public Map<Integer, String[]> getColumnRanges() {
        return columnRanges;
    }

    public void setColumnRanges(Map<Integer, String[]> columnRanges) {
        this.columnRanges = columnRanges;
    }

    public String getErrorOwner() {
        return errorOwner;
    }

    public void setErrorOwner(String errorOwner) {
        this.errorOwner = errorOwner;
    }

    public String getQueue() {
        return queue;
    }

    public void setQueue(String queue) {
        this.queue = queue;
    }

    public String getErrorq() {
        return errorq;
    }

    public void setErrorq(String errorq) {
        this.errorq = errorq;
    }

    public Map<Integer, Boolean> getReferenceFile() {
        return referenceFile;
    }

    public void setReferenceFile(Map<Integer, Boolean> referenceFile) {
        this.referenceFile = referenceFile;
    }

    public Map<Integer, String> getCountry() {
        return country;
    }

    public void setCountry(Map<Integer, String> country) {
        this.country = country;
    }
}
