package com.dbs.daas.nostro.model;

import org.apache.geode.pdx.PdxReader;
import org.apache.geode.pdx.PdxSerializable;
import org.apache.geode.pdx.PdxWriter;
import org.springframework.data.annotation.Id;
import org.springframework.data.gemfire.mapping.Region;

import java.util.Arrays;
import java.util.List;

@Region("Schemas")
public class SchemaModel implements PdxSerializable {

    @Id
    /** client that register schema model*/
    private String appName;

    /**
     * list of fields that represents the schema model
     */
    private List<String> model;

    /**
     * Queue name
     */
    private String topicName;

    /**
     * Host for Queue
     */
    private String mqHost;

    /**
     * Port for Queue
     */
    private int mqPort;

    /**
     * Username for Queue
     */
    private String mqUsername;

    /**
     * Password for Queue
     */
    private String mqPassword;

    /**
     * Virtual Host for Queue
     */
    private String mqVirtualHost;

    public SchemaModel() {
    }

    public SchemaModel(String appName, List<String> model, String topicName, String mqHost, int mqPort, String mqUsername, String mqPassword, String mqVirtualHost) {
        this.appName = appName;
        this.model = model;
        this.topicName = topicName;
        this.mqHost = mqHost;
        this.mqPort = mqPort;
        this.mqUsername = mqUsername;
        this.mqPassword = mqPassword;
        this.mqVirtualHost = mqVirtualHost;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public List<String> getModel() {
        return model;
    }

    public void setModel(List<String> model) {
        this.model = model;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public String getMqHost() {
        return mqHost;
    }

    public void setMqHost(String mqHost) {
        this.mqHost = mqHost;
    }

    public int getMqPort() {
        return mqPort;
    }

    public void setMqPort(int mqPort) {
        this.mqPort = mqPort;
    }

    public String getMqUsername() {
        return mqUsername;
    }

    public void setMqUsername(String mqUsername) {
        this.mqUsername = mqUsername;
    }

    public String getMqPassword() {
        return mqPassword;
    }

    public void setMqPassword(String mqPassword) {
        this.mqPassword = mqPassword;
    }

    public String getMqVirtualHost() {
        return mqVirtualHost;
    }

    public void setMqVirtualHost(String mqVirtualHost) {
        this.mqVirtualHost = mqVirtualHost;
    }


    @Override
    public void toData(PdxWriter pdxWriter) {
        pdxWriter.writeString("appName", this.appName);

        String[] modelArray = new String[this.model.size()];
        modelArray = this.model.toArray(modelArray);
        pdxWriter.writeStringArray("model", modelArray);
        pdxWriter.writeString("topicName", this.topicName);
        pdxWriter.writeString("mqHost", this.mqHost);
        pdxWriter.writeInt("mqPort", this.mqPort);
        pdxWriter.writeString("mqUsername", this.mqUsername);
        pdxWriter.writeString("mqPassword", this.mqPassword);
        pdxWriter.writeString("mqVirtualHost", this.mqVirtualHost);
    }

    @Override
    public void fromData(PdxReader pdxReader) {
        this.appName = pdxReader.readString("appName");
        this.model = Arrays.asList(pdxReader.readStringArray("model"));
        this.topicName = pdxReader.readString("topicName");
        this.mqHost = pdxReader.readString("mqHost");
        this.mqPort = pdxReader.readInt("mqPort");
        this.mqUsername = pdxReader.readString("mqUsername");
        this.mqPassword = pdxReader.readString("mqPassword");
        this.mqVirtualHost = pdxReader.readString("mqVirtualHost");
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SchemaModel that = (SchemaModel) o;

        if (mqPort != that.mqPort) return false;
        if (appName != null ? !appName.equals(that.appName) : that.appName != null) return false;
        if (model != null ? !model.equals(that.model) : that.model != null) return false;
        if (topicName != null ? !topicName.equals(that.topicName) : that.topicName != null) return false;
        if (mqHost != null ? !mqHost.equals(that.mqHost) : that.mqHost != null) return false;
        if (mqUsername != null ? !mqUsername.equals(that.mqUsername) : that.mqUsername != null) return false;
        if (mqPassword != null ? !mqPassword.equals(that.mqPassword) : that.mqPassword != null) return false;
        return mqVirtualHost != null ? mqVirtualHost.equals(that.mqVirtualHost) : that.mqVirtualHost == null;
    }

    @Override
    public int hashCode() {
        int result = appName != null ? appName.hashCode() : 0;
        result = 31 * result + (model != null ? model.hashCode() : 0);
        result = 31 * result + (topicName != null ? topicName.hashCode() : 0);
        result = 31 * result + (mqHost != null ? mqHost.hashCode() : 0);
        result = 31 * result + mqPort;
        result = 31 * result + (mqUsername != null ? mqUsername.hashCode() : 0);
        result = 31 * result + (mqPassword != null ? mqPassword.hashCode() : 0);
        result = 31 * result + (mqVirtualHost != null ? mqVirtualHost.hashCode() : 0);
        return result;
    }
}
