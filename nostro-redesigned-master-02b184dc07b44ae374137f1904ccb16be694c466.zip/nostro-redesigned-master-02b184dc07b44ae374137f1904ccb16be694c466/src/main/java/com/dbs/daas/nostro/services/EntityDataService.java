package com.dbs.daas.nostro.services;



import static com.dbs.daas.nostro.utils.ApiConstants.BATCH_FILE_STATUS_INPROGRESS;
import static com.dbs.daas.nostro.utils.ApiConstants.BATCH_FILE_STATUS_PROCESSED;
import static com.dbs.daas.nostro.utils.ApiConstants.DDMMYYYY;
import static com.dbs.daas.nostro.utils.ApiConstants.ENTITY_DATA_MODEL_FIELDS;
import static com.dbs.daas.nostro.utils.ApiConstants.ENTITY_DATA_MODEL_FIELDS_ARRAY;
import static com.dbs.daas.nostro.utils.CommonUtil.dateFormatter;
import static com.dbs.daas.nostro.utils.CommonUtil.stringToDate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dbs.daas.nostro.config.SCPSourceOptionsMetadata;
import com.dbs.daas.nostro.exceptions.APIException;
import com.dbs.daas.nostro.model.BatchFile;
import com.dbs.daas.nostro.model.ClientState;
import com.dbs.daas.nostro.model.EntityData;
import com.dbs.daas.nostro.model.SchemaModel;
import com.dbs.daas.nostro.repositories.BatchFileRepository;
import com.dbs.daas.nostro.repositories.EntityDataRepository;
import com.dbs.daas.nostro.utils.ApiConstants;
import com.dbs.daas.nostro.utils.FixedLengthPayloadParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class EntityDataService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EntityDataService.class);
    private final ObjectMapper mapper = new ObjectMapper().setDateFormat(new SimpleDateFormat(DDMMYYYY));
    private SCPSourceOptionsMetadata options;
    private EntityDataRepository entityDataRepository;
    private BatchFileRepository fileRepository;
    private ClientStateService clientStateService;

    @Value("${check.file.processing}")
    private long timeToCheckFileProcessing;

    @Autowired
    public EntityDataService(SCPSourceOptionsMetadata options, EntityDataRepository entityDataRepository,
                             BatchFileRepository fileRepository, ClientStateService clientStateService) {
        this.options = options;
        this.entityDataRepository = entityDataRepository;
        this.clientStateService = clientStateService;
        this.fileRepository = fileRepository;
    }
    
    public BatchFile getBatchFile(String checksum) {
    	return fileRepository.findOne(checksum);
    }


    public boolean checkFileForProcessing(String fileName, String checksum) {
    	String fileStatusMsg = fileName + " with checksum: " + checksum;
        boolean exists = fileRepository.exists(checksum);
        if (!exists) { 
        	LOGGER.info(fileStatusMsg + " NOT EXISTS");
        	return true;
        }
        else {
            BatchFile batchFile = fileRepository.findOne(checksum);
            if (batchFile.getStatus().equalsIgnoreCase(BATCH_FILE_STATUS_PROCESSED)) {
            	LOGGER.info(fileStatusMsg + " is already PROCESSED");
                return false;
            } else if (batchFile.getStatus().equalsIgnoreCase(BATCH_FILE_STATUS_INPROGRESS) && !dateInRange(batchFile.getDatetime())) {
            	LOGGER.info(fileStatusMsg + " is in INPROGRESS");
                return false;
            } else { 
            	LOGGER.info(fileStatusMsg + " is ready for processing");
            	return true;
            }
        }
    }

    private boolean dateInRange(long date0) {
        long sixHours = timeToCheckFileProcessing;
        long currentDate = System.currentTimeMillis();
        return (currentDate - date0) > sixHours;
    }

    public void createOrUpdateStatus(BatchFile batchFile) {
        fileRepository.save(batchFile);
    }


    public EntityData getLatestTransaction() {
        return entityDataRepository.getLatestDataEntity();

    }

    private Page<EntityData> getPage(List<EntityData> entityDataList, int page, int size) {

        if (entityDataList == null || entityDataList.isEmpty())
            return new PageImpl<>(new ArrayList<>(), new PageRequest(page, size), 0);

        int min = page * size;
        int max = Math.min(min + size, entityDataList.size());

        List<EntityData> paginatedList = IntStream.range(0, entityDataList.size()).filter(i -> i >= min)
                .filter(i -> i < max)
                .mapToObj(i -> entityDataList.get(i))
                .collect(Collectors.toList());


        PagedListHolder<EntityData> holder = new PagedListHolder<>(paginatedList);
        holder.setPage(page);
        holder.setPageSize(size);

        return new PageImpl<>(holder.getPageList(), new PageRequest(page, size), entityDataList.size());

    }

    private String defaultReturnMessage(String message) throws JsonProcessingException{
        Map<String, Object> responseJsonObject = new HashMap<>();
        responseJsonObject.put("remarks", message);
        responseJsonObject.put("totalElements", 0);
        responseJsonObject.put("totalPages", 0);
        responseJsonObject.put("last", true);
        return mapper.writeValueAsString(responseJsonObject);
    }

    public String getData(SchemaModel schemaModel, Long timestampRequestDate, String replay, int requestedPage, int size, boolean latest)
            throws JsonProcessingException, APIException {

        Long latestPositionDate;
        Long batchDate;
        List<EntityData> entityDataList = null;
        int maxPages = 0;

        if(null == schemaModel || null == schemaModel.getModel() || schemaModel.getModel().isEmpty()) {
			return defaultReturnMessage("no schema model defined!");
		}

        ClientState currentState = clientStateService.get(schemaModel.getAppName());

		if(latest){

            EntityData latestData = getLatestTransaction();

            if (null == latestData) // there is no data in the database.
                return defaultReturnMessage("no data in the database!");


            latestPositionDate = latestData.getPositionDate();
            entityDataList = entityDataRepository.getAllByPositionDate(latestPositionDate);
            if(null != entityDataList && !entityDataList.isEmpty()) {
                if (entityDataList.size() % size == 0) {
                    maxPages = (entityDataList.size() / size);
                } else {
                    maxPages = (entityDataList.size() / size) + 1;
                }
            }

            if (null == currentState) {

            	if ("N".equalsIgnoreCase(replay)){ // make sure we increment page request and don't go over max pages possible.

                    if(requestedPage < 0)
                        requestedPage = 0;

                    if(requestedPage >= maxPages)
                        requestedPage = maxPages - 1;

                }else { // Y option defined. start with page 0. Same for any other letter that is not N.

                    requestedPage = 0;
                }

                ClientState newState = new ClientState(schemaModel.getAppName(), requestedPage, System.currentTimeMillis(), latestPositionDate);
                batchDate = newState.getBatchDate();
                updateClientState(newState);

            } else {

                batchDate = currentState.getBatchDate();

                if(latestPositionDate > batchDate) {// need to stop pagination and start from 0. as newer data is available

                    requestedPage = 0;
                    currentState.setBatchDate(latestPositionDate);
                    currentState.setPageNo(requestedPage);
                    batchDate = currentState.getBatchDate();

                }else if ("N".equalsIgnoreCase(replay)){ // make sure we increment page request and don't go over max pages possible.

                    if(requestedPage < 0)
                        requestedPage = currentState.getPageNo() + 1;

                    if(requestedPage >= maxPages)
                        requestedPage = maxPages - 1;

                }else { // Y option defined. start with page 0. Same for any other letter that is not N.

                    requestedPage = 0;
                }

                currentState.setPageNo(requestedPage);
                currentState.setDateOfRequest(System.currentTimeMillis());
                updateClientState(currentState);
            }


        }else{ //specific date. Uses date passed on the method.

            entityDataList = entityDataRepository.getAllByPositionDate(timestampRequestDate);
            if(null != entityDataList && !entityDataList.isEmpty()) {
                if (entityDataList.size() % size == 0) {
                    maxPages = (entityDataList.size() / size);
                } else {
                    maxPages = (entityDataList.size() / size) + 1;
                }
            } else {
                return defaultReturnMessage("no data in the database for this date: " + dateFormatter(DDMMYYYY,new Date(timestampRequestDate)));
            }

            if (null == currentState) {
            	if ("N".equalsIgnoreCase(replay)){ // make sure we increment page request and don't go over max pages possible.

                    if(requestedPage < 0)
                        requestedPage = 0;

                    if(requestedPage >= maxPages)
                        requestedPage = maxPages - 1;

                }else { // Y option defined. start with page 0. Same for any other letter that is not N.

                    requestedPage = 0;
                }

                ClientState newState = new ClientState(schemaModel.getAppName(), requestedPage, System.currentTimeMillis(), timestampRequestDate);
                batchDate = newState.getBatchDate();
                updateClientState(newState);

            }else{

                if ("N".equalsIgnoreCase(replay)){

                    if(requestedPage < 0){

                        requestedPage = currentState.getPageNo() + 1;
                    }

                    if(requestedPage >= maxPages) {
                        requestedPage = maxPages - 1;
                    }

                }else {
                    requestedPage = 0;
                }

                currentState.setBatchDate(timestampRequestDate);

                batchDate = currentState.getBatchDate();
                currentState.setPageNo(requestedPage);
                currentState.setDateOfRequest(System.currentTimeMillis());

                updateClientState(currentState);
            }

        }

        if (null != entityDataList && !entityDataList.isEmpty()) {

            final List<Map<String, String>> entityDataPageList = new ArrayList<>();

            Page<EntityData> currentPage = getPage(entityDataList, requestedPage, size);

            currentPage.map(entityData -> toJsonObject(entityData)).map(jsonObject -> {
                Map<String, String> dataMap = generateMap(schemaModel, jsonObject);
                return dataMap;
            }).forEach(entity -> entityDataPageList.add(entity));

            Map<String, Object> responseJsonObject = new HashMap<>();
            responseJsonObject.put("content", entityDataPageList);
            responseJsonObject.put("size", size);
            responseJsonObject.put("pageNumber", requestedPage);
            responseJsonObject.put("numberOfElements", entityDataPageList.size());
            responseJsonObject.put("sort", "desc");

            responseJsonObject.put("totalElements", currentPage.getTotalElements());
            responseJsonObject.put("totalPages", currentPage.getTotalPages());

            if ((currentPage.getTotalPages() - 1) == requestedPage) {
                responseJsonObject.put("last", true);
            } else {
                responseJsonObject.put("last", false);
            }
            if (0 == requestedPage) {
                responseJsonObject.put("first", true);
            } else {
                responseJsonObject.put("first", false);
            }

            responseJsonObject.put("batchDate", dateFormatter(DDMMYYYY,new Date(batchDate)));
            return mapper.writeValueAsString(responseJsonObject);

        } else {
		    return defaultReturnMessage("no data available.");

        }

    }

    private void updateClientState(ClientState currentState) throws APIException {
        if (!clientStateService.save(currentState)) {
            LOGGER.error("Failed to save/update client state in Gemfire cache");
            throw new APIException(Integer.parseInt(HttpStatus.INTERNAL_SERVER_ERROR.toString()),
                    HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
        }
    }

    private Map<String, String> generateMap(SchemaModel schemaModel, JSONObject jsonObject) {
        final Map<String, String> dataMap = new HashMap<>();

        for (String field : schemaModel.getModel()) {
            if (compareFields(field)) {
                try {
                    dataMap.put(field, (String) jsonObject.get(field));

                } catch (JSONException e) {
                    LOGGER.warn("error processing json object: " + jsonObject, e);
                }
            }
        }
        if(dataMap.size() == 0){
            for(String field: ENTITY_DATA_MODEL_FIELDS_ARRAY){
                try {
                    dataMap.put(field, (String) jsonObject.get(field));
                } catch (JSONException e) {
                    LOGGER.warn("error processing json object: " + jsonObject, e);
                }
            }
        }
        return dataMap;
    }

    private boolean compareFields(String field) {
        for (String e : ENTITY_DATA_MODEL_FIELDS) {
            if (e.equalsIgnoreCase(field)) return true;
        }
        return false;

    }

    private JSONObject toJsonObject(EntityData entityData) {

        try {
            return new JSONObject(mapper.writeValueAsString(entityData));
        } catch (JSONException e) {
            LOGGER.warn("error converting object: " + entityData, e);
        } catch (JsonProcessingException e) {
            LOGGER.warn("error converting object: " + entityData, e);
        }
        return null;

    }


    public int processFile(InputStream inputStream, String fileChecksum, int fileIndex) throws IOException {

        int count = 0;


        FixedLengthPayloadParser parser = new FixedLengthPayloadParser();

        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String readLine = reader.readLine();
        String readHeaderValue = readHeaderValue(readLine, fileIndex, parser);


        if (null != readHeaderValue) {
            count = saveFileData(parser, reader, readLine, fileIndex, readHeaderValue, fileChecksum);
        } else {
            LOGGER.info("Header date does not match for " + options.getFileNames().get(fileIndex));
        }
        LOGGER.info(count + " records processed from file " + options.getFileNames().get(fileIndex));
        return count;
    }

    public int saveFileData(FixedLengthPayloadParser parser, BufferedReader br, String line, int fileIndex,
                             String fileDate, String fileChecksum) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        String fileName = getFileName(fileIndex);
        int totalCount = 0;
        int actuallySaved = 0;
        int lineNo = 0;
        String temp = line;
        String footer = null;
        String currentLine = null;
        while (temp != null) {
            try {
                currentLine = temp;
                temp = br.readLine();
                lineNo++;
                boolean isLastLine = temp == null;

                if (isLastLine) {
                    footer = currentLine;
                }

                if ((totalCount == 0 && options.getSkipHeader().get(fileIndex))
                        || (isLastLine && options.getSkipFooter().get(fileIndex))) {
                    if (totalCount == 0)
                        LOGGER.info("Skipping Header Line: " + currentLine);
                    if (isLastLine)
                        LOGGER.info("Skipping Footer Line: " + currentLine);
                } else if (!isLastLine && 1 < lineNo) {



                    Map<String, Object> payloadMap = parser.parsePayload(currentLine, options, fileIndex);

                    String uniqueId = String.valueOf(options.getCountry().get(fileIndex)+payloadMap.get("accountNumber")+payloadMap.get("currency")+System.currentTimeMillis());

                    payloadMap.put(ApiConstants.COL_TIMESTAMP, dateFormatter(ApiConstants.YYYYMMDD));

                    if (null != payloadMap && !payloadMap.isEmpty()) {
                        EntityData entityData = mapper.convertValue(payloadMap, EntityData.class);
                        entityData.setId(uniqueId);
                        entityData.setFileName(fileName);
                        entityData.setFileType(options.getFileTypes().get(fileIndex));
                        entityData.setFileSource(options.getFileSource());
                        entityData.setCountry(options.getCountry().get(fileIndex));
                        entityData.setPositionDate(stringToDate(DDMMYYYY,fileDate).getTime());
                        entityData.setFileChecksum(fileChecksum);
                        
                        EntityData existingEntityData = entityDataRepository.getExistingRecord(entityData.getPositionDate(), entityData.getValueDate(), entityData.getAccountNumber(), entityData.getCurrency(), entityData.getCountry());
                        
                        if(null != existingEntityData) {                       	
                        	entityData.setId(existingEntityData.getId());                        	
                        }
                        
                        EntityData savedEntityData = entityDataRepository.save(entityData);
                        if(null != savedEntityData)
                        	actuallySaved++;
                        
                    }
                }
            } catch (Exception ex) {
                LOGGER.warn("Error proccessing line " + totalCount, ex);
            } finally {
                totalCount++;
            }
        }
        if (options.getValidateCountInFooter().get(fileIndex)) {
            Map<String, Object> footerMap = parser.parseFooter(footer, options, fileIndex);
            validateFooterCount(footerMap, totalCount, fileIndex, fileDate);
        }
        LOGGER.info(actuallySaved + " records are saved in database.");
        return totalCount;
    }

    private String getFileName(int fileIndex) {
        int fileNameIndex = options.getFileNames().get(fileIndex).replaceAll("\\\\", "/").lastIndexOf('/');
        return fileNameIndex >= 0 ? options.getFileNames().get(fileIndex).substring(fileNameIndex + 1)
                : options.getFileNames().get(fileIndex);
    }

    private String readHeaderValue(String line, Integer fileIndex, FixedLengthPayloadParser parser) {
        Map<String, Object> headerMap;
        if (line != null && options.getHeaderColumnNames().get(fileIndex) != null
                && options.getHeaderColumnNames().get(fileIndex).length > 0) {
            headerMap = parser.parseHeader(line, options, fileIndex);
            return headerMap.containsKey(ApiConstants.COL_POSITION_DATE) ? (String)headerMap.get(ApiConstants.COL_POSITION_DATE)
                    : null;
        }
        return null;
    }

    private void validateFooterCount(Map<String, Object> footerMap, int totalCount, int fileIndex, String fileDate) {
        int footerCount = 0;
        String errorMessage = "";
        try {
            String footerCountStr = (String) footerMap.get(ApiConstants.FOOTER_COUNT);
            footerCount = Integer.parseInt(footerCountStr);

        } catch (Exception ex) {
            LOGGER.warn("Error while validateFooterCount ", ex);
        }

        if (footerCount != totalCount) {
            LOGGER.error(ApiConstants.ERR_VALIDATE_FOOTER_CD,
                    "Footer (" + footerCount + ") to record (" + totalCount + ") count do not tally " + errorMessage,
                    fileIndex, fileDate);
        }
    }

}
