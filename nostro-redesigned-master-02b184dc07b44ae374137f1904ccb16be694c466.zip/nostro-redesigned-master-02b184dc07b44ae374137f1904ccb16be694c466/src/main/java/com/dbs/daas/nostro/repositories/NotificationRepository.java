package com.dbs.daas.nostro.repositories;


import org.springframework.data.gemfire.repository.GemfireRepository;
import org.springframework.stereotype.Repository;

import com.dbs.daas.nostro.model.Notification;

@Repository
public interface NotificationRepository extends GemfireRepository<Notification, String> {

}
