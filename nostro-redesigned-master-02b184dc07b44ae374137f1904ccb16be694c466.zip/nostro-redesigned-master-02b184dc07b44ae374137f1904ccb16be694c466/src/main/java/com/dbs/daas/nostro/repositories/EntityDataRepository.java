package com.dbs.daas.nostro.repositories;


import java.util.List;

import org.springframework.data.gemfire.repository.GemfireRepository;
import org.springframework.data.gemfire.repository.Query;
import org.springframework.stereotype.Repository;

import com.dbs.daas.nostro.model.EntityData;


@Repository
public interface EntityDataRepository extends GemfireRepository<EntityData, String> {

    @Query("SELECT * FROM /EntityData ORDER BY positionDate DESC LIMIT 1")
    EntityData getLatestDataEntity();
    
    @Query("SELECT * FROM /EntityData WHERE positionDate = $1 order by id ASC")
    List<EntityData> getAllByPositionDate(Long positionDate);
    
    @Query("SELECT * FROM /EntityData WHERE positionDate = $1 AND valueDate = $2 AND accountNumber = $3 AND currency = $4 AND country = $5 order by id ASC")
    EntityData getExistingRecord(Long positionDate, String valueDate, String accountNumber, String currency, String country);

}
